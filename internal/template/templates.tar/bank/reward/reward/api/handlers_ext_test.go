package api

// Handler tests for the listing endpoints and error branches not covered
// by handlers_test.go (which covers healthz, GetPointsAcct, GetProfile).

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"testing"

	"bank/reward/reward/domain"
	"bank/reward/reward/service"
)

// stubRepo lets each test script one outcome per method.
type stubRepo struct {
	accts  []domain.PointsAcct
	coupons []domain.Coupon
	err    error // when set, every call fails with err

	gotMemberLevel   string
	gotCustID, gotStatus string
	gotOffset, gotLimit    int
}

func (s *stubRepo) GetPointsAcct(context.Context, string) (domain.PointsAcct, error) {
	if s.err != nil {
		return domain.PointsAcct{}, s.err
	}
	return domain.PointsAcct{}, sql.ErrNoRows
}

func (s *stubRepo) ListPointsAccts(_ context.Context, memberLevel string, offset, limit int) ([]domain.PointsAcct, error) {
	s.gotMemberLevel, s.gotOffset, s.gotLimit = memberLevel, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return s.accts, nil
}

func (s *stubRepo) ListCoupons(_ context.Context, custID, status string, offset, limit int) ([]domain.Coupon, error) {
	s.gotCustID, s.gotStatus, s.gotOffset, s.gotLimit = custID, status, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return s.coupons, nil
}

func (s *stubRepo) GetProfile(context.Context, string) (domain.RewardProfile, error) {
	if s.err != nil {
		return domain.RewardProfile{}, s.err
	}
	return domain.RewardProfile{}, sql.ErrNoRows
}

func TestListPointsAccts_OK(t *testing.T) {
	repo := &stubRepo{accts: []domain.PointsAcct{{
		CustID: "C0000001", PointsBalance: 12000, MemberLevel: "gold", UpdateBizDate: "2026-07-01",
	}}}
	h := &Handlers{Svc: service.NewRewardService(repo)}
	code, body := get(t, NewRouter(h), "/api/v1/reward/points-accounts?member_level=gold&offset=2&limit=4")
	if code != 200 || !strings.Contains(body, `"points_balance":12000`) || !strings.Contains(body, `"member_level":"gold"`) {
		t.Errorf("code=%d body=%s", code, body)
	}
	if repo.gotMemberLevel != "gold" || repo.gotOffset != 2 || repo.gotLimit != 4 {
		t.Errorf("filters not passed through: %+v", repo)
	}
}

func TestListPointsAccts_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewRewardService(&stubRepo{err: errors.New("db down")})}
	code, body := get(t, NewRouter(h), "/api/v1/reward/points-accounts")
	if code != 500 || !strings.Contains(body, "db down") {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestListCoupons_OK(t *testing.T) {
	repo := &stubRepo{coupons: []domain.Coupon{{
		CouponID: "CP-1", CustID: "C0000001", CampaignID: "CAM-1",
		FaceValue: domain.NewMoneyFromCents(5000), MinSpend: domain.NewMoneyFromCents(30000),
		Status: "issued", IssueBizDate: "2026-07-01", ExpireDate: "2026-12-31",
	}}}
	h := &Handlers{Svc: service.NewRewardService(repo)}
	code, body := get(t, NewRouter(h), "/api/v1/reward/customers/C0000001/coupons?status=issued&limit=3")
	if code != 200 || !strings.Contains(body, `"face_value":"50.00"`) || !strings.Contains(body, `"min_spend":"300.00"`) {
		t.Errorf("code=%d body=%s", code, body)
	}
	if repo.gotCustID != "C0000001" || repo.gotStatus != "issued" || repo.gotLimit != 3 {
		t.Errorf("filters not passed through: %+v", repo)
	}
}

func TestListCoupons_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewRewardService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/reward/customers/C0000001/coupons"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestGetPointsAcct_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewRewardService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/reward/points-accounts/C0000001"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestGetProfile_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewRewardService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/reward/customers/C0000001/profile"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}
