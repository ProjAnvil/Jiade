package reward

// Tests for ConsumeDelivery, the AMQP entry point that wraps
// processCompletion with the Inbox transaction. Uses the fakesql harness
// (below) so the tx lifecycle (BeginTx/Exec/Commit) runs without PostgreSQL
// and a stub acknowledger instead of a live broker.

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"encoding/json"
	"errors"
	"io"
	"strings"
	"sync"
	"testing"

	amqp "github.com/rabbitmq/amqp091-go"

	"bank/lib/messaging"
)

// recordingAcknowledger records ack/nack/reject calls made by
// messaging.ProcessDelivery against the delivery.
type recordingAcknowledger struct {
	mu      sync.Mutex
	acked   int
	nacked  int
	rejected int
}

func (a *recordingAcknowledger) Ack(uint64, bool) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.acked++
	return nil
}

func (a *recordingAcknowledger) Nack(uint64, bool, bool) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.nacked++
	return nil
}

func (a *recordingAcknowledger) Reject(uint64, bool) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.rejected++
	return nil
}

func (a *recordingAcknowledger) counts() (int, int, int) {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.acked, a.nacked, a.rejected
}

func completionDelivery(t *testing.T, workflowID string) amqp.Delivery {
	t.Helper()
	env := completionEnvelope(t, workflowID)
	body, err := json.Marshal(env)
	if err != nil {
		t.Fatalf("marshal envelope: %v", err)
	}
	return amqp.Delivery{Body: body, Acknowledger: &recordingAcknowledger{}}
}

func TestConsumeDelivery_NilDBFailsClosed(t *testing.T) {
	earner := &fakePointsEarner{}
	c := NewConsumer(nil, earner, messaging.RetryPolicy{MaxAttempts: 3})
	err := c.ConsumeDelivery(context.Background(), completionDelivery(t, "wf-1"))
	if err == nil {
		t.Fatal("nil db must surface the missing-transaction error, not ack silently")
	}
	if len(earner.Calls()) != 0 {
		t.Errorf("EarnPoints calls = %d, want 0 when the tx cannot open", len(earner.Calls()))
	}
}

func TestConsumeDelivery_HappyPathCommitsAndAcks(t *testing.T) {
	earner := &fakePointsEarner{}
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into inbox_message", affected: 1})
	c := NewConsumer(db.open(), earner, messaging.RetryPolicy{MaxAttempts: 3})

	delivery := completionDelivery(t, "wf-tx-1")
	if err := c.ConsumeDelivery(context.Background(), delivery); err != nil {
		t.Fatalf("ConsumeDelivery: %v", err)
	}
	calls := earner.Calls()
	if len(calls) != 1 || calls[0].PaymentID != "wf-tx-1" {
		t.Fatalf("EarnPoints calls = %+v, want one call for wf-tx-1", calls)
	}
	// The inbox tx must have been committed exactly once.
	begins, commits, rolls := db.counters()
	if begins != 1 || commits != 1 || rolls != 0 {
		t.Errorf("tx counters = begin:%d commit:%d rollback:%d, want 1/1/0", begins, commits, rolls)
	}
}

func TestConsumeDelivery_DuplicateIsSkippedButAcked(t *testing.T) {
	earner := &fakePointsEarner{}
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into inbox_message", affected: 0}) // ON CONFLICT: already processed
	c := NewConsumer(db.open(), earner, messaging.RetryPolicy{MaxAttempts: 3})

	if err := c.ConsumeDelivery(context.Background(), completionDelivery(t, "wf-dup")); err != nil {
		t.Fatalf("ConsumeDelivery: %v", err)
	}
	if len(earner.Calls()) != 0 {
		t.Errorf("EarnPoints calls = %d, want 0 for a duplicate delivery", len(earner.Calls()))
	}
	// A duplicate still commits the (no-op) tx and acks the delivery.
	_, commits, rolls := db.counters()
	if commits != 1 || rolls != 0 {
		t.Errorf("tx counters commit:%d rollback:%d, want 1/0", commits, rolls)
	}
}

func TestConsumeDelivery_MalformedBodyRoutesToDLQ(t *testing.T) {
	earner := &fakePointsEarner{}
	db := &fakeDB{}
	c := NewConsumer(db.open(), earner, messaging.RetryPolicy{MaxAttempts: 3})

	delivery := amqp.Delivery{Body: []byte("{not-json"), Acknowledger: &recordingAcknowledger{}}
	err := c.ConsumeDelivery(context.Background(), delivery)
	if err == nil {
		t.Fatal("malformed envelope must yield a terminal-routing error")
	}
	if !strings.Contains(err.Error(), "decode envelope") {
		t.Errorf("error = %v, want decode-envelope cause", err)
	}
	if len(earner.Calls()) != 0 {
		t.Errorf("EarnPoints calls = %d, want 0", len(earner.Calls()))
	}
	_, _, rolls := db.counters()
	if rolls == 0 {
		t.Error("malformed envelope must roll the tx back")
	}
}

func TestNewConsumer_NilEarnerPanics(t *testing.T) {
	defer func() {
		if recover() == nil {
			t.Error("NewConsumer with nil earner must panic (fail fast at wiring time)")
		}
	}()
	db := &fakeDB{}
	NewConsumer(db.open(), nil, messaging.RetryPolicy{})
}

// ---------------------------------------------------------------------------
// fakesql harness (same design as reward/repo/fakesql_test.go, copied here
// because the consumer package test needs its own *sql.DB).
// ---------------------------------------------------------------------------

type queryPlan struct {
	marker   string
	cols     []string
	rows     [][]driver.Value
	err      error
	iterErr  error
	affected int64
}

type fakeDB struct {
	mu      sync.Mutex
	plans   []queryPlan
	calls   []fakeCall
	begins  int
	commits int
	rolls   int
}

type fakeCall struct {
	query string
	args  []driver.Value
}

func (d *fakeDB) add(p queryPlan) { d.plans = append(d.plans, p) }

func (d *fakeDB) plan(query string) *queryPlan {
	lower := strings.ToLower(query)
	for i := range d.plans {
		if strings.Contains(lower, d.plans[i].marker) {
			return &d.plans[i]
		}
	}
	return nil
}

func (d *fakeDB) record(query string, args []driver.NamedValue) {
	vals := make([]driver.Value, len(args))
	for i, a := range args {
		vals[i] = a.Value
	}
	d.mu.Lock()
	d.calls = append(d.calls, fakeCall{query: query, args: vals})
	d.mu.Unlock()
}

func (d *fakeDB) lastCallWith(marker string) *fakeCall {
	d.mu.Lock()
	defer d.mu.Unlock()
	for i := len(d.calls) - 1; i >= 0; i-- {
		if strings.Contains(strings.ToLower(d.calls[i].query), marker) {
			c := d.calls[i]
			return &c
		}
	}
	return nil
}

func (d *fakeDB) counters() (begins, commits, rolls int) {
	d.mu.Lock()
	defer d.mu.Unlock()
	return d.begins, d.commits, d.rolls
}

// open returns a *sql.DB backed by this fake driver.
func (d *fakeDB) open() *sql.DB {
	return sql.OpenDB(fakeConnector{db: d})
}

type fakeConnector struct{ db *fakeDB }

func (c fakeConnector) Connect(context.Context) (driver.Conn, error) {
	return &fakeConn{db: c.db}, nil
}
func (c fakeConnector) Driver() driver.Driver { return fakeDriver{c.db} }

type fakeDriver struct{ db *fakeDB }

func (fakeDriver) Open(string) (driver.Conn, error) {
	return nil, errors.New("fakesql: Open not supported, use sql.OpenDB")
}

type fakeConn struct{ db *fakeDB }

func (c *fakeConn) Prepare(string) (driver.Stmt, error) {
	return nil, errors.New("fakesql: Prepare not supported")
}
func (c *fakeConn) Close() error              { return nil }
func (c *fakeConn) Begin() (driver.Tx, error) { return c.BeginTx(context.Background(), driver.TxOptions{}) }
func (c *fakeConn) BeginTx(context.Context, driver.TxOptions) (driver.Tx, error) {
	c.db.mu.Lock()
	c.db.begins++
	c.db.mu.Unlock()
	return fakeTx{db: c.db}, nil
}

func (c *fakeConn) ExecContext(_ context.Context, query string, args []driver.NamedValue) (driver.Result, error) {
	c.db.record(query, args)
	p := c.db.plan(query)
	if p == nil {
		return nil, errors.New("fakesql: no plan for " + query)
	}
	if p.err != nil {
		return nil, p.err
	}
	return driver.RowsAffected(p.affected), nil
}

func (c *fakeConn) QueryContext(_ context.Context, query string, args []driver.NamedValue) (driver.Rows, error) {
	c.db.record(query, args)
	p := c.db.plan(query)
	if p == nil {
		return nil, errors.New("fakesql: no plan for " + query)
	}
	if p.err != nil {
		return nil, p.err
	}
	rows := make([][]driver.Value, len(p.rows))
	copy(rows, p.rows)
	return &fakeRows{cols: p.cols, rows: rows, iterErr: p.iterErr}, nil
}

type fakeTx struct{ db *fakeDB }

func (t fakeTx) Commit() error {
	t.db.mu.Lock()
	t.db.commits++
	t.db.mu.Unlock()
	return nil
}
func (t fakeTx) Rollback() error {
	t.db.mu.Lock()
	t.db.rolls++
	t.db.mu.Unlock()
	return nil
}

type fakeRows struct {
	cols    []string
	rows    [][]driver.Value
	idx     int
	iterErr error
}

func (r *fakeRows) Columns() []string { return r.cols }
func (r *fakeRows) Close() error      { return nil }
func (r *fakeRows) Next(dest []driver.Value) error {
	if r.idx >= len(r.rows) {
		if r.iterErr != nil {
			err := r.iterErr
			r.iterErr = nil
			return err
		}
		return io.EOF
	}
	row := r.rows[r.idx]
	r.idx++
	copy(dest, row)
	return nil
}
