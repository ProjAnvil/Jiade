// Package repo is the data access layer of reward service: this library SQL + customer gRPC query.
package repo

import (
	"bank/lib/serviceclient"
	"bank/reward/reward/domain"
	"context"
	"database/sql"
	"fmt"
)

// RewardRepo reward warehousing. This library only queries points_acct/coupon.
type RewardRepo struct {
	db       *sql.DB
	customer serviceclient.CustomerReader
}

// NewRewardRepo constructs RewardRepo.
func NewRewardRepo(db *sql.DB, customer serviceclient.CustomerReader) *RewardRepo {
	return &RewardRepo{
		db:       db,
		customer: customer,
	}
}

// GetPointsAcct checks a single points account. There is no return wrapped sql.ErrNoRows.
func (r *RewardRepo) GetPointsAcct(ctx context.Context, custID string) (domain.PointsAcct, error) {
	var a domain.PointsAcct
	var level sql.NullString
	err := r.db.QueryRowContext(ctx,
		`SELECT cust_id,points_balance,frozen_points,member_level,update_biz_date FROM points_acct WHERE cust_id=$1`,
		custID).Scan(&a.CustID, &a.PointsBalance, &a.FrozenPoints, &level, &a.UpdateBizDate)
	if err != nil {
		return domain.PointsAcct{}, fmt.Errorf("repo: query points account %s: %w", custID, err)
	}
	a.MemberLevel = level.String
	return a, nil
}

// ListPointsAccts is filtered by member_level (no limit if empty) and paging. limit<=0 takes 50.
func (r *RewardRepo) ListPointsAccts(ctx context.Context, memberLevel string, offset, limit int) ([]domain.PointsAcct, error) {
	if limit <= 0 {
		limit = 50
	}
	rows, err := r.db.QueryContext(ctx,
		`SELECT cust_id,points_balance,frozen_points,member_level,update_biz_date FROM points_acct
		WHERE ($1='' OR member_level=$1) ORDER BY cust_id LIMIT $2 OFFSET $3`, memberLevel, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("repo: list points accounts: %w", err)
	}
	defer rows.Close()
	var out []domain.PointsAcct
	for rows.Next() {
		var a domain.PointsAcct
		var level sql.NullString
		if err := rows.Scan(&a.CustID, &a.PointsBalance, &a.FrozenPoints, &level, &a.UpdateBizDate); err != nil {
			return nil, fmt.Errorf("repo: list points accounts scan: %w", err)
		}
		a.MemberLevel = level.String
		out = append(out, a)
	}
	if err := rows.Err(); err != nil {
		return out, fmt.Errorf("repo: list points accounts: %w", err)
	}
	return out, nil
}

// ListCoupons Check customer coupons (if status is empty, no limit), pagination.
func (r *RewardRepo) ListCoupons(ctx context.Context, custID, status string, offset, limit int) ([]domain.Coupon, error) {
	if limit <= 0 {
		limit = 50
	}
	rows, err := r.db.QueryContext(ctx,
		`SELECT coupon_id,cust_id,campaign_id,face_value,min_spend,status,issue_biz_date,expire_date
		FROM coupon WHERE ($1='' OR cust_id=$1) AND ($2='' OR status=$2)
		ORDER BY issue_biz_date DESC, coupon_id LIMIT $3 OFFSET $4`, custID, status, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("repo: list coupons: %w", err)
	}
	defer rows.Close()
	return scanCoupons(rows)
}

// GetProfile checks the library points account, and then calls customer to obtain the customer name/type.
func (r *RewardRepo) GetProfile(ctx context.Context, custID string) (domain.RewardProfile, error) {
	var p domain.RewardProfile
	var level sql.NullString
	err := r.db.QueryRowContext(ctx,
		`SELECT cust_id,points_balance,member_level FROM points_acct WHERE cust_id=$1`, custID).
		Scan(&p.CustID, &p.PointsBalance, &level)
	if err != nil {
		return domain.RewardProfile{}, fmt.Errorf("repo: query points profile %s: %w", custID, err)
	}
	customer, err := r.customer.GetCustomer(ctx, custID, serviceclient.RequestID(ctx))
	if err != nil {
		return domain.RewardProfile{}, fmt.Errorf("repo: query customer %s from customer: %w", custID, err)
	}
	p.MemberLevel, p.CustName, p.CustType = level.String, customer.Name, customer.CustomerType
	return p, nil
}

func scanCoupons(rows *sql.Rows) ([]domain.Coupon, error) {
	var out []domain.Coupon
	for rows.Next() {
		var c domain.Coupon
		var camp, face, minS, issue, exp sql.NullString
		if err := rows.Scan(&c.CouponID, &c.CustID, &camp, &face, &minS, &c.Status, &issue, &exp); err != nil {
			return nil, fmt.Errorf("repo: scan coupon: %w", err)
		}
		c.CampaignID, c.IssueBizDate, c.ExpireDate = camp.String, issue.String, exp.String
		fv, err := domain.ParseCents(face.String)
		if err != nil {
			return nil, fmt.Errorf("repo: parse coupon amount: %w", err)
		}
		ms, err := domain.ParseCents(minS.String)
		if err != nil {
			return nil, fmt.Errorf("repo: parse coupon amount: %w", err)
		}
		c.FaceValue, c.MinSpend = fv, ms
		out = append(out, c)
	}
	if err := rows.Err(); err != nil {
		return out, fmt.Errorf("repo: list coupons: %w", err)
	}
	return out, nil
}
