package repo

// Unit tests for RewardRepo query/scan logic using the fakesql harness in
// fakesql_test.go (no live PostgreSQL). Live-DB round-trips remain in the
// integration-gated reward_repo_test.go.

import (
	"context"
	"database/sql/driver"
	"errors"
	"strings"
	"testing"

	"bank/lib/serviceclient"
)

type stubCustomerReader struct {
	customer serviceclient.Customer
	err      error
	calls    int
}

func (s *stubCustomerReader) GetCustomer(_ context.Context, customerID, _ string) (serviceclient.Customer, error) {
	s.calls++
	if s.err != nil {
		return serviceclient.Customer{}, s.err
	}
	return serviceclient.Customer{CustomerID: customerID, Name: "Alice", CustomerType: "personal"}, nil
}

const acctCols = "cust_id,points_balance,frozen_points,member_level,update_biz_date"

func TestGetPointsAcct_MapsRow(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from points_acct where cust_id=$1",
		cols:   strings.Split(acctCols, ","),
		rows:   [][]driver.Value{{"C0000001", int64(12000), int64(500), "gold", "2026-07-01"}},
	})
	r := NewRewardRepo(db.open(), &stubCustomerReader{})
	a, err := r.GetPointsAcct(context.Background(), "C0000001")
	if err != nil {
		t.Fatalf("GetPointsAcct: %v", err)
	}
	if a.CustID != "C0000001" || a.PointsBalance != 12000 || a.FrozenPoints != 500 || a.MemberLevel != "gold" {
		t.Errorf("account mapping wrong: %+v", a)
	}
	if call := db.lastCallWith("from points_acct"); call == nil || call.args[0] != "C0000001" {
		t.Errorf("cust filter not passed: %+v", call)
	}
}

func TestGetPointsAcct_MissingRowWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from points_acct where cust_id=$1", cols: strings.Split(acctCols, ",")})
	r := NewRewardRepo(db.open(), &stubCustomerReader{})
	if _, err := r.GetPointsAcct(context.Background(), "C-NOPE"); err == nil || !strings.Contains(err.Error(), "C-NOPE") {
		t.Fatalf("want wrapped not-found error, got %v", err)
	}
}

func TestListPointsAccts_MapsRowsAndDefaultsLimit(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from points_acct",
		cols:   strings.Split(acctCols, ","),
		rows: [][]driver.Value{
			{"C0000001", int64(12000), int64(500), "gold", "2026-07-01"},
			{"C0000002", int64(10), int64(0), nil, "2026-07-01"},
		},
	})
	r := NewRewardRepo(db.open(), &stubCustomerReader{})
	list, err := r.ListPointsAccts(context.Background(), "gold", 0, 0)
	if err != nil {
		t.Fatalf("ListPointsAccts: %v", err)
	}
	if len(list) != 2 {
		t.Fatalf("accounts = %d, want 2", len(list))
	}
	if list[0].MemberLevel != "gold" || list[1].MemberLevel != "" {
		t.Errorf("member level mapping wrong: %+v", list)
	}
	if call := db.lastCallWith("from points_acct"); call == nil || call.args[0] != "gold" || call.args[1] != int64(50) {
		t.Errorf("default limit not applied: %+v", call)
	}
}

func TestListPointsAccts_QueryErrorWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from points_acct", err: errors.New("boom")})
	r := NewRewardRepo(db.open(), &stubCustomerReader{})
	if _, err := r.ListPointsAccts(context.Background(), "", 0, 10); err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("want wrapped error, got %v", err)
	}
}

const couponCols = "coupon_id,cust_id,campaign_id,face_value,min_spend,status,issue_biz_date,expire_date"

func TestListCoupons_MapsRows(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from coupon",
		cols:   strings.Split(couponCols, ","),
		rows: [][]driver.Value{
			{"CP-1", "C0000001", "CAM-1", "50.00", "300.00", "issued", "2026-07-01", "2026-12-31"},
			{"CP-2", "C0000001", nil, nil, nil, "used", nil, nil},
		},
	})
	r := NewRewardRepo(db.open(), &stubCustomerReader{})
	list, err := r.ListCoupons(context.Background(), "C0000001", "issued", 0, 10)
	if err != nil {
		t.Fatalf("ListCoupons: %v", err)
	}
	if len(list) != 2 {
		t.Fatalf("coupons = %d, want 2", len(list))
	}
	if list[0].FaceValue.Cents() != 5000 || list[0].MinSpend.Cents() != 30000 || list[0].Status != "issued" {
		t.Errorf("coupon mapping wrong: %+v", list[0])
	}
	if list[1].FaceValue.Cents() != 0 || list[1].CampaignID != "" || list[1].ExpireDate != "" {
		t.Errorf("NULL coupon columns wrong: %+v", list[1])
	}
	if call := db.lastCallWith("from coupon"); call == nil || call.args[0] != "C0000001" || call.args[1] != "issued" {
		t.Errorf("filters not passed: %+v", call)
	}
}

func TestListCoupons_BadFaceValueFails(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from coupon",
		cols:   strings.Split(couponCols, ","),
		rows:   [][]driver.Value{{"CP-1", "C1", "CAM", "NaN", "1.00", "issued", nil, nil}},
	})
	r := NewRewardRepo(db.open(), &stubCustomerReader{})
	if _, err := r.ListCoupons(context.Background(), "", "", 0, 10); err == nil {
		t.Fatal("bad face_value should fail")
	}
}

func TestGetProfile_JoinsCustomer(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from points_acct where cust_id=$1",
		cols:   []string{"cust_id", "points_balance", "member_level"},
		rows:   [][]driver.Value{{"C0000001", int64(12000), "gold"}},
	})
	cust := &stubCustomerReader{}
	r := NewRewardRepo(db.open(), cust)
	p, err := r.GetProfile(context.Background(), "C0000001")
	if err != nil {
		t.Fatalf("GetProfile: %v", err)
	}
	if p.CustName != "Alice" || p.CustType != "personal" || p.MemberLevel != "gold" || p.PointsBalance != 12000 {
		t.Errorf("profile mapping wrong: %+v", p)
	}
	if cust.calls != 1 {
		t.Errorf("customer calls = %d, want 1", cust.calls)
	}
}

func TestGetProfile_CustomerFailureWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from points_acct where cust_id=$1",
		cols:   []string{"cust_id", "points_balance", "member_level"},
		rows:   [][]driver.Value{{"C0000001", int64(1), "gold"}},
	})
	r := NewRewardRepo(db.open(), &stubCustomerReader{err: errors.New("grpc down")})
	_, err := r.GetProfile(context.Background(), "C0000001")
	if err == nil || !strings.Contains(err.Error(), "grpc down") {
		t.Fatalf("want customer error surfaced, got %v", err)
	}
}
