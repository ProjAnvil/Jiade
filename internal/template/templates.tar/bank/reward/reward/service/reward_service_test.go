package service

// Tests for the query-orchestration layer: every method must pass its
// arguments through to the store unchanged and surface the store error.

import (
	"context"
	"errors"
	"testing"

	"bank/reward/reward/domain"
)

type recordingStore struct {
	gotCustID      string
	gotMemberLevel string
	gotStatus      string
	gotOffset      int
	gotLimit       int

	err error
}

func (s *recordingStore) GetPointsAcct(_ context.Context, custID string) (domain.PointsAcct, error) {
	s.gotCustID = custID
	if s.err != nil {
		return domain.PointsAcct{}, s.err
	}
	return domain.PointsAcct{CustID: custID, PointsBalance: 100}, nil
}

func (s *recordingStore) ListPointsAccts(_ context.Context, memberLevel string, offset, limit int) ([]domain.PointsAcct, error) {
	s.gotMemberLevel, s.gotOffset, s.gotLimit = memberLevel, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return []domain.PointsAcct{{CustID: "C1"}}, nil
}

func (s *recordingStore) ListCoupons(_ context.Context, custID, status string, offset, limit int) ([]domain.Coupon, error) {
	s.gotCustID, s.gotStatus, s.gotOffset, s.gotLimit = custID, status, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return []domain.Coupon{{CouponID: "CP-1"}}, nil
}

func (s *recordingStore) GetProfile(_ context.Context, custID string) (domain.RewardProfile, error) {
	s.gotCustID = custID
	if s.err != nil {
		return domain.RewardProfile{}, s.err
	}
	return domain.RewardProfile{CustID: custID}, nil
}

func TestRewardService_PassesFiltersThrough(t *testing.T) {
	store := &recordingStore{}
	svc := NewRewardService(store)
	ctx := context.Background()

	a, err := svc.GetPointsAcct(ctx, "C0000001")
	if err != nil || a.CustID != "C0000001" || a.PointsBalance != 100 {
		t.Fatalf("GetPointsAcct: %+v %v", a, err)
	}
	if _, err := svc.ListPointsAccts(ctx, "gold", 10, 5); err != nil {
		t.Fatal(err)
	}
	if store.gotMemberLevel != "gold" || store.gotOffset != 10 || store.gotLimit != 5 {
		t.Errorf("ListPointsAccts args wrong: %+v", store)
	}
	if _, err := svc.ListCoupons(ctx, "C0000001", "issued", 1, 2); err != nil {
		t.Fatal(err)
	}
	if store.gotCustID != "C0000001" || store.gotStatus != "issued" || store.gotLimit != 2 {
		t.Errorf("ListCoupons args wrong: %+v", store)
	}
	p, err := svc.Profile(ctx, "C0000001")
	if err != nil || p.CustID != "C0000001" {
		t.Fatalf("Profile: %+v %v", p, err)
	}
}

func TestRewardService_SurfacesStoreErrors(t *testing.T) {
	boom := errors.New("boom")
	svc := NewRewardService(&recordingStore{err: boom})
	ctx := context.Background()

	if _, err := svc.GetPointsAcct(ctx, "x"); !errors.Is(err, boom) {
		t.Errorf("GetPointsAcct err = %v", err)
	}
	if _, err := svc.ListPointsAccts(ctx, "", 0, 0); !errors.Is(err, boom) {
		t.Errorf("ListPointsAccts err = %v", err)
	}
	if _, err := svc.ListCoupons(ctx, "", "", 0, 0); !errors.Is(err, boom) {
		t.Errorf("ListCoupons err = %v", err)
	}
	if _, err := svc.Profile(ctx, "x"); !errors.Is(err, boom) {
		t.Errorf("Profile err = %v", err)
	}
}
