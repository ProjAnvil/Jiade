package repo

// Unit tests for PaymentRepo query/scan logic using the fakesql harness in
// fakesql_test.go (no live PostgreSQL). Live-DB round-trips remain in the
// integration-gated payment_repo_test.go.

import (
	"context"
	"database/sql/driver"
	"errors"
	"strings"
	"testing"

	"bank/lib/serviceclient"
)

type stubAccountReader struct {
	err   error
	calls []string
}

func (s *stubAccountReader) GetAccount(_ context.Context, accountNo, _ string) (serviceclient.Account, error) {
	s.calls = append(s.calls, accountNo)
	if s.err != nil {
		return serviceclient.Account{}, s.err
	}
	return serviceclient.Account{AccountNo: accountNo, CustomerID: "C0000001"}, nil
}

type stubCustomerReader struct {
	err    error
	calls  int
}

func (s *stubCustomerReader) GetCustomer(_ context.Context, _, _ string) (serviceclient.Customer, error) {
	s.calls++
	if s.err != nil {
		return serviceclient.Customer{}, s.err
	}
	return serviceclient.Customer{CustomerID: "C0000001", Name: "Alice"}, nil
}

const transferCols = "txn_id,biz_date,out_account,in_account,amount,ccy,fee,channel,counter_bank,status,summary"

func transferRow(id string) []driver.Value {
	return []driver.Value{id, "2026-07-01", "6222000000000001", "6222000000000002", "10000.00", "CNY", "5.00", "online", "ICBC", "booked", "rent"}
}

func TestListTransfers_MapsRowsAndDefaultsLimit(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from transfer_txn", cols: strings.Split(transferCols, ","), rows: [][]driver.Value{
		transferRow("T1"),
		{"T2", "2026-07-02", "A1", "A2", "1.00", "CNY", "0", nil, nil, "pending", nil},
	}})
	r := NewPaymentRepo(db.open(), &stubAccountReader{}, &stubCustomerReader{})
	list, err := r.ListTransfers(context.Background(), "6222000000000001", "2026-07-01", "2026-07-31", 0, 10)
	if err != nil {
		t.Fatalf("ListTransfers: %v", err)
	}
	if len(list) != 2 {
		t.Fatalf("transfers = %d, want 2", len(list))
	}
	tt := list[0]
	if tt.TxnID != "T1" || tt.Amount.Cents() != 1000000 || tt.Fee.Cents() != 500 || tt.Channel != "online" || tt.CounterBank != "ICBC" {
		t.Errorf("transfer mapping wrong: %+v", tt)
	}
	if list[1].Fee.Cents() != 0 || list[1].Channel != "" {
		t.Errorf("NULL fee/channel wrong: %+v", list[1])
	}
	if call := db.lastCallWith("from transfer_txn"); call == nil || call.args[0] != "6222000000000001" || call.args[3] != int64(50) {
		t.Errorf("default limit not applied: %+v", call)
	}
}

func TestListTransfers_BadAmountFails(t *testing.T) {
	db := &fakeDB{}
	row := transferRow("T1")
	row[4] = "NaN"
	db.add(queryPlan{marker: "from transfer_txn", cols: strings.Split(transferCols, ","), rows: [][]driver.Value{row}})
	r := NewPaymentRepo(db.open(), &stubAccountReader{}, &stubCustomerReader{})
	if _, err := r.ListTransfers(context.Background(), "", "", "", 10, 0); err == nil {
		t.Fatal("bad amount should fail the scan")
	}
}

func TestGetTransfer_FoundAndMissing(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from transfer_txn where txn_id=$1", cols: strings.Split(transferCols, ","), rows: [][]driver.Value{transferRow("T1")}})
	r := NewPaymentRepo(db.open(), &stubAccountReader{}, &stubCustomerReader{})
	tt, err := r.GetTransfer(context.Background(), "T1")
	if err != nil || tt.TxnID != "T1" {
		t.Fatalf("GetTransfer: %+v %v", tt, err)
	}

	empty := &fakeDB{}
	empty.add(queryPlan{marker: "from transfer_txn where txn_id=$1", cols: strings.Split(transferCols, ",")})
	r2 := NewPaymentRepo(empty.open(), &stubAccountReader{}, &stubCustomerReader{})
	if _, err := r2.GetTransfer(context.Background(), "T-NOPE"); err == nil || !strings.Contains(err.Error(), "T-NOPE") {
		t.Fatalf("want wrapped not-found error, got %v", err)
	}
}

func TestGetTransferParties_JoinsCoreAndCustomer(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from transfer_txn where txn_id=$1",
		cols:   []string{"txn_id", "amount", "ccy", "biz_date", "out_account", "in_account"},
		rows:   [][]driver.Value{{"T1", "10000.00", "CNY", "2026-07-01", "ACC-OUT", "ACC-IN"}},
	})
	core := &stubAccountReader{}
	cust := &stubCustomerReader{}
	r := NewPaymentRepo(db.open(), core, cust)
	p, err := r.GetTransferParties(context.Background(), "T1")
	if err != nil {
		t.Fatalf("GetTransferParties: %v", err)
	}
	if p.Amount.Cents() != 1000000 || p.OutAccount != "ACC-OUT" || p.InAccount != "ACC-IN" {
		t.Errorf("parties mapping wrong: %+v", p)
	}
	if p.OutCustName != "Alice" || p.InCustName != "Alice" {
		t.Errorf("federated names wrong: %+v", p)
	}
	if len(core.calls) != 2 || cust.calls != 2 {
		t.Errorf("core calls=%v customer calls=%d, want 2/2", core.calls, cust.calls)
	}
}

func TestGetTransferParties_BadAmountFails(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from transfer_txn where txn_id=$1",
		cols:   []string{"txn_id", "amount", "ccy", "biz_date", "out_account", "in_account"},
		rows:   [][]driver.Value{{"T1", "bad", "CNY", "2026-07-01", "ACC-OUT", "ACC-IN"}},
	})
	r := NewPaymentRepo(db.open(), &stubAccountReader{}, &stubCustomerReader{})
	if _, err := r.GetTransferParties(context.Background(), "T1"); err == nil {
		t.Fatal("bad amount should fail the federation lookup")
	}
}

func TestGetTransferParties_CoreFailureWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from transfer_txn where txn_id=$1",
		cols:   []string{"txn_id", "amount", "ccy", "biz_date", "out_account", "in_account"},
		rows:   [][]driver.Value{{"T1", "1.00", "CNY", "2026-07-01", "ACC-OUT", "ACC-IN"}},
	})
	r := NewPaymentRepo(db.open(), &stubAccountReader{err: errors.New("grpc down")}, &stubCustomerReader{})
	_, err := r.GetTransferParties(context.Background(), "T1")
	if err == nil || !strings.Contains(err.Error(), "grpc down") {
		t.Fatalf("want core error surfaced, got %v", err)
	}
}

func TestGetTransferParties_CustomerFailureWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from transfer_txn where txn_id=$1",
		cols:   []string{"txn_id", "amount", "ccy", "biz_date", "out_account", "in_account"},
		rows:   [][]driver.Value{{"T1", "1.00", "CNY", "2026-07-01", "ACC-OUT", "ACC-IN"}},
	})
	r := NewPaymentRepo(db.open(), &stubAccountReader{}, &stubCustomerReader{err: errors.New("customer down")})
	_, err := r.GetTransferParties(context.Background(), "T1")
	if err == nil || !strings.Contains(err.Error(), "customer down") {
		t.Fatalf("want customer error surfaced, got %v", err)
	}
}

func TestGetMerchant_Found(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from merchant",
		cols:   []string{"merchant_id", "merchant_name", "mcc", "region", "status", "create_biz_date"},
		rows:   [][]driver.Value{{"M-1", "Coffee Shop", "5812", "CN-SH", "active", "2026-01-01"}},
	})
	r := NewPaymentRepo(db.open(), &stubAccountReader{}, &stubCustomerReader{})
	m, err := r.GetMerchant(context.Background(), "M-1")
	if err != nil || m.MerchantID != "M-1" || m.MCC != "5812" || m.Status != "active" {
		t.Fatalf("GetMerchant: %+v %v", m, err)
	}
}

func TestGetMerchant_MissingWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from merchant", cols: []string{"merchant_id"}})
	r := NewPaymentRepo(db.open(), &stubAccountReader{}, &stubCustomerReader{})
	if _, err := r.GetMerchant(context.Background(), "M-NOPE"); err == nil {
		t.Fatal("missing merchant should fail")
	}
}
