package api

// Handler tests for ListTransfers, GetMerchant, and the non-ErrNoRows error
// branches not covered by handlers_test.go (healthz, GetTransfer,
// GetTransferParties).

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"testing"

	"bank/payment/payment/domain"
	"bank/payment/payment/service"
)

// stubRepo lets each test script one outcome per method.
type stubRepo struct {
	transfers []domain.Transfer
	merchant  *domain.Merchant
	err       error

	gotAccountNo, gotFrom, gotTo string
	gotLimit, gotOffset          int
}

func (s *stubRepo) ListTransfers(_ context.Context, accountNo, from, to string, limit, offset int) ([]domain.Transfer, error) {
	s.gotAccountNo, s.gotFrom, s.gotTo, s.gotLimit, s.gotOffset = accountNo, from, to, limit, offset
	if s.err != nil {
		return nil, s.err
	}
	return s.transfers, nil
}

func (s *stubRepo) GetTransfer(context.Context, string) (domain.Transfer, error) {
	if s.err != nil {
		return domain.Transfer{}, s.err
	}
	return domain.Transfer{}, sql.ErrNoRows
}

func (s *stubRepo) GetTransferParties(context.Context, string) (domain.TransferParty, error) {
	if s.err != nil {
		return domain.TransferParty{}, s.err
	}
	return domain.TransferParty{}, sql.ErrNoRows
}

func (s *stubRepo) GetMerchant(context.Context, string) (domain.Merchant, error) {
	if s.err != nil {
		return domain.Merchant{}, s.err
	}
	if s.merchant != nil {
		return *s.merchant, nil
	}
	return domain.Merchant{}, sql.ErrNoRows
}

func TestListTransfers_OK(t *testing.T) {
	repo := &stubRepo{transfers: []domain.Transfer{{
		TxnID: "T1", BizDate: "2026-07-01", OutAccount: "ACC-1", InAccount: "ACC-2",
		Amount: domain.NewMoneyFromCents(1000000), Ccy: "CNY", Fee: domain.NewMoneyFromCents(500), Status: "booked",
	}}}
	h := &Handlers{Svc: service.NewPaymentService(repo)}
	code, body := get(t, NewRouter(h), "/api/v1/payments/transfers?account_no=ACC-1&from=2026-07-01&to=2026-07-31&limit=3&offset=6")
	if code != 200 || !strings.Contains(body, `"txn_id":"T1"`) || !strings.Contains(body, `"amount":"10000.00"`) || !strings.Contains(body, `"fee":"5.00"`) {
		t.Errorf("code=%d body=%s", code, body)
	}
	if repo.gotAccountNo != "ACC-1" || repo.gotFrom != "2026-07-01" || repo.gotLimit != 3 || repo.gotOffset != 6 {
		t.Errorf("filters not passed through: %+v", repo)
	}
}

func TestListTransfers_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewPaymentService(&stubRepo{err: errors.New("db down")})}
	code, body := get(t, NewRouter(h), "/api/v1/payments/transfers")
	if code != 500 || !strings.Contains(body, "db down") {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestGetMerchant_OK(t *testing.T) {
	h := &Handlers{Svc: service.NewPaymentService(&stubRepo{merchant: &domain.Merchant{
		MerchantID: "M-1", MerchantName: "Coffee Shop", MCC: "5812", Region: "CN-SH", Status: "active",
	}})}
	code, body := get(t, NewRouter(h), "/api/v1/merchants/M-1")
	if code != 200 || !strings.Contains(body, `"merchant_id":"M-1"`) || !strings.Contains(body, `"mcc":"5812"`) {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestGetMerchant_NotFoundIs404(t *testing.T) {
	h := &Handlers{Svc: service.NewPaymentService(&stubRepo{})}
	if code, _ := get(t, NewRouter(h), "/api/v1/merchants/M-NOPE"); code != 404 {
		t.Errorf("code=%d want 404", code)
	}
}

func TestGetMerchant_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewPaymentService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/merchants/M-1"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestGetTransfer_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewPaymentService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/payments/transfers/T1"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestGetTransferParties_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewPaymentService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/payments/transfers/T1/parties"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}
