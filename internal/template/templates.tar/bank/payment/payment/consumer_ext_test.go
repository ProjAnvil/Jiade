package payment

// Unit tests for the DB-backed consumer components that need a *sql.DB:
// PaymentIntentRepo, WorkflowStarter, ConsumeDelivery (outer Inbox tx), the
// atomic status+completion path, reversal auto-detection, InstanceStatusRepo,
// PgCompletionOutbox, and the OutboxRelay drain loop. Uses the fakesql harness
// (bottom of this file) so the tx lifecycle runs without PostgreSQL, plus the
// stubs already defined in consumer_test.go.

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"strings"
	"sync"
	"testing"
	"time"

	amqp "github.com/rabbitmq/amqp091-go"

	"bank/lib/messaging"
	"bank/lib/workflow"
)

// ackingAcknowledger satisfies amqp.Acknowledger.
type ackingAcknowledger struct {
	mu     sync.Mutex
	acked  int
	nacked int
}

func (a *ackingAcknowledger) Ack(uint64, bool) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.acked++
	return nil
}
func (a *ackingAcknowledger) Nack(uint64, bool, bool) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.nacked++
	return nil
}
func (a *ackingAcknowledger) Reject(uint64, bool) error { return nil }

func resultDelivery(t *testing.T, workflowID string) amqp.Delivery {
	t.Helper()
	env := sampleEnvelope(t, "risk.payment-authorized.v1", workflowID)
	raw, err := json.Marshal(env)
	if err != nil {
		t.Fatalf("marshal envelope: %v", err)
	}
	return amqp.Delivery{Body: raw, Acknowledger: &ackingAcknowledger{}}
}

// --- PaymentIntentRepo ---

const intentCols = "idempotency_key,request_hash,workflow_id,payer_customer_id,payer_account_no,payee_account_no,currency,amount_minor,status,reversed,created_at,updated_at"

var intentNow = time.Date(2026, 7, 31, 12, 0, 0, 0, time.UTC)

func intentRow(key, hash, workflowID, status string) []driver.Value {
	return []driver.Value{key, hash, workflowID, "C0000001", "ACC-1", "ACC-2", "CNY", int64(10000), status, false, intentNow, intentNow}
}

func sampleIntent(key, hash, workflowID string) PaymentIntent {
	return PaymentIntent{
		IdempotencyKey: key, RequestHash: hash, WorkflowID: workflowID,
		PayerCustomerID: "C0000001", PayerAccountNo: "ACC-1", PayeeAccountNo: "ACC-2",
		Currency: "CNY", AmountMinor: 10000, Status: IntentPending,
	}
}

func TestCreateOrMatchInTx_Insert(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into payment_intent", cols: []string{"idempotency_key"}, rows: [][]driver.Value{{"key-1"}}})
	repo := NewPaymentIntentRepo(db.open())
	got, inserted, err := repo.CreateOrMatchInTx(context.Background(), db.open(), sampleIntent("key-1", "hash-1", "wf-1"))
	if err != nil || !inserted {
		t.Fatalf("CreateOrMatchInTx = %+v, %v, %v; want inserted", got, inserted, err)
	}
}

func TestCreateOrMatchInTx_ReplaySameHash(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into payment_intent", cols: []string{"idempotency_key"}}) // RETURNING empty: conflict
	db.add(queryPlan{marker: "from payment_intent where idempotency_key", cols: strings.Split(intentCols, ","), rows: [][]driver.Value{intentRow("key-1", "hash-1", "wf-old", "running")}})
	repo := NewPaymentIntentRepo(db.open())
	got, inserted, err := repo.CreateOrMatchInTx(context.Background(), db.open(), sampleIntent("key-1", "hash-1", "wf-new"))
	if err != nil {
		t.Fatalf("CreateOrMatchInTx: %v", err)
	}
	if inserted {
		t.Error("replay must report inserted=false")
	}
	if got.WorkflowID != "wf-old" {
		t.Errorf("replay must keep the original workflow_id, got %q", got.WorkflowID)
	}
	if got.Status != IntentRunning {
		t.Errorf("existing status = %q, want running", got.Status)
	}
}

func TestCreateOrMatchInTx_ConflictDifferentHash(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into payment_intent", cols: []string{"idempotency_key"}})
	db.add(queryPlan{marker: "from payment_intent where idempotency_key", cols: strings.Split(intentCols, ","), rows: [][]driver.Value{intentRow("key-1", "hash-OTHER", "wf-old", "running")}})
	repo := NewPaymentIntentRepo(db.open())
	_, _, err := repo.CreateOrMatchInTx(context.Background(), db.open(), sampleIntent("key-1", "hash-1", "wf-new"))
	if !errors.Is(err, ErrIdempotencyConflict) {
		t.Fatalf("want ErrIdempotencyConflict, got %v", err)
	}
}

func TestCreateOrMatchInTx_InsertErrorWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into payment_intent", err: errors.New("syntax error")})
	repo := NewPaymentIntentRepo(db.open())
	_, _, err := repo.CreateOrMatchInTx(context.Background(), db.open(), sampleIntent("key-1", "hash-1", "wf-1"))
	if err == nil || !strings.Contains(err.Error(), "syntax error") {
		t.Fatalf("want wrapped error, got %v", err)
	}
}

func TestGetByWorkflowID_FoundAndMissing(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from payment_intent where workflow_id", cols: strings.Split(intentCols, ","), rows: [][]driver.Value{intentRow("key-1", "hash-1", "wf-1", "succeeded")}})
	repo := NewPaymentIntentRepo(db.open())
	intent, err := repo.GetByWorkflowID(context.Background(), "wf-1")
	if err != nil || intent.WorkflowID != "wf-1" || intent.Status != IntentSucceeded {
		t.Fatalf("GetByWorkflowID: %+v %v", intent, err)
	}

	empty := &fakeDB{}
	empty.add(queryPlan{marker: "from payment_intent where workflow_id", cols: strings.Split(intentCols, ",")})
	repo2 := NewPaymentIntentRepo(empty.open())
	if _, err := repo2.GetByWorkflowID(context.Background(), "wf-nope"); !errors.Is(err, ErrWorkflowNotFound) {
		t.Fatalf("want ErrWorkflowNotFound, got %v", err)
	}
}

func TestUpdateStatusByWorkflowID(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "set status = $2", affected: 1})
	repo := NewPaymentIntentRepo(db.open())
	if err := repo.UpdateStatusByWorkflowID(context.Background(), "wf-1", IntentSucceeded); err != nil {
		t.Fatalf("UpdateStatusByWorkflowID: %v", err)
	}
	if call := db.lastCallWith("update payment_intent"); call == nil || call.args[0] != "wf-1" || call.args[1] != "succeeded" {
		t.Errorf("args wrong: %+v", call)
	}
}

func TestUpdateStatusByWorkflowIDInTx_ErrorWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "set status = $2", err: errors.New("deadlock")})
	repo := NewPaymentIntentRepo(db.open())
	err := repo.UpdateStatusByWorkflowIDInTx(context.Background(), db.open(), "wf-1", IntentSucceeded)
	if err == nil || !strings.Contains(err.Error(), "deadlock") {
		t.Fatalf("want wrapped error, got %v", err)
	}
}

func TestMarkReversedByWorkflowID(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "set reversed = true", affected: 1})
	repo := NewPaymentIntentRepo(db.open())
	if err := repo.MarkReversedByWorkflowID(context.Background(), "wf-1"); err != nil {
		t.Fatalf("MarkReversedByWorkflowID: %v", err)
	}

	zero := &fakeDB{}
	zero.add(queryPlan{marker: "set reversed = true", affected: 0})
	repo2 := NewPaymentIntentRepo(zero.open())
	if err := repo2.MarkReversedByWorkflowID(context.Background(), "wf-1"); !errors.Is(err, ErrWorkflowNotFound) {
		t.Fatalf("want ErrWorkflowNotFound on zero rows, got %v", err)
	}
}

func TestMarkReversalPendingByWorkflowID(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "set status = 'reversal_pending'", affected: 1})
	repo := NewPaymentIntentRepo(db.open())
	if err := repo.MarkReversalPendingByWorkflowID(context.Background(), "wf-1"); err != nil {
		t.Fatalf("MarkReversalPendingByWorkflowID: %v", err)
	}

	zero := &fakeDB{}
	zero.add(queryPlan{marker: "set status = 'reversal_pending'", affected: 0})
	repo2 := NewPaymentIntentRepo(zero.open())
	if err := repo2.MarkReversalPendingByWorkflowID(context.Background(), "wf-1"); !errors.Is(err, ErrWorkflowNotFound) {
		t.Fatalf("want ErrWorkflowNotFound on zero rows, got %v", err)
	}

	failing := &fakeDB{}
	failing.add(queryPlan{marker: "set status = 'reversal_pending'", err: errors.New("boom")})
	repo3 := NewPaymentIntentRepo(failing.open())
	if err := repo3.MarkReversalPendingByWorkflowID(context.Background(), "wf-1"); err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("want wrapped error, got %v", err)
	}
}

// --- WorkflowStarter ---

type recordingWorkflowStore struct {
	created []workflow.StartRequest
	err     error
}

func (s *recordingWorkflowStore) CreateInTx(_ context.Context, _ *sql.Tx, req workflow.StartRequest) (workflow.Instance, error) {
	s.created = append(s.created, req)
	if s.err != nil {
		return workflow.Instance{}, s.err
	}
	return workflow.Instance{ID: req.WorkflowID}, nil
}

func TestStartPayment_NewIntentCreatesWorkflow(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into payment_intent", cols: []string{"idempotency_key"}, rows: [][]driver.Value{{"key-1"}}})
	intents := NewPaymentIntentRepo(db.open())
	store := &recordingWorkflowStore{}
	starter := NewWorkflowStarter(db.open(), intents, store, nil)
	if starter.now == nil {
		t.Error("NewWorkflowStarter must default now to time.Now")
	}

	result, err := starter.StartPayment(context.Background(), StartPaymentRequest{
		IdempotencyKey: "key-1", RequestHash: "hash-1", PayerCustomerID: "C0000001",
		PayerAccountNo: "ACC-1", PayeeAccountNo: "ACC-2", Currency: "CNY", AmountMinor: 10000,
	}, "wf-new")
	if err != nil {
		t.Fatalf("StartPayment: %v", err)
	}
	if !result.Inserted || result.Intent.WorkflowID != "wf-new" {
		t.Errorf("result wrong: %+v", result)
	}
	if len(store.created) != 1 {
		t.Fatalf("workflow creations = %d, want 1", len(store.created))
	}
	if store.created[0].WorkflowID != "wf-new" || store.created[0].CorrelationID != "wf-new" {
		t.Errorf("workflow request wrong: %+v", store.created[0])
	}
	_, commits, _ := db.counters()
	if commits != 1 {
		t.Errorf("commits = %d, want 1", commits)
	}
}

func TestStartPayment_ReplaySkipsWorkflowCreate(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into payment_intent", cols: []string{"idempotency_key"}})
	db.add(queryPlan{marker: "from payment_intent where idempotency_key", cols: strings.Split(intentCols, ","), rows: [][]driver.Value{intentRow("key-1", "hash-1", "wf-old", "running")}})
	intents := NewPaymentIntentRepo(db.open())
	store := &recordingWorkflowStore{}
	starter := NewWorkflowStarter(db.open(), intents, store, nil)

	result, err := starter.StartPayment(context.Background(), StartPaymentRequest{
		IdempotencyKey: "key-1", RequestHash: "hash-1", Currency: "CNY",
	}, "wf-new")
	if err != nil {
		t.Fatalf("StartPayment: %v", err)
	}
	if result.Inserted || result.Intent.WorkflowID != "wf-old" {
		t.Errorf("replay result wrong: %+v", result)
	}
	if len(store.created) != 0 {
		t.Errorf("replay must not create a second workflow, got %d", len(store.created))
	}
}

func TestStartPayment_WorkflowCreateFailureRollsBack(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into payment_intent", cols: []string{"idempotency_key"}, rows: [][]driver.Value{{"key-1"}}})
	intents := NewPaymentIntentRepo(db.open())
	store := &recordingWorkflowStore{err: errors.New("instance insert failed")}
	starter := NewWorkflowStarter(db.open(), intents, store, nil)

	if _, err := starter.StartPayment(context.Background(), StartPaymentRequest{IdempotencyKey: "key-1", RequestHash: "hash-1"}, "wf-new"); err == nil {
		t.Fatal("workflow create failure must surface")
	}
	_, commits, rolls := db.counters()
	if commits != 0 || rolls != 1 {
		t.Errorf("tx counters commit:%d rollback:%d, want 0/1", commits, rolls)
	}
}

// --- Consumer wiring + ConsumeDelivery ---

func TestNewConsumer_Chaining(t *testing.T) {
	c := NewConsumer(nil, &fakeApplyResulter{}, &fakeInstanceStatusReader{}, &fakeIntentUpdater{}, &fakeIntentReader{}, &fakeCompletionOutbox{}, messaging.RetryPolicy{})
	db := &fakeDB{}
	intents := NewPaymentIntentRepo(db.open())
	outbox := NewPgCompletionOutbox(db.open())
	if c.WithAtomicCompletion(intents, outbox) != c {
		t.Error("WithAtomicCompletion must return the same consumer for chaining")
	}
	if c.WithReversalAutoDetection(&fakeInstanceMetaReader{}, &fakeIntentReversalMarker{}) != c {
		t.Error("WithReversalAutoDetection must return the same consumer for chaining")
	}
}

func TestConsumeDelivery_NilDBFailsClosed(t *testing.T) {
	engine := &fakeApplyResulter{}
	c := NewConsumer(nil, engine, nil, nil, nil, nil, messaging.RetryPolicy{})
	err := c.ConsumeDelivery(context.Background(), resultDelivery(t, "wf-1"))
	if err == nil {
		t.Fatal("nil db must surface the missing-transaction error, not ack silently")
	}
	if len(engine.Calls()) != 0 {
		t.Errorf("engine calls = %d, want 0", len(engine.Calls()))
	}
}

// TestConsumeDelivery_AtomicPathCommitsStatusAndCompletion drives the full
// outer-Inbox ConsumeDelivery with the atomic (tx-aware) dependencies wired
// over the fake DB: status update and completion outbox commit together.
func TestConsumeDelivery_AtomicPathCommitsStatusAndCompletion(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into inbox_message", affected: 1})
	db.add(queryPlan{marker: "from payment_intent where workflow_id", cols: strings.Split(intentCols, ","), rows: [][]driver.Value{intentRow("key-1", "hash-1", "wf-1", "running")}})
	db.add(queryPlan{marker: "set status = $2", affected: 1})
	db.add(queryPlan{marker: "insert into outbox_message", affected: 1})

	engine := &fakeApplyResulter{}
	statusReader := &fakeInstanceStatusReader{exists: true, status: "succeeded"}
	intentReader := &fakeIntentReader{intent: PaymentIntent{
		WorkflowID: "wf-1", PayerCustomerID: "C-100", Currency: "CNY", AmountMinor: 50000, Status: IntentRunning,
	}}
	updater := &fakeIntentUpdater{}
	intents := NewPaymentIntentRepo(db.open())
	outbox := NewPgCompletionOutbox(db.open())
	c := NewConsumer(db.open(), engine, statusReader, updater, intentReader, outbox, messaging.RetryPolicy{}).
		WithAtomicCompletion(intents, outbox)

	if err := c.ConsumeDelivery(context.Background(), resultDelivery(t, "wf-1")); err != nil {
		t.Fatalf("ConsumeDelivery: %v", err)
	}
	if len(engine.Calls()) != 1 {
		t.Errorf("engine calls = %d, want 1", len(engine.Calls()))
	}
	// The legacy (non-tx) updater must NOT be used on the atomic path.
	if len(updater.Updates()) != 0 {
		t.Errorf("legacy updates = %d, want 0 on the atomic path", len(updater.Updates()))
	}
	// Status update and completion outbox row must both hit the DB.
	if call := db.lastCallWith("set status = $2"); call == nil || call.args[0] != "wf-1" || call.args[1] != "succeeded" {
		t.Errorf("status update wrong: %+v", call)
	}
	if call := db.lastCallWith("insert into outbox_message"); call == nil || call.args[3] != RoutePaymentCompleted {
		t.Errorf("completion outbox row wrong: %+v", call)
	}
	_, commits, rolls := db.counters()
	if commits < 2 || rolls != 0 { // outer Inbox tx + atomic status/emit tx
		t.Errorf("tx counters commit:%d rollback:%d, want >=2/0", commits, rolls)
	}
}

// TestConsumeDelivery_ReversalAutoDetection wires WithReversalAutoDetection so
// a payment-reversal instance reaching succeeded marks the ORIGINAL intent
// reversed inside the delivery tx.
func TestConsumeDelivery_ReversalAutoDetection(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into inbox_message", affected: 1})
	db.add(queryPlan{marker: "set reversed = true", affected: 1})

	engine := &fakeApplyResulter{}
	metaReader := &fakeInstanceMetaReader{meta: InstanceMeta{
		Status: "succeeded",
		Type:   WorkflowReversalType,
		PreparedContext: json.RawMessage(`{"original_workflow_id":"wf-original"}`),
	}}
	marker := &fakeIntentReversalMarker{}
	updater := &fakeIntentUpdater{}
	c := NewConsumer(db.open(), engine, nil, updater, nil, nil, messaging.RetryPolicy{}).
		WithReversalAutoDetection(metaReader, marker)

	if err := c.ConsumeDelivery(context.Background(), resultDelivery(t, "wf-reversal")); err != nil {
		t.Fatalf("ConsumeDelivery: %v", err)
	}
	if calls := marker.Calls(); len(calls) != 1 || calls[0] != "wf-original" {
		t.Errorf("marker calls = %v, want [wf-original]", calls)
	}
}

func TestHandleReversalSuccess_Guards(t *testing.T) {
	ctx := context.Background()

	emptyCtx := &fakeIntentReversalMarker{}
	(&Consumer{intentReversalMarker: emptyCtx}).handleReversalSuccess(ctx, "wf-r", nil)
	if len(emptyCtx.Calls()) != 0 {
		t.Error("empty prepared context must not mark anything")
	}

	badJSON := &fakeIntentReversalMarker{}
	(&Consumer{intentReversalMarker: badJSON}).handleReversalSuccess(ctx, "wf-r", json.RawMessage("{not-json"))
	if len(badJSON.Calls()) != 0 {
		t.Error("malformed prepared context must not mark anything")
	}

	missingOriginal := &fakeIntentReversalMarker{}
	(&Consumer{intentReversalMarker: missingOriginal}).handleReversalSuccess(ctx, "wf-r", json.RawMessage(`{}`))
	if len(missingOriginal.Calls()) != 0 {
		t.Error("missing original_workflow_id must not mark anything")
	}

	markerErr := &fakeIntentReversalMarker{err: errors.New("update failed")}
	(&Consumer{intentReversalMarker: markerErr}).handleReversalSuccess(ctx, "wf-r", json.RawMessage(`{"original_workflow_id":"wf-o"}`))
	if len(markerErr.Calls()) != 1 {
		t.Error("marker must be attempted even when it errors (logged and swallowed)")
	}
}

// --- InstanceStatusRepo ---

func TestInstanceStatusRepo_InstanceStatus(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from workflow_instance", cols: []string{"status"}, rows: [][]driver.Value{{"running"}}})
	r := NewInstanceStatusRepo(db.open())
	status, err := r.InstanceStatus(context.Background(), "wf-1")
	if err != nil || status != "running" {
		t.Fatalf("InstanceStatus = %q, %v", status, err)
	}

	empty := &fakeDB{}
	empty.add(queryPlan{marker: "from workflow_instance", cols: []string{"status"}})
	r2 := NewInstanceStatusRepo(empty.open())
	if _, err := r2.InstanceStatus(context.Background(), "wf-nope"); !errors.Is(err, ErrWorkflowNotFound) {
		t.Fatalf("want ErrWorkflowNotFound, got %v", err)
	}
}

func TestInstanceStatusRepo_InstanceMeta(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from workflow_instance",
		cols:   []string{"status", "type", "prepared_context_json"},
		rows:   [][]driver.Value{{"succeeded", "payment-reversal", []byte(`{"original_workflow_id":"wf-o"}`)}},
	})
	r := NewInstanceStatusRepo(db.open())
	meta, err := r.InstanceMeta(context.Background(), "wf-r")
	if err != nil {
		t.Fatalf("InstanceMeta: %v", err)
	}
	if meta.Status != "succeeded" || meta.Type != "payment-reversal" || string(meta.PreparedContext) == "" {
		t.Errorf("meta wrong: %+v", meta)
	}

	emptyCtx := &fakeDB{}
	emptyCtx.add(queryPlan{
		marker: "from workflow_instance",
		cols:   []string{"status", "type", "prepared_context_json"},
		rows:   [][]driver.Value{{"preparing", "payment-transfer", nil}},
	})
	r2 := NewInstanceStatusRepo(emptyCtx.open())
	meta2, err := r2.InstanceMeta(context.Background(), "wf-1")
	if err != nil || meta2.PreparedContext != nil {
		t.Fatalf("NULL prepared context must yield nil: %+v %v", meta2, err)
	}

	missing := &fakeDB{}
	missing.add(queryPlan{marker: "from workflow_instance", cols: []string{"status"}})
	r3 := NewInstanceStatusRepo(missing.open())
	if _, err := r3.InstanceMeta(context.Background(), "wf-nope"); !errors.Is(err, ErrWorkflowNotFound) {
		t.Fatalf("want ErrWorkflowNotFound, got %v", err)
	}
}

// --- PgCompletionOutbox ---

func TestPgCompletionOutbox_EmitCompletion(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into outbox_message", affected: 1})
	o := NewPgCompletionOutbox(db.open())
	env := sampleEnvelope(t, EventPaymentCompleted, "wf-1")
	if err := o.EmitCompletion(context.Background(), env); err != nil {
		t.Fatalf("EmitCompletion: %v", err)
	}
	call := db.lastCallWith("insert into outbox_message")
	if call == nil || call.args[0] != env.MessageID || call.args[3] != RoutePaymentCompleted {
		t.Errorf("outbox args wrong: %+v", call)
	}
}

func TestPgCompletionOutbox_EmitCompletionInTx_ErrorWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into outbox_message", err: errors.New("insert failed")})
	o := NewPgCompletionOutbox(db.open())
	env := sampleEnvelope(t, EventPaymentCompleted, "wf-1")
	err := o.EmitCompletionInTx(context.Background(), db.open(), env)
	if err == nil || !strings.Contains(err.Error(), "insert failed") {
		t.Fatalf("want wrapped error, got %v", err)
	}
}

// --- OutboxRelay ---

func TestNewOutboxRelay_Defaults(t *testing.T) {
	r := NewOutboxRelay(nil, nil)
	if r.Interval <= 0 || r.BatchSize <= 0 {
		t.Errorf("defaults wrong: interval=%v batch=%d", r.Interval, r.BatchSize)
	}
}

func TestOutboxRelay_Run_GuardsAndCancel(t *testing.T) {
	if err := (&OutboxRelay{}).Run(context.Background()); err == nil {
		t.Error("nil db must fail fast")
	}
	db := &fakeDB{}
	if err := NewOutboxRelay(db.open(), nil).Run(context.Background()); err == nil {
		t.Error("nil publisher must fail fast")
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := NewOutboxRelay(db.open(), &relayPublisherStub{}).Run(ctx); err != nil {
		t.Errorf("Run on cancelled ctx = %v, want nil", err)
	}
}

type relayPublisherStub struct {
	err  error
	route string
}

func (p *relayPublisherStub) PublishTo(_ context.Context, _, routingKey string, _ messaging.Envelope) error {
	p.route = routingKey
	return p.err
}

func TestOutboxRelay_DrainPublishesAndMarksDispatched(t *testing.T) {
	env := sampleEnvelope(t, EventPaymentCompleted, "wf-1")
	body, _ := json.Marshal(env)
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from outbox_message",
		cols:   []string{"message_id", "routing_key", "envelope"},
		rows:   [][]driver.Value{{env.MessageID, RoutePaymentCompleted, []byte(body)}},
	})
	db.add(queryPlan{marker: "update outbox_message", affected: 1})
	pub := &relayPublisherStub{}
	relay := NewOutboxRelay(db.open(), pub)
	if err := relay.drain(context.Background()); err != nil {
		t.Fatalf("drain: %v", err)
	}
	if pub.route != RoutePaymentCompleted {
		t.Errorf("published routing key = %q, want %q", pub.route, RoutePaymentCompleted)
	}
	if call := db.lastCallWith("update outbox_message"); call == nil || call.args[0] != env.MessageID {
		t.Errorf("dispatched update missing: %+v", call)
	}
}

func TestOutboxRelay_DrainPoisonMessageMarked(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from outbox_message",
		cols:   []string{"message_id", "routing_key", "envelope"},
		rows:   [][]driver.Value{{"poison-1", RoutePaymentCompleted, []byte("{not-json")}},
	})
	db.add(queryPlan{marker: "update outbox_message", affected: 1})
	pub := &relayPublisherStub{}
	relay := NewOutboxRelay(db.open(), pub)
	if err := relay.drain(context.Background()); err != nil {
		t.Fatalf("drain must tolerate poison messages: %v", err)
	}
	if pub.route != "" {
		t.Error("poison message must not be published")
	}
	if call := db.lastCallWith("update outbox_message"); call == nil || call.args[0] != "poison-1" {
		t.Errorf("poison message must be marked with last_error: %+v", call)
	}
}

func TestOutboxRelay_DrainPublishFailurePropagates(t *testing.T) {
	env := sampleEnvelope(t, EventPaymentCompleted, "wf-1")
	body, _ := json.Marshal(env)
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from outbox_message",
		cols:   []string{"message_id", "routing_key", "envelope"},
		rows:   [][]driver.Value{{env.MessageID, RoutePaymentCompleted, []byte(body)}},
	})
	relay := NewOutboxRelay(db.open(), &relayPublisherStub{err: errors.New("broker down")})
	err := relay.drain(context.Background())
	if err == nil || !strings.Contains(err.Error(), "broker down") {
		t.Fatalf("want publish failure surfaced, got %v", err)
	}
}

// ---------------------------------------------------------------------------
// fakesql harness (same design as payment/repo/fakesql_test.go; duplicated
// here because this package's tests need their own *sql.DB).
// ---------------------------------------------------------------------------

type queryPlan struct {
	marker   string
	cols     []string
	rows     [][]driver.Value
	err      error
	iterErr  error
	affected int64
}

type fakeDB struct {
	mu      sync.Mutex
	plans   []queryPlan
	calls   []fakeCall
	begins  int
	commits int
	rolls   int
}

type fakeCall struct {
	query string
	args  []driver.Value
}

func (d *fakeDB) add(p queryPlan) { d.plans = append(d.plans, p) }

func (d *fakeDB) plan(query string) *queryPlan {
	lower := strings.ToLower(query)
	for i := range d.plans {
		if strings.Contains(lower, d.plans[i].marker) {
			return &d.plans[i]
		}
	}
	return nil
}

func (d *fakeDB) record(query string, args []driver.NamedValue) {
	vals := make([]driver.Value, len(args))
	for i, a := range args {
		vals[i] = a.Value
	}
	d.mu.Lock()
	d.calls = append(d.calls, fakeCall{query: query, args: vals})
	d.mu.Unlock()
}

func (d *fakeDB) lastCallWith(marker string) *fakeCall {
	d.mu.Lock()
	defer d.mu.Unlock()
	for i := len(d.calls) - 1; i >= 0; i-- {
		if strings.Contains(strings.ToLower(d.calls[i].query), marker) {
			c := d.calls[i]
			return &c
		}
	}
	return nil
}

func (d *fakeDB) counters() (begins, commits, rolls int) {
	d.mu.Lock()
	defer d.mu.Unlock()
	return d.begins, d.commits, d.rolls
}

// open returns a *sql.DB backed by this fake driver.
func (d *fakeDB) open() *sql.DB { return sql.OpenDB(fakeConnector{db: d}) }

type fakeConnector struct{ db *fakeDB }

func (c fakeConnector) Connect(context.Context) (driver.Conn, error) {
	return &fakeConn{db: c.db}, nil
}
func (c fakeConnector) Driver() driver.Driver { return fakeDriver{c.db} }

type fakeDriver struct{ db *fakeDB }

func (fakeDriver) Open(string) (driver.Conn, error) {
	return nil, fmt.Errorf("fakesql: Open not supported, use sql.OpenDB")
}

type fakeConn struct{ db *fakeDB }

func (c *fakeConn) Prepare(string) (driver.Stmt, error) {
	return nil, errors.New("fakesql: Prepare not supported")
}
func (c *fakeConn) Close() error              { return nil }
func (c *fakeConn) Begin() (driver.Tx, error) { return c.BeginTx(context.Background(), driver.TxOptions{}) }
func (c *fakeConn) BeginTx(context.Context, driver.TxOptions) (driver.Tx, error) {
	c.db.mu.Lock()
	c.db.begins++
	c.db.mu.Unlock()
	return fakeTx{db: c.db}, nil
}

func (c *fakeConn) ExecContext(_ context.Context, query string, args []driver.NamedValue) (driver.Result, error) {
	c.db.record(query, args)
	p := c.db.plan(query)
	if p == nil {
		return nil, errors.New("fakesql: no plan for " + query)
	}
	if p.err != nil {
		return nil, p.err
	}
	return driver.RowsAffected(p.affected), nil
}

func (c *fakeConn) QueryContext(_ context.Context, query string, args []driver.NamedValue) (driver.Rows, error) {
	c.db.record(query, args)
	p := c.db.plan(query)
	if p == nil {
		return nil, errors.New("fakesql: no plan for " + query)
	}
	if p.err != nil {
		return nil, p.err
	}
	rows := make([][]driver.Value, len(p.rows))
	copy(rows, p.rows)
	return &fakeRows{cols: p.cols, rows: rows, iterErr: p.iterErr}, nil
}

type fakeTx struct{ db *fakeDB }

func (t fakeTx) Commit() error {
	t.db.mu.Lock()
	t.db.commits++
	t.db.mu.Unlock()
	return nil
}
func (t fakeTx) Rollback() error {
	t.db.mu.Lock()
	t.db.rolls++
	t.db.mu.Unlock()
	return nil
}

type fakeRows struct {
	cols    []string
	rows    [][]driver.Value
	idx     int
	iterErr error
}

func (r *fakeRows) Columns() []string { return r.cols }
func (r *fakeRows) Close() error      { return nil }
func (r *fakeRows) Next(dest []driver.Value) error {
	if r.idx >= len(r.rows) {
		if r.iterErr != nil {
			err := r.iterErr
			r.iterErr = nil
			return err
		}
		return io.EOF
	}
	row := r.rows[r.idx]
	r.idx++
	copy(dest, row)
	return nil
}
