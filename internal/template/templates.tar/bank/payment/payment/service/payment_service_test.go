package service

// Tests for the query-orchestration layer: every method must pass its
// arguments through to the store unchanged and surface the store error.

import (
	"context"
	"errors"
	"testing"

	"bank/payment/payment/domain"
)

type recordingStore struct {
	gotAccountNo, gotFrom, gotTo string
	gotTxnID                     string
	gotMerchantID                string
	gotLimit, gotOffset          int

	err error
}

func (s *recordingStore) ListTransfers(_ context.Context, accountNo, from, to string, limit, offset int) ([]domain.Transfer, error) {
	s.gotAccountNo, s.gotFrom, s.gotTo, s.gotLimit, s.gotOffset = accountNo, from, to, limit, offset
	if s.err != nil {
		return nil, s.err
	}
	return []domain.Transfer{{TxnID: "T1"}}, nil
}

func (s *recordingStore) GetTransfer(_ context.Context, txnID string) (domain.Transfer, error) {
	s.gotTxnID = txnID
	if s.err != nil {
		return domain.Transfer{}, s.err
	}
	return domain.Transfer{TxnID: txnID}, nil
}

func (s *recordingStore) GetTransferParties(_ context.Context, txnID string) (domain.TransferParty, error) {
	s.gotTxnID = txnID
	if s.err != nil {
		return domain.TransferParty{}, s.err
	}
	return domain.TransferParty{TxnID: txnID}, nil
}

func (s *recordingStore) GetMerchant(_ context.Context, id string) (domain.Merchant, error) {
	s.gotMerchantID = id
	if s.err != nil {
		return domain.Merchant{}, s.err
	}
	return domain.Merchant{MerchantID: id}, nil
}

func TestPaymentService_PassesFiltersThrough(t *testing.T) {
	store := &recordingStore{}
	svc := NewPaymentService(store)
	ctx := context.Background()

	if _, err := svc.ListTransfers(ctx, "ACC-1", "2026-07-01", "2026-07-31", 10, 5); err != nil {
		t.Fatal(err)
	}
	if store.gotAccountNo != "ACC-1" || store.gotFrom != "2026-07-01" || store.gotTo != "2026-07-31" || store.gotLimit != 10 || store.gotOffset != 5 {
		t.Errorf("ListTransfers args wrong: %+v", store)
	}
	if _, err := svc.GetTransfer(ctx, "T1"); err != nil {
		t.Fatal(err)
	}
	if store.gotTxnID != "T1" {
		t.Errorf("GetTransfer args wrong: %+v", store)
	}
	if _, err := svc.GetParties(ctx, "T1"); err != nil {
		t.Fatal(err)
	}
	if _, err := svc.GetMerchant(ctx, "M-1"); err != nil {
		t.Fatal(err)
	}
	if store.gotMerchantID != "M-1" {
		t.Errorf("GetMerchant args wrong: %+v", store)
	}
}

func TestPaymentService_SurfacesStoreErrors(t *testing.T) {
	boom := errors.New("boom")
	svc := NewPaymentService(&recordingStore{err: boom})
	ctx := context.Background()

	if _, err := svc.ListTransfers(ctx, "", "", "", 0, 0); !errors.Is(err, boom) {
		t.Errorf("ListTransfers err = %v", err)
	}
	if _, err := svc.GetTransfer(ctx, "x"); !errors.Is(err, boom) {
		t.Errorf("GetTransfer err = %v", err)
	}
	if _, err := svc.GetParties(ctx, "x"); !errors.Is(err, boom) {
		t.Errorf("GetParties err = %v", err)
	}
	if _, err := svc.GetMerchant(ctx, "x"); !errors.Is(err, boom) {
		t.Errorf("GetMerchant err = %v", err)
	}
}
