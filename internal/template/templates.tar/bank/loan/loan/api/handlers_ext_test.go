package api

// Handler tests for the endpoints not covered by handlers_test.go:
// products, balances, overdue listings and non-ErrNoRows error branches.

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"testing"

	"bank/loan/loan/domain"
	"bank/loan/loan/service"
)

// stubRepo lets each test script one outcome per method.
type stubRepo struct {
	products []domain.LoanProduct
	balances []domain.LoanBalance
	overdues []domain.LoanOverdue
	err      error // when set, every call fails with err

	gotFrom, gotTo, gotLoanNo string
	gotOverdueClass           string
}

func (s *stubRepo) ListProducts(context.Context) ([]domain.LoanProduct, error) {
	if s.err != nil {
		return nil, s.err
	}
	return s.products, nil
}

func (s *stubRepo) ListAccounts(context.Context, string, string, int, int) ([]domain.LoanAccount, error) {
	if s.err != nil {
		return nil, s.err
	}
	return nil, nil
}

func (s *stubRepo) GetAccount(context.Context, string) (domain.LoanAccount, error) {
	if s.err != nil {
		return domain.LoanAccount{}, s.err
	}
	return domain.LoanAccount{}, sql.ErrNoRows
}

func (s *stubRepo) ListBalances(_ context.Context, from, to, loanNo string, _, _ int) ([]domain.LoanBalance, error) {
	s.gotFrom, s.gotTo, s.gotLoanNo = from, to, loanNo
	if s.err != nil {
		return nil, s.err
	}
	return s.balances, nil
}

func (s *stubRepo) ListOverdue(_ context.Context, overdueClass, from, to string, _, _ int) ([]domain.LoanOverdue, error) {
	s.gotOverdueClass, s.gotFrom, s.gotTo = overdueClass, from, to
	if s.err != nil {
		return nil, s.err
	}
	return s.overdues, nil
}

func (s *stubRepo) GetProfile(context.Context, string) (domain.LoanProfile, error) {
	if s.err != nil {
		return domain.LoanProfile{}, s.err
	}
	return domain.LoanProfile{}, sql.ErrNoRows
}

func TestListProducts_OK(t *testing.T) {
	h := &Handlers{Svc: service.NewLoanService(&stubRepo{products: []domain.LoanProduct{{
		ProductCode: "LP-CONS", ProductName: "Consumer Loan", MaxTerm: 36,
		MaxAmount: domain.NewMoneyFromCents(50000000), RateType: "fixed", Status: "active",
	}}})}
	code, body := get(t, NewRouter(h), "/api/v1/loan/products")
	if code != 200 || !strings.Contains(body, `"product_code":"LP-CONS"`) ||
		!strings.Contains(body, `"max_amount":"500000.00"`) || !strings.Contains(body, `"max_term":36`) {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestListProducts_EmptyIsArray(t *testing.T) {
	h := &Handlers{Svc: service.NewLoanService(&stubRepo{})}
	code, body := get(t, NewRouter(h), "/api/v1/loan/products")
	if code != 200 || !strings.Contains(body, `"products":[]`) {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestListProducts_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewLoanService(&stubRepo{err: errors.New("db down")})}
	code, body := get(t, NewRouter(h), "/api/v1/loan/products")
	if code != 500 || !strings.Contains(body, "db down") {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestListBalances_OK(t *testing.T) {
	repo := &stubRepo{balances: []domain.LoanBalance{{
		LoanNo: "LN0000001", BizDate: "2026-07-01",
		PrincipalBalance: domain.NewMoneyFromCents(800000), InterestReceivable: domain.NewMoneyFromCents(3625),
	}}}
	h := &Handlers{Svc: service.NewLoanService(repo)}
	code, body := get(t, NewRouter(h), "/api/v1/loan/balances?from=2026-07-01&to=2026-07-31&loan_no=LN0000001&limit=5&offset=1")
	if code != 200 || !strings.Contains(body, `"principal_balance":"8000.00"`) || !strings.Contains(body, `"interest_receivable":"36.25"`) {
		t.Errorf("code=%d body=%s", code, body)
	}
	if repo.gotFrom != "2026-07-01" || repo.gotTo != "2026-07-31" || repo.gotLoanNo != "LN0000001" {
		t.Errorf("filters not passed through: %+v", repo)
	}
}

func TestListBalances_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewLoanService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/loan/balances"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestListOverdue_OK(t *testing.T) {
	repo := &stubRepo{overdues: []domain.LoanOverdue{{
		OverdueID: "OD-1", BizDate: "2026-07-01", LoanNo: "LN0000001",
		OverdueDays: 31, OverdueClass: "substandard", OverdueAmount: domain.NewMoneyFromCents(123456),
	}}}
	h := &Handlers{Svc: service.NewLoanService(repo)}
	code, body := get(t, NewRouter(h), "/api/v1/loan/overdue?overdue_class=substandard&from=2026-07-01&to=2026-07-31")
	if code != 200 || !strings.Contains(body, `"overdue_amount":"1234.56"`) || !strings.Contains(body, `"overdue_days":31`) {
		t.Errorf("code=%d body=%s", code, body)
	}
	if repo.gotOverdueClass != "substandard" || repo.gotFrom != "2026-07-01" {
		t.Errorf("filters not passed through: %+v", repo)
	}
}

func TestListOverdue_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewLoanService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/loan/overdue"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestGetAccount_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewLoanService(&stubRepo{err: errors.New("conn refused")})}
	code, _ := get(t, NewRouter(h), "/api/v1/loan/accounts/LN0000001")
	if code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestGetProfile_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewLoanService(&stubRepo{err: errors.New("conn refused")})}
	code, _ := get(t, NewRouter(h), "/api/v1/loan/accounts/LN0000001/profile")
	if code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestGetProfile_NotFoundIs404(t *testing.T) {
	h := &Handlers{Svc: service.NewLoanService(&stubRepo{})}
	code, _ := get(t, NewRouter(h), "/api/v1/loan/accounts/LN9999999/profile")
	if code != 404 {
		t.Errorf("code=%d want 404", code)
	}
}
