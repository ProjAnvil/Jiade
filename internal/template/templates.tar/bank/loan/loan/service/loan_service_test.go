package service

// Tests for the query-orchestration layer: every method must pass its
// arguments through to the store unchanged and surface the store error.

import (
	"context"
	"errors"
	"testing"

	"bank/loan/loan/domain"
)

type recordingStore struct {
	productCode string
	status      string
	offset      int
	limit       int
	from        string
	to          string
	loanNo      string
	overdueCls  string

	err error
}

func (s *recordingStore) ListProducts(context.Context) ([]domain.LoanProduct, error) {
	if s.err != nil {
		return nil, s.err
	}
	return []domain.LoanProduct{{ProductCode: "LP-CONS"}}, nil
}

func (s *recordingStore) ListAccounts(_ context.Context, productCode, status string, offset, limit int) ([]domain.LoanAccount, error) {
	s.productCode, s.status, s.offset, s.limit = productCode, status, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return []domain.LoanAccount{{LoanNo: "LN0000001"}}, nil
}

func (s *recordingStore) GetAccount(_ context.Context, loanNo string) (domain.LoanAccount, error) {
	s.loanNo = loanNo
	if s.err != nil {
		return domain.LoanAccount{}, s.err
	}
	return domain.LoanAccount{LoanNo: loanNo}, nil
}

func (s *recordingStore) ListBalances(_ context.Context, from, to, loanNo string, offset, limit int) ([]domain.LoanBalance, error) {
	s.from, s.to, s.loanNo, s.offset, s.limit = from, to, loanNo, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return []domain.LoanBalance{{LoanNo: loanNo}}, nil
}

func (s *recordingStore) ListOverdue(_ context.Context, overdueClass, from, to string, offset, limit int) ([]domain.LoanOverdue, error) {
	s.overdueCls, s.from, s.to, s.offset, s.limit = overdueClass, from, to, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return []domain.LoanOverdue{{LoanNo: "LN0000001"}}, nil
}

func (s *recordingStore) GetProfile(_ context.Context, loanNo string) (domain.LoanProfile, error) {
	s.loanNo = loanNo
	if s.err != nil {
		return domain.LoanProfile{}, s.err
	}
	return domain.LoanProfile{LoanNo: loanNo}, nil
}

func TestLoanService_PassesFiltersThrough(t *testing.T) {
	store := &recordingStore{}
	svc := NewLoanService(store)
	ctx := context.Background()

	prods, err := svc.ListProducts(ctx)
	if err != nil || len(prods) != 1 || prods[0].ProductCode != "LP-CONS" {
		t.Fatalf("ListProducts: %+v %v", prods, err)
	}

	if _, err := svc.ListAccounts(ctx, "LP-CONS", "disbursed", 10, 5); err != nil {
		t.Fatal(err)
	}
	if store.productCode != "LP-CONS" || store.status != "disbursed" || store.offset != 10 || store.limit != 5 {
		t.Errorf("ListAccounts args wrong: %+v", store)
	}

	acc, err := svc.GetAccount(ctx, "LN0000001")
	if err != nil || acc.LoanNo != "LN0000001" {
		t.Fatalf("GetAccount: %+v %v", acc, err)
	}

	if _, err := svc.ListBalances(ctx, "2026-07-01", "2026-07-31", "LN0000001", 3, 7); err != nil {
		t.Fatal(err)
	}
	if store.from != "2026-07-01" || store.to != "2026-07-31" || store.loanNo != "LN0000001" || store.offset != 3 || store.limit != 7 {
		t.Errorf("ListBalances args wrong: %+v", store)
	}

	if _, err := svc.ListOverdue(ctx, "substandard", "2026-07-01", "2026-07-31", 0, 20); err != nil {
		t.Fatal(err)
	}
	if store.overdueCls != "substandard" || store.limit != 20 {
		t.Errorf("ListOverdue args wrong: %+v", store)
	}

	prof, err := svc.Profile(ctx, "LN0000001")
	if err != nil || prof.LoanNo != "LN0000001" {
		t.Fatalf("Profile: %+v %v", prof, err)
	}
}

func TestLoanService_SurfacesStoreErrors(t *testing.T) {
	boom := errors.New("boom")
	svc := NewLoanService(&recordingStore{err: boom})
	ctx := context.Background()

	if _, err := svc.ListProducts(ctx); !errors.Is(err, boom) {
		t.Errorf("ListProducts err = %v", err)
	}
	if _, err := svc.ListAccounts(ctx, "", "", 0, 0); !errors.Is(err, boom) {
		t.Errorf("ListAccounts err = %v", err)
	}
	if _, err := svc.GetAccount(ctx, "x"); !errors.Is(err, boom) {
		t.Errorf("GetAccount err = %v", err)
	}
	if _, err := svc.ListBalances(ctx, "", "", "", 0, 0); !errors.Is(err, boom) {
		t.Errorf("ListBalances err = %v", err)
	}
	if _, err := svc.ListOverdue(ctx, "", "", "", 0, 0); !errors.Is(err, boom) {
		t.Errorf("ListOverdue err = %v", err)
	}
	if _, err := svc.Profile(ctx, "x"); !errors.Is(err, boom) {
		t.Errorf("Profile err = %v", err)
	}
}
