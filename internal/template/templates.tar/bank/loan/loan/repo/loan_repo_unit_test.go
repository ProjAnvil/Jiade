package repo

// Unit tests for LoanRepo query/scan logic using the fakesql harness in
// fakesql_test.go (no live PostgreSQL). Live-DB round-trips remain in the
// integration-gated loan_repo_test.go.

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"errors"
	"strings"
	"testing"

	"bank/loan/loan/domain"
	"bank/lib/serviceclient"
)

type stubCustomerReader struct {
	customer serviceclient.Customer
	err      error
	calls    int
}

func (s *stubCustomerReader) GetCustomer(_ context.Context, customerID, _ string) (serviceclient.Customer, error) {
	s.calls++
	if s.err != nil {
		return serviceclient.Customer{}, s.err
	}
	return serviceclient.Customer{CustomerID: customerID, Name: "Alice", CustomerType: "personal"}, nil
}

const accountCols = "loan_no,cust_id,product_code,ccy,principal,balance,rate,start_biz_date,mature_date,term_months,status,guarantee_type,branch_code"

func accountRow(loanNo string) []driver.Value {
	return []driver.Value{loanNo, "C0000001", "LP-MORT", "CNY", "10000.00", "9000.00", "0.043500", "2026-01-10", "2036-01-10", int64(120), "disbursed", "credit", "BR-01"}
}

func TestListProducts_MapsRowsAndParsesAmount(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from loan_product",
		cols:   []string{"product_code", "product_name", "loan_type", "rate_type", "min_rate", "max_rate", "max_term", "max_amount", "status"},
		rows: [][]driver.Value{
			{"LP-CONS", "Consumer Loan", "consumer", "fixed", "0.035000", "0.055000", int64(36), "500000.00", "active"},
			{"LP-MORT", "Mortgage", "mortgage", nil, nil, nil, int64(360), nil, nil},
		},
	})
	r := NewLoanRepo(db.open(), &stubCustomerReader{})
	prods, err := r.ListProducts(context.Background())
	if err != nil {
		t.Fatalf("ListProducts: %v", err)
	}
	if len(prods) != 2 {
		t.Fatalf("products = %d, want 2", len(prods))
	}
	got := prods[0]
	if got.ProductCode != "LP-CONS" || got.MaxTerm != 36 || got.MaxAmount != domain.NewMoneyFromCents(50000000) {
		t.Errorf("product mapping wrong: %+v", got)
	}
	if got.RateType != "fixed" || got.Status != "active" {
		t.Errorf("nullable strings wrong: %+v", got)
	}
	// NULL amount column parses as 0.
	if prods[1].MaxAmount.Cents() != 0 {
		t.Errorf("NULL max_amount should parse as 0, got %d", prods[1].MaxAmount.Cents())
	}
	if prods[1].RateType != "" || prods[1].Status != "" {
		t.Errorf("NULL should map to empty strings: %+v", prods[1])
	}
}

func TestListProducts_BadAmountFails(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from loan_product",
		cols:   []string{"product_code", "product_name", "loan_type", "rate_type", "min_rate", "max_rate", "max_term", "max_amount", "status"},
		rows:   [][]driver.Value{{"LP-CONS", "n", "t", nil, nil, nil, int64(1), "not-a-number", nil}},
	})
	r := NewLoanRepo(db.open(), &stubCustomerReader{})
	if _, err := r.ListProducts(context.Background()); err == nil || !strings.Contains(err.Error(), "not-a-number") {
		t.Fatalf("want parse error, got %v", err)
	}
}

func TestListProducts_QueryErrorWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from loan_product", err: errors.New("boom")})
	r := NewLoanRepo(db.open(), &stubCustomerReader{})
	_, err := r.ListProducts(context.Background())
	if err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("want wrapped query error, got %v", err)
	}
}

func TestListAccounts_DefaultsLimitTo50(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from loan_account", cols: strings.Split(accountCols, ","), rows: [][]driver.Value{accountRow("LN0000001")}})
	r := NewLoanRepo(db.open(), &stubCustomerReader{})
	list, err := r.ListAccounts(context.Background(), "", "", 0, -3)
	if err != nil {
		t.Fatalf("ListAccounts: %v", err)
	}
	if len(list) != 1 {
		t.Fatalf("accounts = %d, want 1", len(list))
	}
	a := list[0]
	if a.LoanNo != "LN0000001" || a.Principal.Cents() != 1000000 || a.Balance.Cents() != 900000 || a.TermMonths != 120 {
		t.Errorf("account mapping wrong: %+v", a)
	}
	if a.Rate != "0.043500" || a.GuaranteeType != "credit" || a.BranchCode != "BR-01" {
		t.Errorf("nullable mapping wrong: %+v", a)
	}
	// limit<=0 must be defaulted to 50 before hitting SQL.
	if call := db.lastCallWith("from loan_account"); call == nil || call.args[2] != int64(50) {
		t.Errorf("default limit not applied: %+v", call)
	}
}

func TestListAccounts_RowsIterationError(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from loan_account", cols: strings.Split(accountCols, ","), iterErr: errors.New("mid-iteration failure")})
	r := NewLoanRepo(db.open(), &stubCustomerReader{})
	if _, err := r.ListAccounts(context.Background(), "", "", 0, 10); err == nil || !strings.Contains(err.Error(), "mid-iteration failure") {
		t.Fatalf("want rows.Err surfaced, got %v", err)
	}
}

func TestGetAccount_FoundAndMissing(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from loan_account", cols: strings.Split(accountCols, ","), rows: [][]driver.Value{accountRow("LN0000001")}})
	r := NewLoanRepo(db.open(), &stubCustomerReader{})
	a, err := r.GetAccount(context.Background(), "LN0000001")
	if err != nil || a.LoanNo != "LN0000001" {
		t.Fatalf("GetAccount: %+v %v", a, err)
	}

	empty := &fakeDB{}
	empty.add(queryPlan{marker: "from loan_account", cols: strings.Split(accountCols, ",")})
	r2 := NewLoanRepo(empty.open(), &stubCustomerReader{})
	if _, err := r2.GetAccount(context.Background(), "LN-NOPE"); !errors.Is(err, sql.ErrNoRows) {
		t.Fatalf("want sql.ErrNoRows wrapped, got %v", err)
	}
}

func TestGetAccount_BadPrincipalFails(t *testing.T) {
	db := &fakeDB{}
	bad := accountRow("LN0000001")
	bad[4] = "oops"
	db.add(queryPlan{marker: "from loan_account", cols: strings.Split(accountCols, ","), rows: [][]driver.Value{bad}})
	r := NewLoanRepo(db.open(), &stubCustomerReader{})
	if _, err := r.GetAccount(context.Background(), "LN0000001"); err == nil {
		t.Fatal("bad principal should fail scan")
	}
}

func TestListBalances_MapsRows(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from loan_balance",
		cols:   []string{"loan_no", "biz_date", "principal_balance", "interest_receivable"},
		rows:   [][]driver.Value{{"LN0000001", "2026-07-01", "8000.00", "36.25"}},
	})
	r := NewLoanRepo(db.open(), &stubCustomerReader{})
	list, err := r.ListBalances(context.Background(), "2026-07-01", "2026-07-31", "LN0000001", 0, 10)
	if err != nil {
		t.Fatalf("ListBalances: %v", err)
	}
	if len(list) != 1 || list[0].PrincipalBalance.Cents() != 800000 || list[0].InterestReceivable.Cents() != 3625 {
		t.Fatalf("balance mapping wrong: %+v", list)
	}
	if call := db.lastCallWith("from loan_balance"); call == nil || call.args[0] != "2026-07-01" || call.args[2] != "LN0000001" {
		t.Errorf("filters not passed through: %+v", call)
	}
}

func TestListBalances_BadInterestFails(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from loan_balance",
		cols:   []string{"loan_no", "biz_date", "principal_balance", "interest_receivable"},
		rows:   [][]driver.Value{{"LN0000001", "2026-07-01", "1.00", "bad"}},
	})
	r := NewLoanRepo(db.open(), &stubCustomerReader{})
	if _, err := r.ListBalances(context.Background(), "", "", "", 0, 10); err == nil {
		t.Fatal("bad interest amount should fail")
	}
}

func TestListOverdue_MapsRowsAndDefaultsLimit(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from loan_overdue",
		cols:   []string{"overdue_id", "biz_date", "loan_no", "overdue_days", "overdue_class", "overdue_amount"},
		rows:   [][]driver.Value{{"OD-1", "2026-07-01", "LN0000001", int64(31), "substandard", "1234.56"}},
	})
	r := NewLoanRepo(db.open(), &stubCustomerReader{})
	list, err := r.ListOverdue(context.Background(), "substandard", "", "", 0, 0)
	if err != nil {
		t.Fatalf("ListOverdue: %v", err)
	}
	if len(list) != 1 || list[0].OverdueDays != 31 || list[0].OverdueAmount.Cents() != 123456 {
		t.Fatalf("overdue mapping wrong: %+v", list)
	}
	if call := db.lastCallWith("from loan_overdue"); call == nil || call.args[0] != "substandard" || call.args[3] != int64(50) {
		t.Errorf("args wrong: %+v", call)
	}
}

func TestListOverdue_BadAmountFails(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from loan_overdue",
		cols:   []string{"overdue_id", "biz_date", "loan_no", "overdue_days", "overdue_class", "overdue_amount"},
		rows:   [][]driver.Value{{"OD-1", "2026-07-01", "LN0000001", int64(31), "sub", "xx"}},
	})
	r := NewLoanRepo(db.open(), &stubCustomerReader{})
	if _, err := r.ListOverdue(context.Background(), "", "", "", 0, 10); err == nil {
		t.Fatal("bad overdue amount should fail")
	}
}

func TestGetProfile_JoinsCustomer(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from loan_account where loan_no=$1",
		cols:   []string{"loan_no", "cust_id", "principal", "balance", "rate", "status"},
		rows:   [][]driver.Value{{"LN0000001", "C0000001", "10000.00", "9000.00", "0.043500", "disbursed"}},
	})
	cust := &stubCustomerReader{}
	r := NewLoanRepo(db.open(), cust)
	p, err := r.GetProfile(context.Background(), "LN0000001")
	if err != nil {
		t.Fatalf("GetProfile: %v", err)
	}
	if p.CustName != "Alice" || p.CustType != "personal" || p.Rate != "0.043500" || p.Status != "disbursed" {
		t.Errorf("profile mapping wrong: %+v", p)
	}
	if p.Principal.Cents() != 1000000 || p.Balance.Cents() != 900000 {
		t.Errorf("profile money wrong: %+v", p)
	}
	if cust.calls != 1 {
		t.Errorf("customer calls = %d, want 1", cust.calls)
	}
}

func TestGetProfile_CustomerFailureWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from loan_account where loan_no=$1",
		cols:   []string{"loan_no", "cust_id", "principal", "balance", "rate", "status"},
		rows:   [][]driver.Value{{"LN0000001", "C0000001", "1.00", "1.00", "r", "s"}},
	})
	r := NewLoanRepo(db.open(), &stubCustomerReader{err: errors.New("grpc down")})
	_, err := r.GetProfile(context.Background(), "LN0000001")
	if err == nil || !strings.Contains(err.Error(), "grpc down") {
		t.Fatalf("want customer error surfaced, got %v", err)
	}
}

func TestGetProfile_MissingRowFails(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from loan_account where loan_no=$1", cols: []string{"loan_no"}})
	r := NewLoanRepo(db.open(), &stubCustomerReader{})
	if _, err := r.GetProfile(context.Background(), "LN-NOPE"); err == nil {
		t.Fatal("missing row should fail")
	}
}
