package service

// Tests for the query-orchestration layer: every method must pass its
// arguments through to the store unchanged and surface the store error.

import (
	"context"
	"errors"
	"testing"

	"bank/wealth/wealth/domain"
)

type recordingStore struct {
	productCode, from, to string
	custID                 string
	holdingID              string
	offset, limit          int

	err error
}

func (s *recordingStore) ListProducts(context.Context) ([]domain.WealthProduct, error) {
	if s.err != nil {
		return nil, s.err
	}
	return []domain.WealthProduct{{ProductCode: "WP-FIX-90"}}, nil
}

func (s *recordingStore) ListNav(_ context.Context, productCode, from, to string) ([]domain.WealthNav, error) {
	s.productCode, s.from, s.to = productCode, from, to
	if s.err != nil {
		return nil, s.err
	}
	return []domain.WealthNav{{ProductCode: productCode}}, nil
}

func (s *recordingStore) ListHoldings(_ context.Context, custID string, offset, limit int) ([]domain.WealthHolding, error) {
	s.custID, s.offset, s.limit = custID, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return []domain.WealthHolding{{HoldingID: "WH-1"}}, nil
}

func (s *recordingStore) ListOrders(_ context.Context, custID, productCode, from, to string, offset, limit int) ([]domain.WealthOrder, error) {
	s.custID, s.productCode, s.from, s.to, s.offset, s.limit = custID, productCode, from, to, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return []domain.WealthOrder{{OrderID: "WO-1"}}, nil
}

func (s *recordingStore) ListIncomes(_ context.Context, holdingID, from, to string, offset, limit int) ([]domain.WealthIncome, error) {
	s.holdingID, s.from, s.to, s.offset, s.limit = holdingID, from, to, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return []domain.WealthIncome{{IncomeID: "WI-1"}}, nil
}

func (s *recordingStore) GetHoldingProfile(_ context.Context, holdingID string) (domain.WealthProfile, error) {
	s.holdingID = holdingID
	if s.err != nil {
		return domain.WealthProfile{}, s.err
	}
	return domain.WealthProfile{HoldingID: holdingID}, nil
}

func TestWealthService_PassesFiltersThrough(t *testing.T) {
	store := &recordingStore{}
	svc := NewWealthService(store)
	ctx := context.Background()

	prods, err := svc.ListProducts(ctx)
	if err != nil || len(prods) != 1 {
		t.Fatalf("ListProducts: %+v %v", prods, err)
	}

	if _, err := svc.ListNav(ctx, "WP-FIX-90", "2026-07-01", "2026-07-31"); err != nil {
		t.Fatal(err)
	}
	if store.productCode != "WP-FIX-90" || store.from != "2026-07-01" || store.to != "2026-07-31" {
		t.Errorf("ListNav args wrong: %+v", store)
	}

	if _, err := svc.ListHoldings(ctx, "C0000001", 10, 5); err != nil {
		t.Fatal(err)
	}
	if store.custID != "C0000001" || store.offset != 10 || store.limit != 5 {
		t.Errorf("ListHoldings args wrong: %+v", store)
	}

	if _, err := svc.ListOrders(ctx, "C0000001", "WP-FIX-90", "2026-07-01", "2026-07-31", 1, 2); err != nil {
		t.Fatal(err)
	}
	if store.custID != "C0000001" || store.productCode != "WP-FIX-90" || store.offset != 1 || store.limit != 2 {
		t.Errorf("ListOrders args wrong: %+v", store)
	}

	if _, err := svc.ListIncomes(ctx, "WH-1", "2026-07-01", "2026-07-31", 3, 4); err != nil {
		t.Fatal(err)
	}
	if store.holdingID != "WH-1" || store.limit != 4 {
		t.Errorf("ListIncomes args wrong: %+v", store)
	}

	p, err := svc.HoldingProfile(ctx, "WH-1")
	if err != nil || p.HoldingID != "WH-1" {
		t.Fatalf("HoldingProfile: %+v %v", p, err)
	}
}

func TestWealthService_SurfacesStoreErrors(t *testing.T) {
	boom := errors.New("boom")
	svc := NewWealthService(&recordingStore{err: boom})
	ctx := context.Background()

	if _, err := svc.ListProducts(ctx); !errors.Is(err, boom) {
		t.Errorf("ListProducts err = %v", err)
	}
	if _, err := svc.ListNav(ctx, "", "", ""); !errors.Is(err, boom) {
		t.Errorf("ListNav err = %v", err)
	}
	if _, err := svc.ListHoldings(ctx, "", 0, 0); !errors.Is(err, boom) {
		t.Errorf("ListHoldings err = %v", err)
	}
	if _, err := svc.ListOrders(ctx, "", "", "", "", 0, 0); !errors.Is(err, boom) {
		t.Errorf("ListOrders err = %v", err)
	}
	if _, err := svc.ListIncomes(ctx, "", "", "", 0, 0); !errors.Is(err, boom) {
		t.Errorf("ListIncomes err = %v", err)
	}
	if _, err := svc.HoldingProfile(ctx, "x"); !errors.Is(err, boom) {
		t.Errorf("HoldingProfile err = %v", err)
	}
}
