package repo

// Unit tests for WealthRepo query/scan logic using the fakesql harness in
// fakesql_test.go (no live PostgreSQL). Live-DB round-trips remain in the
// integration-gated wealth_repo_test.go.

import (
	"context"
	"database/sql/driver"
	"errors"
	"strings"
	"testing"

	"bank/lib/serviceclient"
)

type stubCustomerReader struct {
	customer serviceclient.Customer
	err      error
	calls    int
}

func (s *stubCustomerReader) GetCustomer(_ context.Context, customerID, _ string) (serviceclient.Customer, error) {
	s.calls++
	if s.err != nil {
		return serviceclient.Customer{}, s.err
	}
	return serviceclient.Customer{CustomerID: customerID, Name: "Alice", CustomerType: "personal"}, nil
}

func TestListProducts_MapsRowsAndParsesMinAmount(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from wealth_product",
		cols:   []string{"product_code", "product_name", "product_type", "risk_level", "expected_return", "min_amount", "term_days", "start_biz_date", "end_biz_date", "status"},
		rows: [][]driver.Value{
			{"WP-FIX-90", "Fixed 90d", "fixed", "R2", "0.035000", "50000.00", int64(90), "2026-01-01", "2026-04-01", "active"},
			{"WP-NULL", "Nullable", "fund", nil, nil, nil, int64(0), nil, nil, nil},
		},
	})
	r := NewWealthRepo(db.open(), &stubCustomerReader{})
	prods, err := r.ListProducts(context.Background())
	if err != nil {
		t.Fatalf("ListProducts: %v", err)
	}
	if len(prods) != 2 {
		t.Fatalf("products = %d, want 2", len(prods))
	}
	if prods[0].MinAmount.Cents() != 5000000 || prods[0].TermDays != 90 || prods[0].RiskLevel != "R2" || prods[0].Status != "active" {
		t.Errorf("product mapping wrong: %+v", prods[0])
	}
	if prods[1].MinAmount.Cents() != 0 || prods[1].RiskLevel != "" || prods[1].StartBizDate != "" {
		t.Errorf("NULL columns should map to zero values: %+v", prods[1])
	}
}

func TestListProducts_BadMinAmountFails(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from wealth_product",
		cols:   []string{"product_code", "product_name", "product_type", "risk_level", "expected_return", "min_amount", "term_days", "start_biz_date", "end_biz_date", "status"},
		rows:   [][]driver.Value{{"WP-1", "n", "t", nil, nil, "NaN", int64(1), nil, nil, nil}},
	})
	r := NewWealthRepo(db.open(), &stubCustomerReader{})
	if _, err := r.ListProducts(context.Background()); err == nil {
		t.Fatal("bad min_amount should fail")
	}
}

func TestListNav_MapsRowsAndPassesFilters(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from wealth_nav",
		cols:   []string{"product_code", "biz_date", "nav", "accum_nav"},
		rows:   [][]driver.Value{{"WP-FIX-90", "2026-07-01", "1.023400", "1.254300"}},
	})
	r := NewWealthRepo(db.open(), &stubCustomerReader{})
	navs, err := r.ListNav(context.Background(), "WP-FIX-90", "2026-07-01", "2026-07-31")
	if err != nil {
		t.Fatalf("ListNav: %v", err)
	}
	if len(navs) != 1 || navs[0].Nav != "1.023400" || navs[0].AccumNav != "1.254300" {
		t.Fatalf("nav mapping wrong: %+v", navs)
	}
	call := db.lastCallWith("from wealth_nav")
	if call == nil || call.args[0] != "WP-FIX-90" || call.args[1] != "2026-07-01" || call.args[2] != "2026-07-31" {
		t.Errorf("filters not passed through: %+v", call)
	}
}

func TestListNav_QueryErrorWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from wealth_nav", err: errors.New("boom")})
	r := NewWealthRepo(db.open(), &stubCustomerReader{})
	if _, err := r.ListNav(context.Background(), "", "", ""); err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("want wrapped error, got %v", err)
	}
}

const holdingCols = "holding_id,cust_id,account_no,product_code,ccy,share,cost,current_value,biz_date"

func holdingRow(id string) []driver.Value {
	return []driver.Value{id, "C0000001", "ACCT-1", "WP-FIX-90", "CNY", "100.0000", "50000.00", "51234.56", "2026-07-01"}
}

func TestListHoldings_MapsRowsAndDefaultsLimit(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from wealth_holding", cols: strings.Split(holdingCols, ","), rows: [][]driver.Value{holdingRow("WH-1")}})
	r := NewWealthRepo(db.open(), &stubCustomerReader{})
	list, err := r.ListHoldings(context.Background(), "C0000001", 0, 0)
	if err != nil {
		t.Fatalf("ListHoldings: %v", err)
	}
	if len(list) != 1 {
		t.Fatalf("holdings = %d, want 1", len(list))
	}
	h := list[0]
	if h.HoldingID != "WH-1" || h.Cost.Cents() != 5000000 || h.CurrentValue.Cents() != 5123456 || h.Share != "100.0000" {
		t.Errorf("holding mapping wrong: %+v", h)
	}
	if call := db.lastCallWith("from wealth_holding"); call == nil || call.args[0] != "C0000001" || call.args[1] != int64(50) {
		t.Errorf("default limit not applied: %+v", call)
	}
}

func TestListHoldings_BadCostFails(t *testing.T) {
	db := &fakeDB{}
	bad := holdingRow("WH-1")
	bad[6] = "bad"
	db.add(queryPlan{marker: "from wealth_holding", cols: strings.Split(holdingCols, ","), rows: [][]driver.Value{bad}})
	r := NewWealthRepo(db.open(), &stubCustomerReader{})
	if _, err := r.ListHoldings(context.Background(), "", 0, 10); err == nil {
		t.Fatal("bad cost should fail scan")
	}
}

func TestListOrders_MapsRowsAndDefaultsLimit(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from wealth_order",
		cols:   []string{"order_id", "biz_date", "cust_id", "product_code", "account_no", "order_type", "amount", "share", "nav", "status"},
		rows:   [][]driver.Value{{"WO-1", "2026-07-01", "C0000001", "WP-FIX-90", "ACCT-1", "subscribe", "50000.00", "50.0000", "1.000000", "confirmed"}},
	})
	r := NewWealthRepo(db.open(), &stubCustomerReader{})
	list, err := r.ListOrders(context.Background(), "C0000001", "WP-FIX-90", "2026-07-01", "2026-07-31", 0, 0)
	if err != nil {
		t.Fatalf("ListOrders: %v", err)
	}
	if len(list) != 1 || list[0].Amount.Cents() != 5000000 || list[0].Share != "50.0000" || list[0].Status != "confirmed" {
		t.Fatalf("order mapping wrong: %+v", list)
	}
	if call := db.lastCallWith("from wealth_order"); call == nil || call.args[0] != "C0000001" || call.args[4] != int64(50) {
		t.Errorf("args wrong: %+v", call)
	}
}

func TestListOrders_BadAmountFails(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from wealth_order",
		cols:   []string{"order_id", "biz_date", "cust_id", "product_code", "account_no", "order_type", "amount", "share", "nav", "status"},
		rows:   [][]driver.Value{{"WO-1", "2026-07-01", "C1", "WP", "A", "subscribe", "bad", nil, nil, nil}},
	})
	r := NewWealthRepo(db.open(), &stubCustomerReader{})
	if _, err := r.ListOrders(context.Background(), "", "", "", "", 0, 10); err == nil {
		t.Fatal("bad amount should fail")
	}
}

func TestListIncomes_MapsRows(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from wealth_income",
		cols:   []string{"income_id", "biz_date", "holding_id", "income_type", "amount"},
		rows:   [][]driver.Value{{"WI-1", "2026-07-02", "WH-1", "daily", "12.34"}},
	})
	r := NewWealthRepo(db.open(), &stubCustomerReader{})
	list, err := r.ListIncomes(context.Background(), "WH-1", "2026-07-01", "2026-07-31", 0, 10)
	if err != nil {
		t.Fatalf("ListIncomes: %v", err)
	}
	if len(list) != 1 || list[0].Amount.Cents() != 1234 || list[0].IncomeType != "daily" {
		t.Fatalf("income mapping wrong: %+v", list)
	}
	if call := db.lastCallWith("from wealth_income"); call == nil || call.args[0] != "WH-1" {
		t.Errorf("args wrong: %+v", call)
	}
}

func TestListIncomes_BadAmountFails(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from wealth_income",
		cols:   []string{"income_id", "biz_date", "holding_id", "income_type", "amount"},
		rows:   [][]driver.Value{{"WI-1", "2026-07-02", "WH-1", "daily", "oops"}},
	})
	r := NewWealthRepo(db.open(), &stubCustomerReader{})
	if _, err := r.ListIncomes(context.Background(), "", "", "", 0, 10); err == nil {
		t.Fatal("bad amount should fail")
	}
}

func TestGetHoldingProfile_JoinsCustomer(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from wealth_holding where holding_id=$1",
		cols:   []string{"holding_id", "cust_id", "product_code", "share", "current_value"},
		rows:   [][]driver.Value{{"WH-1", "C0000001", "WP-FIX-90", "100.0000", "51234.56"}},
	})
	cust := &stubCustomerReader{}
	r := NewWealthRepo(db.open(), cust)
	p, err := r.GetHoldingProfile(context.Background(), "WH-1")
	if err != nil {
		t.Fatalf("GetHoldingProfile: %v", err)
	}
	if p.CustName != "Alice" || p.CustType != "personal" || p.CurrentValue.Cents() != 5123456 || p.Share != "100.0000" {
		t.Errorf("profile mapping wrong: %+v", p)
	}
	if cust.calls != 1 {
		t.Errorf("customer calls = %d, want 1", cust.calls)
	}
}

func TestGetHoldingProfile_CustomerFailureWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from wealth_holding where holding_id=$1",
		cols:   []string{"holding_id", "cust_id", "product_code", "share", "current_value"},
		rows:   [][]driver.Value{{"WH-1", "C0000001", "WP-FIX-90", "1", "1.00"}},
	})
	r := NewWealthRepo(db.open(), &stubCustomerReader{err: errors.New("grpc down")})
	_, err := r.GetHoldingProfile(context.Background(), "WH-1")
	if err == nil || !strings.Contains(err.Error(), "grpc down") {
		t.Fatalf("want customer error surfaced, got %v", err)
	}
}

func TestGetHoldingProfile_MissingRowFails(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from wealth_holding where holding_id=$1", cols: []string{"holding_id"}})
	r := NewWealthRepo(db.open(), &stubCustomerReader{})
	if _, err := r.GetHoldingProfile(context.Background(), "WH-NOPE"); err == nil {
		t.Fatal("missing row should fail")
	}
}
