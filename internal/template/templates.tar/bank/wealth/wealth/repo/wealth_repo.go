// Package repo is the data access layer of wealth service: this library SQL + customer gRPC query.
package repo

import (
	"bank/lib/serviceclient"
	"bank/wealth/wealth/domain"
	"context"
	"database/sql"
	"fmt"
)

// WealthRepo wealth storage. This library only queries wealth_*.
type WealthRepo struct {
	db       *sql.DB
	customer serviceclient.CustomerReader
}

// NewWealthRepo Constructs WealthRepo.
func NewWealthRepo(db *sql.DB, customer serviceclient.CustomerReader) *WealthRepo {
	return &WealthRepo{
		db:       db,
		customer: customer,
	}
}

// ListProducts lists financial products (static full quantity).
func (r *WealthRepo) ListProducts(ctx context.Context) ([]domain.WealthProduct, error) {
	rows, err := r.db.QueryContext(ctx,
		`SELECT product_code,product_name,product_type,risk_level,expected_return,min_amount,term_days,start_biz_date,end_biz_date,status
		FROM wealth_product ORDER BY product_code`)
	if err != nil {
		return nil, fmt.Errorf("repo: list wealth products: %w", err)
	}
	defer rows.Close()
	var out []domain.WealthProduct
	for rows.Next() {
		var p domain.WealthProduct
		var risk, ret, minAmt, start, end, status sql.NullString
		if err := rows.Scan(&p.ProductCode, &p.ProductName, &p.ProductType, &risk, &ret, &minAmt, &p.TermDays, &start, &end, &status); err != nil {
			return nil, fmt.Errorf("repo: list wealth products scan: %w", err)
		}
		p.RiskLevel, p.ExpectedReturn, p.StartBizDate, p.EndBizDate, p.Status = risk.String, ret.String, start.String, end.String, status.String
		m, err := domain.ParseCents(minAmt.String)
		if err != nil {
			return nil, fmt.Errorf("repo: parse minimum purchase amount: %w", err)
		}
		p.MinAmount = m
		out = append(out, p)
	}
	if err := rows.Err(); err != nil {
		return out, fmt.Errorf("repo: list wealth products: %w", err)
	}
	return out, nil
}

// ListNav checks the daily net value by product/date range (no limit if empty; no pagination if the sequence volume is small).
func (r *WealthRepo) ListNav(ctx context.Context, productCode, from, to string) ([]domain.WealthNav, error) {
	rows, err := r.db.QueryContext(ctx,
		`SELECT product_code,biz_date,nav,accum_nav FROM wealth_nav
		WHERE ($1='' OR product_code=$1)
		AND (NULLIF($2,'') IS NULL OR biz_date >= NULLIF($2,'')::date)
		AND (NULLIF($3,'') IS NULL OR biz_date <= NULLIF($3,'')::date)
		ORDER BY biz_date, product_code`, productCode, from, to)
	if err != nil {
		return nil, fmt.Errorf("repo: list nav: %w", err)
	}
	defer rows.Close()
	var out []domain.WealthNav
	for rows.Next() {
		var n domain.WealthNav
		var nav, accum sql.NullString
		if err := rows.Scan(&n.ProductCode, &n.BizDate, &nav, &accum); err != nil {
			return nil, fmt.Errorf("repo: list nav scan: %w", err)
		}
		n.Nav, n.AccumNav = nav.String, accum.String
		out = append(out, n)
	}
	if err := rows.Err(); err != nil {
		return out, fmt.Errorf("repo: list nav: %w", err)
	}
	return out, nil
}

// ListHoldings filters holdings by customer (no limit if empty), pagination. limit<=0 takes 50.
func (r *WealthRepo) ListHoldings(ctx context.Context, custID string, offset, limit int) ([]domain.WealthHolding, error) {
	if limit <= 0 {
		limit = 50
	}
	rows, err := r.db.QueryContext(ctx,
		`SELECT holding_id,cust_id,account_no,product_code,ccy,share,cost,current_value,biz_date
		FROM wealth_holding WHERE ($1='' OR cust_id=$1) ORDER BY holding_id LIMIT $2 OFFSET $3`, custID, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("repo: list holdings: %w", err)
	}
	defer rows.Close()
	var out []domain.WealthHolding
	for rows.Next() {
		h, err := scanHolding(rows.Scan)
		if err != nil {
			return nil, fmt.Errorf("repo: list holdings scan: %w", err)
		}
		out = append(out, h)
	}
	if err := rows.Err(); err != nil {
		return out, fmt.Errorf("repo: list holdings: %w", err)
	}
	return out, nil
}

// ListOrders Check orders by customer/product/date range (no limit if empty), pagination.
func (r *WealthRepo) ListOrders(ctx context.Context, custID, productCode, from, to string, offset, limit int) ([]domain.WealthOrder, error) {
	if limit <= 0 {
		limit = 50
	}
	rows, err := r.db.QueryContext(ctx,
		`SELECT order_id,biz_date,cust_id,product_code,account_no,order_type,amount,share,nav,status
		FROM wealth_order WHERE ($1='' OR cust_id=$1) AND ($2='' OR product_code=$2)
		AND (NULLIF($3,'') IS NULL OR biz_date >= NULLIF($3,'')::date)
		AND (NULLIF($4,'') IS NULL OR biz_date <= NULLIF($4,'')::date)
		ORDER BY biz_date DESC, order_id LIMIT $5 OFFSET $6`, custID, productCode, from, to, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("repo: list wealth orders: %w", err)
	}
	defer rows.Close()
	var out []domain.WealthOrder
	for rows.Next() {
		var o domain.WealthOrder
		var amt, share, nav, status sql.NullString
		if err := rows.Scan(&o.OrderID, &o.BizDate, &o.CustID, &o.ProductCode, &o.AccountNo, &o.OrderType, &amt, &share, &nav, &status); err != nil {
			return nil, fmt.Errorf("repo: list wealth orders scan: %w", err)
		}
		m, err := domain.ParseCents(amt.String)
		if err != nil {
			return nil, fmt.Errorf("repo: parse order amount: %w", err)
		}
		o.Amount, o.Share, o.Nav, o.Status = m, share.String, nav.String, status.String
		out = append(out, o)
	}
	if err := rows.Err(); err != nil {
		return out, fmt.Errorf("repo: list wealth orders: %w", err)
	}
	return out, nil
}

// ListIncomes Check the income by position/date range (no limit if empty), paging.
func (r *WealthRepo) ListIncomes(ctx context.Context, holdingID, from, to string, offset, limit int) ([]domain.WealthIncome, error) {
	if limit <= 0 {
		limit = 50
	}
	rows, err := r.db.QueryContext(ctx,
		`SELECT income_id,biz_date,holding_id,income_type,amount FROM wealth_income
		WHERE ($1='' OR holding_id=$1)
		AND (NULLIF($2,'') IS NULL OR biz_date >= NULLIF($2,'')::date)
		AND (NULLIF($3,'') IS NULL OR biz_date <= NULLIF($3,'')::date)
		ORDER BY biz_date DESC, income_id LIMIT $4 OFFSET $5`, holdingID, from, to, limit, offset)
	if err != nil {
		return nil, fmt.Errorf("repo: list wealth incomes: %w", err)
	}
	defer rows.Close()
	var out []domain.WealthIncome
	for rows.Next() {
		var inc domain.WealthIncome
		var itype, amt sql.NullString
		if err := rows.Scan(&inc.IncomeID, &inc.BizDate, &inc.HoldingID, &itype, &amt); err != nil {
			return nil, fmt.Errorf("repo: list wealth incomes scan: %w", err)
		}
		m, err := domain.ParseCents(amt.String)
		if err != nil {
			return nil, fmt.Errorf("repo: parse income amount: %w", err)
		}
		inc.IncomeType, inc.Amount = itype.String, m
		out = append(out, inc)
	}
	if err := rows.Err(); err != nil {
		return out, fmt.Errorf("repo: list wealth incomes: %w", err)
	}
	return out, nil
}

// GetHoldingProfile checks the library's holdings, and then calls customer to obtain the customer's name/type.
func (r *WealthRepo) GetHoldingProfile(ctx context.Context, holdingID string) (domain.WealthProfile, error) {
	var p domain.WealthProfile
	var share, cv sql.NullString
	err := r.db.QueryRowContext(ctx,
		`SELECT holding_id,cust_id,product_code,share,current_value FROM wealth_holding WHERE holding_id=$1`, holdingID).
		Scan(&p.HoldingID, &p.CustID, &p.ProductCode, &share, &cv)
	if err != nil {
		return domain.WealthProfile{}, fmt.Errorf("repo: query holding profile %s: %w", holdingID, err)
	}
	m, err := domain.ParseCents(cv.String)
	if err != nil {
		return domain.WealthProfile{}, fmt.Errorf("repo: parse holding market value: %w", err)
	}
	customer, err := r.customer.GetCustomer(ctx, p.CustID, serviceclient.RequestID(ctx))
	if err != nil {
		return domain.WealthProfile{}, fmt.Errorf("repo: query customer %s from customer: %w", p.CustID, err)
	}
	p.Share, p.CurrentValue, p.CustName, p.CustType = share.String, m, customer.Name, customer.CustomerType
	return p, nil
}

// scanHolding scans a single row wealth_holding (scan function is injected by QueryRow or Rows).
func scanHolding(scan func(dest ...any) error) (domain.WealthHolding, error) {
	var h domain.WealthHolding
	var share, cost, cv sql.NullString
	if err := scan(&h.HoldingID, &h.CustID, &h.AccountNo, &h.ProductCode, &h.Ccy, &share, &cost, &cv, &h.BizDate); err != nil {
		return domain.WealthHolding{}, err
	}
	var err error
	if h.Cost, err = domain.ParseCents(cost.String); err != nil {
		return domain.WealthHolding{}, fmt.Errorf("parse holding cost: %w", err)
	}
	if h.CurrentValue, err = domain.ParseCents(cv.String); err != nil {
		return domain.WealthHolding{}, fmt.Errorf("parse holding market value: %w", err)
	}
	h.Share = share.String
	return h, nil
}
