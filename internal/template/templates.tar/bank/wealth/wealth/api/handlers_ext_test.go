package api

// Handler tests for the endpoints not covered by handlers_test.go:
// products, nav, orders, incomes listings and error branches.

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"testing"

	"bank/wealth/wealth/domain"
	"bank/wealth/wealth/service"
)

// stubRepo lets each test script one outcome per method.
type stubRepo struct {
	products []domain.WealthProduct
	navs     []domain.WealthNav
	orders   []domain.WealthOrder
	incomes  []domain.WealthIncome
	err      error // when set, every call fails with err

	gotProductCode, gotFrom, gotTo string
	gotCustID                      string
	gotHoldingID                   string
}

func (s *stubRepo) ListProducts(context.Context) ([]domain.WealthProduct, error) {
	if s.err != nil {
		return nil, s.err
	}
	return s.products, nil
}

func (s *stubRepo) ListNav(_ context.Context, productCode, from, to string) ([]domain.WealthNav, error) {
	s.gotProductCode, s.gotFrom, s.gotTo = productCode, from, to
	if s.err != nil {
		return nil, s.err
	}
	return s.navs, nil
}

func (s *stubRepo) ListHoldings(context.Context, string, int, int) ([]domain.WealthHolding, error) {
	if s.err != nil {
		return nil, s.err
	}
	return nil, nil
}

func (s *stubRepo) ListOrders(_ context.Context, custID, productCode, from, to string, _, _ int) ([]domain.WealthOrder, error) {
	s.gotCustID, s.gotProductCode, s.gotFrom, s.gotTo = custID, productCode, from, to
	if s.err != nil {
		return nil, s.err
	}
	return s.orders, nil
}

func (s *stubRepo) ListIncomes(_ context.Context, holdingID, from, to string, _, _ int) ([]domain.WealthIncome, error) {
	s.gotHoldingID, s.gotFrom, s.gotTo = holdingID, from, to
	if s.err != nil {
		return nil, s.err
	}
	return s.incomes, nil
}

func (s *stubRepo) GetHoldingProfile(context.Context, string) (domain.WealthProfile, error) {
	if s.err != nil {
		return domain.WealthProfile{}, s.err
	}
	return domain.WealthProfile{}, sql.ErrNoRows
}

func TestListProducts_OK(t *testing.T) {
	h := &Handlers{Svc: service.NewWealthService(&stubRepo{products: []domain.WealthProduct{{
		ProductCode: "WP-FIX-90", ProductName: "Fixed 90d", RiskLevel: "R2",
		MinAmount: domain.NewMoneyFromCents(5000000), TermDays: 90, Status: "active",
	}}})}
	code, body := get(t, NewRouter(h), "/api/v1/wealth/products")
	if code != 200 || !strings.Contains(body, `"product_code":"WP-FIX-90"`) ||
		!strings.Contains(body, `"min_amount":"50000.00"`) || !strings.Contains(body, `"term_days":90`) {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestListProducts_EmptyIsArray(t *testing.T) {
	h := &Handlers{Svc: service.NewWealthService(&stubRepo{})}
	code, body := get(t, NewRouter(h), "/api/v1/wealth/products")
	if code != 200 || !strings.Contains(body, `"products":[]`) {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestListProducts_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewWealthService(&stubRepo{err: errors.New("db down")})}
	code, body := get(t, NewRouter(h), "/api/v1/wealth/products")
	if code != 500 || !strings.Contains(body, "db down") {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestListNav_OK(t *testing.T) {
	repo := &stubRepo{navs: []domain.WealthNav{{
		ProductCode: "WP-FIX-90", BizDate: "2026-07-01", Nav: "1.023400", AccumNav: "1.254300",
	}}}
	h := &Handlers{Svc: service.NewWealthService(repo)}
	code, body := get(t, NewRouter(h), "/api/v1/wealth/nav?product_code=WP-FIX-90&from=2026-07-01&to=2026-07-31")
	if code != 200 || !strings.Contains(body, `"nav":"1.023400"`) || !strings.Contains(body, `"accum_nav":"1.254300"`) {
		t.Errorf("code=%d body=%s", code, body)
	}
	if repo.gotProductCode != "WP-FIX-90" || repo.gotFrom != "2026-07-01" || repo.gotTo != "2026-07-31" {
		t.Errorf("filters not passed through: %+v", repo)
	}
}

func TestListNav_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewWealthService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/wealth/nav"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestListOrders_OK(t *testing.T) {
	repo := &stubRepo{orders: []domain.WealthOrder{{
		OrderID: "WO-1", BizDate: "2026-07-01", CustID: "C0000001", ProductCode: "WP-FIX-90",
		OrderType: "subscribe", Amount: domain.NewMoneyFromCents(5000000), Share: "50.0000", Status: "confirmed",
	}}}
	h := &Handlers{Svc: service.NewWealthService(repo)}
	code, body := get(t, NewRouter(h), "/api/v1/wealth/orders?cust_id=C0000001&product_code=WP-FIX-90&from=2026-07-01&to=2026-07-31")
	if code != 200 || !strings.Contains(body, `"amount":"50000.00"`) || !strings.Contains(body, `"share":"50.0000"`) {
		t.Errorf("code=%d body=%s", code, body)
	}
	if repo.gotCustID != "C0000001" || repo.gotProductCode != "WP-FIX-90" {
		t.Errorf("filters not passed through: %+v", repo)
	}
}

func TestListOrders_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewWealthService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/wealth/orders"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestListIncomes_OK(t *testing.T) {
	repo := &stubRepo{incomes: []domain.WealthIncome{{
		IncomeID: "WI-1", BizDate: "2026-07-02", HoldingID: "WH-1", IncomeType: "daily",
		Amount: domain.NewMoneyFromCents(1234),
	}}}
	h := &Handlers{Svc: service.NewWealthService(repo)}
	code, body := get(t, NewRouter(h), "/api/v1/wealth/incomes?holding_id=WH-1&from=2026-07-01&to=2026-07-31")
	if code != 200 || !strings.Contains(body, `"amount":"12.34"`) || !strings.Contains(body, `"income_type":"daily"`) {
		t.Errorf("code=%d body=%s", code, body)
	}
	if repo.gotHoldingID != "WH-1" {
		t.Errorf("filters not passed through: %+v", repo)
	}
}

func TestListIncomes_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewWealthService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/wealth/incomes"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestGetHoldingProfile_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewWealthService(&stubRepo{err: errors.New("conn refused")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/wealth/holdings/WH-1/profile"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}
