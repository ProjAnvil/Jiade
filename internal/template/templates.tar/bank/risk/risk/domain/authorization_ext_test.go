package domain

// Edge-case tests for the authorization helpers not fully covered by
// authorization_test.go: DecisionLabel mapping and the nil/empty branches of
// the matched-rules JSON codec.

import "testing"

func TestDecisionLabel(t *testing.T) {
	tests := []struct {
		status AuthorizationStatus
		want   string
	}{
		{AuthStatusAuthorized, "approved"},
		{AuthStatusRejected, "rejected"},
		{AuthStatusPending, ""},
		{AuthStatusVoided, ""},
	}
	for _, tc := range tests {
		a := PaymentAuthorization{Status: tc.status}
		if got := a.DecisionLabel(); got != tc.want {
			t.Errorf("DecisionLabel(%q) = %q, want %q", tc.status, got, tc.want)
		}
	}
}

func TestEncodeMatchedRules_NilYieldsEmptyArray(t *testing.T) {
	b, err := EncodeMatchedRules(nil)
	if err != nil {
		t.Fatalf("EncodeMatchedRules(nil): %v", err)
	}
	if string(b) != "[]" {
		t.Errorf("EncodeMatchedRules(nil) = %s, want [] (NOT NULL column constraint)", b)
	}
}

func TestDecodeMatchedRules_EmptyAndNullYieldNil(t *testing.T) {
	for _, raw := range [][]byte{nil, {}} {
		rules, err := DecodeMatchedRules(raw)
		if err != nil || rules != nil {
			t.Errorf("DecodeMatchedRules(%#v) = %#v, %v; want nil, nil", raw, rules, err)
		}
	}
}

func TestDecodeMatchedRules_BadJSONFails(t *testing.T) {
	if _, err := DecodeMatchedRules([]byte("{not-json")); err == nil {
		t.Error("DecodeMatchedRules must fail on malformed JSON")
	}
}
