package api

// Handler tests for ListEvents, ListRules, ListBlacklists and the error
// branches not covered by handlers_test.go (which covers healthz, GetEvent).

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"testing"

	"bank/risk/risk/domain"
	"bank/risk/risk/service"
)

// stubRepo lets each test script one outcome per method.
type stubRepo struct {
	events      []domain.RiskEvent
	rules       []domain.RiskRule
	blacklists  []domain.Blacklist
	err         error

	gotFrom, gotTo, gotRuleID, gotAction string
	gotCustID                            string
	gotOffset, gotLimit                  int
}

func (s *stubRepo) ListEvents(_ context.Context, from, to, ruleID, action string, offset, limit int) ([]domain.RiskEvent, error) {
	s.gotFrom, s.gotTo, s.gotRuleID, s.gotAction, s.gotOffset, s.gotLimit = from, to, ruleID, action, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return s.events, nil
}

func (s *stubRepo) GetEvent(context.Context, string) (domain.RiskEventDetail, error) {
	if s.err != nil {
		return domain.RiskEventDetail{}, s.err
	}
	return domain.RiskEventDetail{}, sql.ErrNoRows
}

func (s *stubRepo) ListRules(context.Context) ([]domain.RiskRule, error) {
	if s.err != nil {
		return nil, s.err
	}
	return s.rules, nil
}

func (s *stubRepo) ListBlacklists(_ context.Context, custID string, offset, limit int) ([]domain.Blacklist, error) {
	s.gotCustID, s.gotOffset, s.gotLimit = custID, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return s.blacklists, nil
}

func TestListEvents_OK(t *testing.T) {
	repo := &stubRepo{events: []domain.RiskEvent{{
		EventID: "E1", BizDate: "2026-07-01", CustID: "C0000001", RuleID: "R-KYC",
		RiskScore: "85.000000", ActionTaken: "reject", Summary: "KYC inactive",
	}}}
	h := &Handlers{Svc: service.NewRiskService(repo)}
	code, body := get(t, NewRouter(h), "/api/v1/risk/events?from=2026-07-01&to=2026-07-31&rule_id=R-KYC&action=reject&offset=1&limit=2")
	if code != 200 || !strings.Contains(body, `"event_id":"E1"`) || !strings.Contains(body, `"action_taken":"reject"`) {
		t.Errorf("code=%d body=%s", code, body)
	}
	if repo.gotFrom != "2026-07-01" || repo.gotTo != "2026-07-31" || repo.gotRuleID != "R-KYC" || repo.gotAction != "reject" || repo.gotLimit != 2 {
		t.Errorf("filters not passed through: %+v", repo)
	}
}

func TestListEvents_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewRiskService(&stubRepo{err: errors.New("db down")})}
	code, body := get(t, NewRouter(h), "/api/v1/risk/events")
	if code != 500 || !strings.Contains(body, "db down") {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestListRules_OK(t *testing.T) {
	h := &Handlers{Svc: service.NewRiskService(&stubRepo{rules: []domain.RiskRule{{
		RuleID: "R-KYC", RuleName: "KYC gate", RuleType: "kyc", Action: "reject", Status: "active",
	}}})}
	code, body := get(t, NewRouter(h), "/api/v1/risk/rules")
	if code != 200 || !strings.Contains(body, `"RuleID":"R-KYC"`) || !strings.Contains(body, `"Action":"reject"`) {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestListRules_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewRiskService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/risk/rules"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestListBlacklists_OK(t *testing.T) {
	repo := &stubRepo{blacklists: []domain.Blacklist{{
		ListID: "B1", CustID: "C0000001", EntityType: "customer", Status: "active",
	}}}
	h := &Handlers{Svc: service.NewRiskService(repo)}
	code, body := get(t, NewRouter(h), "/api/v1/risk/blacklists?cust_id=C0000001&offset=4&limit=6")
	if code != 200 || !strings.Contains(body, `"ListID":"B1"`) || !strings.Contains(body, `"Status":"active"`) {
		t.Errorf("code=%d body=%s", code, body)
	}
	if repo.gotCustID != "C0000001" || repo.gotOffset != 4 || repo.gotLimit != 6 {
		t.Errorf("filters not passed through: %+v", repo)
	}
}

func TestListBlacklists_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewRiskService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/risk/blacklists"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestGetEvent_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewRiskService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/risk/events/E1"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}
