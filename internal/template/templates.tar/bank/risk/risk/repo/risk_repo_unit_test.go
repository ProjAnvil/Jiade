package repo

// Unit tests for RiskRepo and AuthorizationRepo query/scan logic using the
// fakesql harness in fakesql_test.go (no live PostgreSQL). Live-DB
// round-trips remain in the integration-gated *_test.go files.

import (
	"context"
	"database/sql/driver"
	"errors"
	"strings"
	"testing"
	"time"

	"bank/lib/serviceclient"
	"bank/risk/risk/domain"
	"bank/risk/risk/service"
)

type stubCustomerReader struct {
	customer serviceclient.Customer
	err      error
	calls    int
}

func (s *stubCustomerReader) GetCustomer(_ context.Context, customerID, _ string) (serviceclient.Customer, error) {
	s.calls++
	if s.err != nil {
		return serviceclient.Customer{}, s.err
	}
	return serviceclient.Customer{CustomerID: customerID, Name: "Alice", CustomerType: "personal"}, nil
}

const eventCols = "event_id,biz_date,cust_id,account_no,rule_id,risk_score,action_taken,txn_ref,summary"

func eventRow(id string) []driver.Value {
	return []driver.Value{id, "2026-07-01", "C0000001", "6222000000000001", "R-KYC", "0.850000", "reject", "TX-1", "KYC inactive"}
}

func TestListEvents_MapsRowsAndDefaultsLimit(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from risk_event", cols: strings.Split(eventCols, ","), rows: [][]driver.Value{
		eventRow("E1"),
		{"E2", "2026-07-02", nil, nil, nil, nil, nil, nil, nil},
	}})
	r := NewRiskRepo(db.open(), &stubCustomerReader{})
	list, err := r.ListEvents(context.Background(), "2026-07-01", "2026-07-31", "R-KYC", "reject", 0, 0)
	if err != nil {
		t.Fatalf("ListEvents: %v", err)
	}
	if len(list) != 2 {
		t.Fatalf("events = %d, want 2", len(list))
	}
	e := list[0]
	if e.EventID != "E1" || e.RuleID != "R-KYC" || e.RiskScore != "0.850000" || e.ActionTaken != "reject" {
		t.Errorf("event mapping wrong: %+v", e)
	}
	if list[1].CustID != "" || list[1].Summary != "" {
		t.Errorf("NULL event columns should map to empty: %+v", list[1])
	}
	if call := db.lastCallWith("from risk_event"); call == nil || call.args[2] != "R-KYC" || call.args[3] != "reject" || call.args[4] != int64(50) {
		t.Errorf("default limit not applied: %+v", call)
	}
}

func TestListEvents_QueryErrorWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from risk_event", err: errors.New("boom")})
	r := NewRiskRepo(db.open(), &stubCustomerReader{})
	if _, err := r.ListEvents(context.Background(), "", "", "", "", 0, 10); err == nil || !strings.Contains(err.Error(), "boom") {
		t.Fatalf("want wrapped error, got %v", err)
	}
}

func TestGetEvent_JoinsCustomerWhenPresent(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from risk_event where event_id=$1", cols: strings.Split(eventCols, ","), rows: [][]driver.Value{eventRow("E1")}})
	cust := &stubCustomerReader{}
	r := NewRiskRepo(db.open(), cust)
	d, err := r.GetEvent(context.Background(), "E1")
	if err != nil {
		t.Fatalf("GetEvent: %v", err)
	}
	if d.CustName != "Alice" || d.CustType != "personal" || d.RuleID != "R-KYC" {
		t.Errorf("detail mapping wrong: %+v", d)
	}
	if cust.calls != 1 {
		t.Errorf("customer calls = %d, want 1", cust.calls)
	}
}

func TestGetEvent_NoCustomerSkipsJoin(t *testing.T) {
	db := &fakeDB{}
	row := eventRow("E2")
	row[2] = nil // cust_id NULL: the customer join must be skipped
	db.add(queryPlan{marker: "from risk_event where event_id=$1", cols: strings.Split(eventCols, ","), rows: [][]driver.Value{row}})
	cust := &stubCustomerReader{}
	r := NewRiskRepo(db.open(), cust)
	d, err := r.GetEvent(context.Background(), "E2")
	if err != nil {
		t.Fatalf("GetEvent: %v", err)
	}
	if d.CustID != "" || d.CustName != "" {
		t.Errorf("event without customer must have empty join fields: %+v", d)
	}
	if cust.calls != 0 {
		t.Errorf("customer calls = %d, want 0", cust.calls)
	}
}

func TestGetEvent_CustomerFailureWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from risk_event where event_id=$1", cols: strings.Split(eventCols, ","), rows: [][]driver.Value{eventRow("E1")}})
	r := NewRiskRepo(db.open(), &stubCustomerReader{err: errors.New("grpc down")})
	if _, err := r.GetEvent(context.Background(), "E1"); err == nil || !strings.Contains(err.Error(), "grpc down") {
		t.Fatalf("want customer error surfaced, got %v", err)
	}
}

func TestListRules_MapsRows(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from risk_rule",
		cols:   []string{"rule_id", "rule_name", "rule_type", "condition_json", "threshold", "action", "status"},
		rows:   [][]driver.Value{{"R-KYC", "KYC gate", "kyc", `{"kyc":"pending"}`, "0.00", "reject", "active"}},
	})
	r := NewRiskRepo(db.open(), &stubCustomerReader{})
	rules, err := r.ListRules(context.Background())
	if err != nil {
		t.Fatalf("ListRules: %v", err)
	}
	if len(rules) != 1 || rules[0].RuleID != "R-KYC" || rules[0].ConditionJSON != `{"kyc":"pending"}` || rules[0].Action != "reject" {
		t.Fatalf("rule mapping wrong: %+v", rules)
	}
}

func TestListBlacklists_MapsRowsAndDefaultsLimit(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from blacklist",
		cols:   []string{"list_id", "cust_id", "entity_type", "reason", "effective_biz_date", "expire_date", "status"},
		rows:   [][]driver.Value{{"B1", "C0000001", "customer", "fraud", "2026-01-01", "2099-12-31", "active"}},
	})
	r := NewRiskRepo(db.open(), &stubCustomerReader{})
	list, err := r.ListBlacklists(context.Background(), "C0000001", 0, 0)
	if err != nil {
		t.Fatalf("ListBlacklists: %v", err)
	}
	if len(list) != 1 || list[0].ListID != "B1" || list[0].CustID != "C0000001" || list[0].Status != "active" {
		t.Fatalf("blacklist mapping wrong: %+v", list)
	}
	if call := db.lastCallWith("from blacklist"); call == nil || call.args[0] != "C0000001" || call.args[1] != int64(50) {
		t.Errorf("default limit not applied: %+v", call)
	}
}

// --- AuthorizationRepo ---

const authCols = "authorization_id,workflow_id,idempotency_key,customer_id,amount_cents,currency,status,matched_rules,context_digest,created_at,updated_at"

var testNow = time.Date(2026, 7, 31, 12, 0, 0, 0, time.UTC)

func authRow(id string) []driver.Value {
	return []driver.Value{id, "wf-1", "idem-1", "C0000001", int64(10000), "CNY", "authorized", `["R-KYC"]`, "digest-1", testNow, testNow}
}

func TestAuthorizationRepo_InsertExec(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into payment_authorization", affected: 1})
	r := NewAuthorizationRepo()
	a := domain.PaymentAuthorization{
		AuthorizationID: "auth-1", WorkflowID: "wf-1", IdempotencyKey: "idem-1",
		CustomerID: "C0000001", AmountCents: 10000, Currency: "CNY",
		Status: domain.AuthStatusAuthorized, MatchedRuleIDs: nil,
		CreatedAt: testNow, UpdatedAt: testNow,
	}
	if err := r.Insert(context.Background(), db.open(), a); err != nil {
		t.Fatalf("Insert: %v", err)
	}
	// Nil matched rules must be encoded as [] (NOT NULL column constraint).
	if call := db.lastCallWith("insert into payment_authorization"); call == nil || string(call.args[7].([]byte)) != "[]" {
		t.Errorf("nil matched rules must encode as []: %+v", call)
	}
}

func TestAuthorizationRepo_InsertErrorWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into payment_authorization", err: errors.New("unique violation")})
	r := NewAuthorizationRepo()
	a := domain.PaymentAuthorization{AuthorizationID: "auth-1", CreatedAt: testNow, UpdatedAt: testNow}
	err := r.Insert(context.Background(), db.open(), a)
	if err == nil || !strings.Contains(err.Error(), "unique violation") {
		t.Fatalf("want wrapped error, got %v", err)
	}
}

func TestAuthorizationRepo_GetByID(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "where authorization_id = $1", cols: strings.Split(authCols, ","), rows: [][]driver.Value{authRow("auth-1")}})
	r := NewAuthorizationRepo()
	a, err := r.GetByID(context.Background(), db.open(), "auth-1")
	if err != nil {
		t.Fatalf("GetByID: %v", err)
	}
	if a.AuthorizationID != "auth-1" || a.Status != domain.AuthStatusAuthorized || a.ContextDigest != "digest-1" {
		t.Errorf("authorization mapping wrong: %+v", a)
	}
	if len(a.MatchedRuleIDs) != 1 || a.MatchedRuleIDs[0] != "R-KYC" {
		t.Errorf("matched rules wrong: %+v", a.MatchedRuleIDs)
	}
}

func TestAuthorizationRepo_GetByID_NotFound(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "where authorization_id = $1", cols: strings.Split(authCols, ",")})
	r := NewAuthorizationRepo()
	if _, err := r.GetByID(context.Background(), db.open(), "auth-nope"); !errors.Is(err, service.ErrAuthorizationNotFound) {
		t.Fatalf("want ErrAuthorizationNotFound, got %v", err)
	}
}

func TestAuthorizationRepo_GetByIdempotencyKey(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "where idempotency_key = $1", cols: strings.Split(authCols, ","), rows: [][]driver.Value{authRow("auth-1")}})
	r := NewAuthorizationRepo()
	a, err := r.GetByIdempotencyKey(context.Background(), db.open(), "idem-1")
	if err != nil || a.AuthorizationID != "auth-1" || a.IdempotencyKey != "idem-1" {
		t.Fatalf("GetByIdempotencyKey: %+v %v", a, err)
	}
}

func TestAuthorizationRepo_GetByID_BadRulesJSONFails(t *testing.T) {
	db := &fakeDB{}
	row := authRow("auth-1")
	row[7] = []byte("{not-json")
	db.add(queryPlan{marker: "where authorization_id = $1", cols: strings.Split(authCols, ","), rows: [][]driver.Value{row}})
	r := NewAuthorizationRepo()
	if _, err := r.GetByID(context.Background(), db.open(), "auth-1"); err == nil {
		t.Fatal("malformed matched_rules JSON should fail the scan")
	}
}

func TestAuthorizationRepo_UpdateStatus(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "update payment_authorization", affected: 1})
	r := NewAuthorizationRepo()
	a := domain.PaymentAuthorization{AuthorizationID: "auth-1", Status: domain.AuthStatusVoided, UpdatedAt: testNow}
	if err := r.UpdateStatus(context.Background(), db.open(), a); err != nil {
		t.Fatalf("UpdateStatus: %v", err)
	}
	if call := db.lastCallWith("update payment_authorization"); call == nil || call.args[1] != "voided" {
		t.Errorf("status not passed through: %+v", call)
	}
}

func TestAuthorizationRepo_UpdateStatusErrorWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "update payment_authorization", err: errors.New("deadlock")})
	r := NewAuthorizationRepo()
	a := domain.PaymentAuthorization{AuthorizationID: "auth-1", Status: domain.AuthStatusVoided, UpdatedAt: testNow}
	if err := r.UpdateStatus(context.Background(), db.open(), a); err == nil || !strings.Contains(err.Error(), "deadlock") {
		t.Fatalf("want wrapped error, got %v", err)
	}
}

func TestAuthorizationRepo_IsBlacklisted(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "select exists", cols: []string{"exists"}, rows: [][]driver.Value{{true}}})
	r := NewAuthorizationRepo()
	got, err := r.IsBlacklisted(context.Background(), db.open(), "C0000001")
	if err != nil || !got {
		t.Fatalf("IsBlacklisted = %v, %v; want true, nil", got, err)
	}
}

func TestAuthorizationRepo_IsBlacklisted_False(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "select exists", cols: []string{"exists"}, rows: [][]driver.Value{{false}}})
	r := NewAuthorizationRepo()
	got, err := r.IsBlacklisted(context.Background(), db.open(), "C0000001")
	if err != nil || got {
		t.Fatalf("IsBlacklisted = %v, %v; want false, nil", got, err)
	}
}
