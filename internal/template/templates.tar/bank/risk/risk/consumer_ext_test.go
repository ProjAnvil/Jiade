package risk

// Tests for the consumer's transactional AMQP entry point (ConsumeDelivery),
// the smoke-reject envelope builder, RiskOutbox, and the OutboxRelay drain
// loop. Uses the fakesql harness (bottom of this file) so the tx lifecycle
// runs without PostgreSQL, a stub acknowledger instead of a broker, and the
// stubs already defined in consumer_test.go.

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"encoding/json"
	"errors"
	"io"
	"strings"
	"sync"
	"testing"
	"time"

	amqp "github.com/rabbitmq/amqp091-go"

	"bank/lib/messaging"
	"bank/lib/pg"
	"bank/lib/serviceclient"
	"bank/risk/risk/domain"
	"bank/risk/risk/service"
)

// ---------------------------------------------------------------------------
// Stubs (beyond consumer_test.go's failingStore / capturingOutbox).
// ---------------------------------------------------------------------------

// publishingStub records PublishTo calls for the outbox relay tests.
type publishingStub struct {
	mu    sync.Mutex
	calls []published
	err   error
}

type published struct {
	exchange, routingKey string
}

func (p *publishingStub) PublishTo(_ context.Context, exchange, routingKey string, _ messaging.Envelope) error {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.calls = append(p.calls, published{exchange, routingKey})
	return p.err
}

func (p *publishingStub) publishedTo() []published {
	p.mu.Lock()
	defer p.mu.Unlock()
	out := make([]published, len(p.calls))
	copy(out, p.calls)
	return out
}

// ackingAcknowledger satisfies amqp.Acknowledger.
type ackingAcknowledger struct {
	mu     sync.Mutex
	acked  int
	nacked int
}

func (a *ackingAcknowledger) Ack(uint64, bool) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.acked++
	return nil
}
func (a *ackingAcknowledger) Nack(uint64, bool, bool) error {
	a.mu.Lock()
	defer a.mu.Unlock()
	a.nacked++
	return nil
}
func (a *ackingAcknowledger) Reject(uint64, bool) error { return nil }

func authorizeDelivery(t *testing.T, workflowID string) amqp.Delivery {
	t.Helper()
	payload := authorizePaymentPayload{
		AuthorizationID: "auth-1",
		CustomerID:      "C0000001",
		AmountCents:     10000,
		Currency:        "CNY",
	}
	body, _ := json.Marshal(payload)
	env := makeCommandEnvelope(CmdAuthorizePayment)
	env.WorkflowID = workflowID
	env.Payload = body
	raw, _ := json.Marshal(env)
	return amqp.Delivery{Body: raw, Acknowledger: &ackingAcknowledger{}}
}

// newHappyPathConsumer wires a Consumer over a real AuthorizationService with
// an okStore so the full ConsumeDelivery path (authorize → outbox) succeeds.
func newHappyPathConsumer(t *testing.T) (*Consumer, *capturingOutbox, *fakeDB) {
	t.Helper()
	store := &authStoreStub{}
	goodCustomer := fakeCustomerReader{customer: serviceclient.Customer{
		CustomerID: "C0000001", Name: "Alice", CustomerType: "personal",
		KYCStatus: "passed", Status: "active",
	}}
	svc := service.NewAuthorizationService(store, goodCustomer, fixedNowConsumer)
	outbox := &capturingOutbox{}
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into inbox_message", affected: 1})
	c := &Consumer{db: db.open(), service: svc, outbox: outbox, now: fixedNowConsumer}
	return c, outbox, db
}

// authStoreStub is the happy-path store: idempotency lookups miss, the
// customer is not blacklisted, and writes succeed.
type authStoreStub struct {
	inserts int
	updates int
}

func (s *authStoreStub) Insert(context.Context, pg.DBTX, domain.PaymentAuthorization) error {
	s.inserts++
	return nil
}
func (s *authStoreStub) GetByID(context.Context, pg.DBTX, string) (domain.PaymentAuthorization, error) {
	return domain.PaymentAuthorization{}, service.ErrAuthorizationNotFound
}
func (s *authStoreStub) GetByIdempotencyKey(context.Context, pg.DBTX, string) (domain.PaymentAuthorization, error) {
	return domain.PaymentAuthorization{}, service.ErrAuthorizationNotFound
}
func (s *authStoreStub) UpdateStatus(context.Context, pg.DBTX, domain.PaymentAuthorization) error {
	s.updates++
	return nil
}
func (s *authStoreStub) IsBlacklisted(context.Context, pg.DBTX, string) (bool, error) {
	return false, nil
}

func TestConsumeDelivery_AuthorizeCommitsAndAcks(t *testing.T) {
	c, outbox, db := newHappyPathConsumer(t)
	if err := c.ConsumeDelivery(context.Background(), authorizeDelivery(t, "wf-ok-1")); err != nil {
		t.Fatalf("ConsumeDelivery: %v", err)
	}
	msgs := outbox.Messages()
	if len(msgs) != 1 {
		t.Fatalf("outbox msgs = %d, want 1", len(msgs))
	}
	if msgs[0].Envelope.MessageType != service.AuthorizeEventAuthorized {
		t.Errorf("event type = %q, want %q", msgs[0].Envelope.MessageType, service.AuthorizeEventAuthorized)
	}
	begins, commits, rolls := db.counters()
	if begins != 1 || commits != 1 || rolls != 0 {
		t.Errorf("tx counters = begin:%d commit:%d rollback:%d, want 1/1/0", begins, commits, rolls)
	}
}

func TestConsumeDelivery_DuplicateInboxSkipsHandlerButAcks(t *testing.T) {
	store := &authStoreStub{}
	goodCustomer := fakeCustomerReader{customer: serviceclient.Customer{
		CustomerID: "C0000001", Name: "Alice", CustomerType: "personal",
		KYCStatus: "passed", Status: "active",
	}}
	svc := service.NewAuthorizationService(store, goodCustomer, fixedNowConsumer)
	outbox := &capturingOutbox{}
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into inbox_message", affected: 0}) // ON CONFLICT
	c := &Consumer{db: db.open(), service: svc, outbox: outbox, now: fixedNowConsumer}

	if err := c.ConsumeDelivery(context.Background(), authorizeDelivery(t, "wf-dup")); err != nil {
		t.Fatalf("ConsumeDelivery: %v", err)
	}
	if len(outbox.Messages()) != 0 {
		t.Errorf("outbox msgs = %d, want 0 for a duplicate delivery", len(outbox.Messages()))
	}
	if store.inserts != 0 {
		t.Errorf("store inserts = %d, want 0", store.inserts)
	}
	_, commits, rolls := db.counters()
	if commits != 1 || rolls != 0 {
		t.Errorf("tx counters commit:%d rollback:%d, want 1/0", commits, rolls)
	}
}

func TestNewConsumer_DefaultsNow(t *testing.T) {
	c := NewConsumer(nil, nil, nil, messaging.RetryPolicy{}, nil)
	if c.now == nil {
		t.Error("NewConsumer must default now to time.Now")
	}
}

func TestBuildSmokeRejectEnvelope(t *testing.T) {
	cmdEnv := makeCommandEnvelope(CmdAuthorizePayment)
	cmdEnv.WorkflowID = "wf-smoke-reject-1"
	payload := authorizePaymentPayload{
		AuthorizationID: "auth-1", CustomerID: "C1", AmountCents: 10000, Currency: "CNY",
	}
	env, err := buildSmokeRejectEnvelope(cmdEnv, payload, fixedNowConsumer())
	if err != nil {
		t.Fatal(err)
	}
	if env.MessageType != service.AuthorizeEventRejected {
		t.Errorf("message type = %q, want %q", env.MessageType, service.AuthorizeEventRejected)
	}
	if env.WorkflowID != "wf-smoke-reject-1" || env.CausationID != cmdEnv.MessageID {
		t.Errorf("workflow/causation wrong: %+v", env)
	}
	var body authorizeResultPayload
	if err := json.Unmarshal(env.Payload, &body); err != nil {
		t.Fatal(err)
	}
	if len(body.MatchedRules) != 1 || body.MatchedRules[0] != "SMOKE-INJECTED" {
		t.Errorf("matched rules = %v, want [SMOKE-INJECTED]", body.MatchedRules)
	}
	if body.AuthorizationID != "auth-1" || body.AmountCents != 10000 {
		t.Errorf("payload mapping wrong: %+v", body)
	}
}

func TestRiskOutbox_AppendOutbox(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into outbox_message", affected: 1})
	o := NewRiskOutbox(db.open())
	env := makeCommandEnvelope(CmdAuthorizePayment)
	if err := o.AppendOutbox(context.Background(), db.open(), env, RoutePaymentRejected); err != nil {
		t.Fatalf("AppendOutbox: %v", err)
	}
	call := db.lastCallWith("insert into outbox_message")
	if call == nil {
		t.Fatal("outbox insert not executed")
	}
	if call.args[0] != env.MessageID || call.args[1] != env.MessageType || call.args[3] != RoutePaymentRejected {
		t.Errorf("outbox args wrong: %+v", call)
	}
}

func TestRiskOutbox_AppendOutboxErrorWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "insert into outbox_message", err: errors.New("insert failed")})
	o := NewRiskOutbox(db.open())
	env := makeCommandEnvelope(CmdAuthorizePayment)
	err := o.AppendOutbox(context.Background(), db.open(), env, "risk.payment.rejected")
	if err == nil || !strings.Contains(err.Error(), "insert failed") {
		t.Fatalf("want wrapped error, got %v", err)
	}
}

func TestNewOutboxRelay_Defaults(t *testing.T) {
	r := NewOutboxRelay(nil, nil)
	if r.Interval != 500*time.Millisecond || r.BatchSize != 100 {
		t.Errorf("defaults wrong: interval=%v batch=%d", r.Interval, r.BatchSize)
	}
}

func TestOutboxRelay_Run_Guards(t *testing.T) {
	if err := (&OutboxRelay{}).Run(context.Background()); err == nil {
		t.Error("nil db must fail fast")
	}
	db := &fakeDB{}
	relay := NewOutboxRelay(db.open(), nil)
	if err := relay.Run(context.Background()); err == nil {
		t.Error("nil publisher must fail fast")
	}
}

func TestOutboxRelay_Run_CancelledContextReturnsNil(t *testing.T) {
	db := &fakeDB{}
	relay := NewOutboxRelay(db.open(), &publishingStub{})
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := relay.Run(ctx); err != nil {
		t.Errorf("Run on cancelled ctx = %v, want nil", err)
	}
}

func TestOutboxRelay_DrainPublishesAndMarksDispatched(t *testing.T) {
	env := makeCommandEnvelope(CmdAuthorizePayment)
	body, _ := json.Marshal(env)
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from outbox_message",
		cols:   []string{"message_id", "routing_key", "envelope"},
		rows:   [][]driver.Value{{env.MessageID, RoutePaymentAuthorized, []byte(body)}},
	})
	db.add(queryPlan{marker: "update outbox_message", affected: 1})
	relay := NewOutboxRelay(db.open(), &publishingStub{})
	if err := relay.drain(context.Background()); err != nil {
		t.Fatalf("drain: %v", err)
	}
	pub := relay.publisher.(*publishingStub).publishedTo()
	if len(pub) != 1 {
		t.Fatalf("published = %d, want 1", len(pub))
	}
	if pub[0].routingKey != RoutePaymentAuthorized || pub[0].exchange != messaging.ExchangeForRoutingKey(RoutePaymentAuthorized) {
		t.Errorf("published to %s/%s", pub[0].exchange, pub[0].routingKey)
	}
	if call := db.lastCallWith("update outbox_message"); call == nil || call.args[0] != env.MessageID {
		t.Errorf("dispatched update missing: %+v", call)
	}
}

func TestOutboxRelay_DrainPoisonMessageMarked(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from outbox_message",
		cols:   []string{"message_id", "routing_key", "envelope"},
		rows:   [][]driver.Value{{"poison-1", RoutePaymentAuthorized, []byte("{not-json")}},
	})
	db.add(queryPlan{marker: "update outbox_message", affected: 1})
	relay := NewOutboxRelay(db.open(), &publishingStub{})
	if err := relay.drain(context.Background()); err != nil {
		t.Fatalf("drain must tolerate poison messages: %v", err)
	}
	pub := relay.publisher.(*publishingStub).publishedTo()
	if len(pub) != 0 {
		t.Errorf("published = %d, want 0 for a poison message", len(pub))
	}
	if call := db.lastCallWith("update outbox_message"); call == nil || call.args[0] != "poison-1" {
		t.Errorf("poison message must be marked with last_error: %+v", call)
	}
}

func TestOutboxRelay_DrainPublishFailurePropagates(t *testing.T) {
	env := makeCommandEnvelope(CmdAuthorizePayment)
	body, _ := json.Marshal(env)
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from outbox_message",
		cols:   []string{"message_id", "routing_key", "envelope"},
		rows:   [][]driver.Value{{env.MessageID, RoutePaymentAuthorized, []byte(body)}},
	})
	relay := NewOutboxRelay(db.open(), &publishingStub{err: errors.New("broker down")})
	err := relay.drain(context.Background())
	if err == nil || !strings.Contains(err.Error(), "broker down") {
		t.Fatalf("want publish failure surfaced, got %v", err)
	}
}

// ---------------------------------------------------------------------------
// fakesql harness (same design as risk/repo/fakesql_test.go; duplicated here
// because this package's tests need their own *sql.DB).
// ---------------------------------------------------------------------------

type queryPlan struct {
	marker   string
	cols     []string
	rows     [][]driver.Value
	err      error
	iterErr  error
	affected int64
}

type fakeDB struct {
	mu      sync.Mutex
	plans   []queryPlan
	calls   []fakeCall
	begins  int
	commits int
	rolls   int
}

type fakeCall struct {
	query string
	args  []driver.Value
}

func (d *fakeDB) add(p queryPlan) { d.plans = append(d.plans, p) }

func (d *fakeDB) plan(query string) *queryPlan {
	lower := strings.ToLower(query)
	for i := range d.plans {
		if strings.Contains(lower, d.plans[i].marker) {
			return &d.plans[i]
		}
	}
	return nil
}

func (d *fakeDB) record(query string, args []driver.NamedValue) {
	vals := make([]driver.Value, len(args))
	for i, a := range args {
		vals[i] = a.Value
	}
	d.mu.Lock()
	d.calls = append(d.calls, fakeCall{query: query, args: vals})
	d.mu.Unlock()
}

func (d *fakeDB) lastCallWith(marker string) *fakeCall {
	d.mu.Lock()
	defer d.mu.Unlock()
	for i := len(d.calls) - 1; i >= 0; i-- {
		if strings.Contains(strings.ToLower(d.calls[i].query), marker) {
			c := d.calls[i]
			return &c
		}
	}
	return nil
}

func (d *fakeDB) counters() (begins, commits, rolls int) {
	d.mu.Lock()
	defer d.mu.Unlock()
	return d.begins, d.commits, d.rolls
}

// open returns a *sql.DB backed by this fake driver.
func (d *fakeDB) open() *sql.DB { return sql.OpenDB(fakeConnector{db: d}) }

type fakeConnector struct{ db *fakeDB }

func (c fakeConnector) Connect(context.Context) (driver.Conn, error) {
	return &fakeConn{db: c.db}, nil
}
func (c fakeConnector) Driver() driver.Driver { return fakeDriver{c.db} }

type fakeDriver struct{ db *fakeDB }

func (fakeDriver) Open(string) (driver.Conn, error) {
	return nil, errors.New("fakesql: Open not supported, use sql.OpenDB")
}

type fakeConn struct{ db *fakeDB }

func (c *fakeConn) Prepare(string) (driver.Stmt, error) {
	return nil, errors.New("fakesql: Prepare not supported")
}
func (c *fakeConn) Close() error              { return nil }
func (c *fakeConn) Begin() (driver.Tx, error) { return c.BeginTx(context.Background(), driver.TxOptions{}) }
func (c *fakeConn) BeginTx(context.Context, driver.TxOptions) (driver.Tx, error) {
	c.db.mu.Lock()
	c.db.begins++
	c.db.mu.Unlock()
	return fakeTx{db: c.db}, nil
}

func (c *fakeConn) ExecContext(_ context.Context, query string, args []driver.NamedValue) (driver.Result, error) {
	c.db.record(query, args)
	p := c.db.plan(query)
	if p == nil {
		return nil, errors.New("fakesql: no plan for " + query)
	}
	if p.err != nil {
		return nil, p.err
	}
	return driver.RowsAffected(p.affected), nil
}

func (c *fakeConn) QueryContext(_ context.Context, query string, args []driver.NamedValue) (driver.Rows, error) {
	c.db.record(query, args)
	p := c.db.plan(query)
	if p == nil {
		return nil, errors.New("fakesql: no plan for " + query)
	}
	if p.err != nil {
		return nil, p.err
	}
	rows := make([][]driver.Value, len(p.rows))
	copy(rows, p.rows)
	return &fakeRows{cols: p.cols, rows: rows, iterErr: p.iterErr}, nil
}

type fakeTx struct{ db *fakeDB }

func (t fakeTx) Commit() error {
	t.db.mu.Lock()
	t.db.commits++
	t.db.mu.Unlock()
	return nil
}
func (t fakeTx) Rollback() error {
	t.db.mu.Lock()
	t.db.rolls++
	t.db.mu.Unlock()
	return nil
}

type fakeRows struct {
	cols    []string
	rows    [][]driver.Value
	idx     int
	iterErr error
}

func (r *fakeRows) Columns() []string { return r.cols }
func (r *fakeRows) Close() error      { return nil }
func (r *fakeRows) Next(dest []driver.Value) error {
	if r.idx >= len(r.rows) {
		if r.iterErr != nil {
			err := r.iterErr
			r.iterErr = nil
			return err
		}
		return io.EOF
	}
	row := r.rows[r.idx]
	r.idx++
	copy(dest, row)
	return nil
}
