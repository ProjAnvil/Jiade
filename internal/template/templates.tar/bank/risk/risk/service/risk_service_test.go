package service

// Tests for the query-orchestration layer: every method must pass its
// arguments through to the store unchanged and surface the store error.

import (
	"context"
	"errors"
	"testing"

	"bank/risk/risk/domain"
)

type recordingStore struct {
	gotEventID string
	gotCustID  string

	gotFrom, gotTo, gotRuleID, gotAction string
	gotOffset, gotLimit                  int

	err error
}

func (s *recordingStore) ListEvents(_ context.Context, from, to, ruleID, action string, offset, limit int) ([]domain.RiskEvent, error) {
	s.gotFrom, s.gotTo, s.gotRuleID, s.gotAction, s.gotOffset, s.gotLimit = from, to, ruleID, action, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return []domain.RiskEvent{{EventID: "E1"}}, nil
}

func (s *recordingStore) GetEvent(_ context.Context, eventID string) (domain.RiskEventDetail, error) {
	s.gotEventID = eventID
	if s.err != nil {
		return domain.RiskEventDetail{}, s.err
	}
	return domain.RiskEventDetail{RiskEvent: domain.RiskEvent{EventID: eventID}}, nil
}

func (s *recordingStore) ListRules(context.Context) ([]domain.RiskRule, error) {
	if s.err != nil {
		return nil, s.err
	}
	return []domain.RiskRule{{RuleID: "R1"}}, nil
}

func (s *recordingStore) ListBlacklists(_ context.Context, custID string, offset, limit int) ([]domain.Blacklist, error) {
	s.gotCustID, s.gotOffset, s.gotLimit = custID, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return []domain.Blacklist{{ListID: "B1"}}, nil
}

func TestRiskService_PassesFiltersThrough(t *testing.T) {
	store := &recordingStore{}
	svc := NewRiskService(store)
	ctx := context.Background()

	events, err := svc.ListEvents(ctx, "2026-07-01", "2026-07-31", "R-KYC", "reject", 10, 5)
	if err != nil || len(events) != 1 {
		t.Fatalf("ListEvents: %+v %v", events, err)
	}
	if store.gotFrom != "2026-07-01" || store.gotTo != "2026-07-31" || store.gotRuleID != "R-KYC" || store.gotAction != "reject" || store.gotOffset != 10 || store.gotLimit != 5 {
		t.Errorf("ListEvents args wrong: %+v", store)
	}

	detail, err := svc.Event(ctx, "E1")
	if err != nil || detail.EventID != "E1" {
		t.Fatalf("Event: %+v %v", detail, err)
	}

	rules, err := svc.Rules(ctx)
	if err != nil || len(rules) != 1 {
		t.Fatalf("Rules: %+v %v", rules, err)
	}

	list, err := svc.Blacklists(ctx, "C0000001", 3, 7)
	if err != nil || len(list) != 1 {
		t.Fatalf("Blacklists: %+v %v", list, err)
	}
	if store.gotCustID != "C0000001" || store.gotOffset != 3 || store.gotLimit != 7 {
		t.Errorf("Blacklists args wrong: %+v", store)
	}
}

func TestRiskService_SurfacesStoreErrors(t *testing.T) {
	boom := errors.New("boom")
	svc := NewRiskService(&recordingStore{err: boom})
	ctx := context.Background()

	if _, err := svc.ListEvents(ctx, "", "", "", "", 0, 0); !errors.Is(err, boom) {
		t.Errorf("ListEvents err = %v", err)
	}
	if _, err := svc.Event(ctx, "x"); !errors.Is(err, boom) {
		t.Errorf("Event err = %v", err)
	}
	if _, err := svc.Rules(ctx); !errors.Is(err, boom) {
		t.Errorf("Rules err = %v", err)
	}
	if _, err := svc.Blacklists(ctx, "", 0, 0); !errors.Is(err, boom) {
		t.Errorf("Blacklists err = %v", err)
	}
}
