package api

// Handler tests for ListCustomers and the error branches not covered by
// handlers_test.go (which covers healthz, GetCustomer, GetCustAccounts).

import (
	"context"
	"database/sql"
	"errors"
	"strings"
	"testing"

	"bank/customer/customer/domain"
	"bank/customer/customer/service"
)

// stubRepo lets each test script one outcome per method.
type stubRepo struct {
	customers []domain.Customer
	err       error

	gotCustType, gotKycStatus string
	gotOffset, gotLimit       int
}

func (s *stubRepo) GetCustomer(context.Context, string) (domain.Customer, error) {
	if s.err != nil {
		return domain.Customer{}, s.err
	}
	return domain.Customer{}, sql.ErrNoRows
}

func (s *stubRepo) ListCustomers(_ context.Context, custType, kycStatus string, offset, limit int) ([]domain.Customer, error) {
	s.gotCustType, s.gotKycStatus, s.gotOffset, s.gotLimit = custType, kycStatus, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return s.customers, nil
}

func (s *stubRepo) GetCustAccounts(context.Context, string) ([]domain.CustAccount, error) {
	if s.err != nil {
		return nil, s.err
	}
	return nil, nil
}

func TestListCustomers_OK(t *testing.T) {
	repo := &stubRepo{customers: []domain.Customer{{
		CustID: "C0000001", CustType: domain.CustType("personal"), Name: "Alice",
		KYCStatus: "passed", RiskLevel: "R2", CreateBizDate: "2026-01-01",
	}}}
	h := &Handlers{Svc: service.NewCustomerService(repo)}
	code, body := get(t, NewRouter(h), "/api/v1/customers?type=personal&kyc_status=passed&offset=1&limit=2")
	if code != 200 || !strings.Contains(body, `"cust_id":"C0000001"`) ||
		!strings.Contains(body, `"cust_type":"personal"`) || !strings.Contains(body, `"kyc_status":"passed"`) {
		t.Errorf("code=%d body=%s", code, body)
	}
	if repo.gotCustType != "personal" || repo.gotKycStatus != "passed" || repo.gotOffset != 1 || repo.gotLimit != 2 {
		t.Errorf("filters not passed through: %+v", repo)
	}
}

func TestListCustomers_EmptyIsArray(t *testing.T) {
	h := &Handlers{Svc: service.NewCustomerService(&stubRepo{})}
	code, body := get(t, NewRouter(h), "/api/v1/customers")
	if code != 200 || !strings.Contains(body, `"customers":[]`) {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestListCustomers_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewCustomerService(&stubRepo{err: errors.New("db down")})}
	code, body := get(t, NewRouter(h), "/api/v1/customers")
	if code != 500 || !strings.Contains(body, "db down") {
		t.Errorf("code=%d body=%s", code, body)
	}
}

func TestGetCustomer_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewCustomerService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/customers/C0000001"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}

func TestGetCustAccounts_StoreErrorIs500(t *testing.T) {
	h := &Handlers{Svc: service.NewCustomerService(&stubRepo{err: errors.New("boom")})}
	if code, _ := get(t, NewRouter(h), "/api/v1/customers/C0000001/accounts"); code != 500 {
		t.Errorf("code=%d want 500", code)
	}
}
