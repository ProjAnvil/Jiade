package repo

// Unit tests for CustomerRepo query/scan logic using the fakesql harness in
// fakesql_test.go (no live PostgreSQL). Live-DB round-trips remain in the
// integration-gated customer_repo_test.go.

import (
	"context"
	"database/sql"
	"database/sql/driver"
	"errors"
	"strings"
	"testing"

	"bank/customer/customer/domain"
	"bank/lib/serviceclient"
)

type stubAccountReader struct {
	err    error
	calls  []string
}

func (s *stubAccountReader) GetAccount(_ context.Context, accountNo, _ string) (serviceclient.Account, error) {
	s.calls = append(s.calls, accountNo)
	if s.err != nil {
		return serviceclient.Account{}, s.err
	}
	return serviceclient.Account{
		AccountNo: accountNo, Currency: "CNY", Status: "active",
		OpenBizDate: "2026-01-10", Branch: "BR-01",
	}, nil
}

const custCols = "cust_id,cust_type,name,cert_type,cert_no,gender,birthday,nationality,risk_level,kyc_status,customer_status,risk_tags,create_biz_date"

func custRow(id string) []driver.Value {
	return []driver.Value{id, "personal", "Alice", "idcard", "110101199001011234", "F", "1990-01-01", "CN", "R2", "passed", "active", `["high_value","vip"]`, "2026-01-01"}
}

func TestGetCustomer_MapsRow(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from cust_info", cols: strings.Split(custCols, ","), rows: [][]driver.Value{custRow("C0000001")}})
	r := NewCustomerRepo(db.open(), &stubAccountReader{})
	c, err := r.GetCustomer(context.Background(), "C0000001")
	if err != nil {
		t.Fatalf("GetCustomer: %v", err)
	}
	if c.CustID != "C0000001" || c.Name != "Alice" || c.CustType != domain.CustType("personal") {
		t.Errorf("customer mapping wrong: %+v", c)
	}
	if len(c.RiskTags) != 2 || c.RiskTags[0] != "high_value" || c.RiskTags[1] != "vip" {
		t.Errorf("risk tags wrong: %+v", c.RiskTags)
	}
	if c.Gender != "F" || c.Birthday != "1990-01-01" {
		t.Errorf("nullable columns wrong: %+v", c)
	}
}

func TestGetCustomer_EmptyTagsDecodeToEmptySlice(t *testing.T) {
	db := &fakeDB{}
	row := custRow("C0000001")
	row[11] = "null"
	db.add(queryPlan{marker: "from cust_info", cols: strings.Split(custCols, ","), rows: [][]driver.Value{row}})
	r := NewCustomerRepo(db.open(), &stubAccountReader{})
	c, err := r.GetCustomer(context.Background(), "C0000001")
	if err != nil {
		t.Fatalf("GetCustomer: %v", err)
	}
	if c.RiskTags == nil || len(c.RiskTags) != 0 {
		t.Errorf("null risk tags must decode to empty slice, got %#v", c.RiskTags)
	}
}

func TestGetCustomer_BadTagsJSONFails(t *testing.T) {
	db := &fakeDB{}
	row := custRow("C0000001")
	row[11] = "{not-json"
	db.add(queryPlan{marker: "from cust_info", cols: strings.Split(custCols, ","), rows: [][]driver.Value{row}})
	r := NewCustomerRepo(db.open(), &stubAccountReader{})
	if _, err := r.GetCustomer(context.Background(), "C0000001"); err == nil {
		t.Fatal("malformed risk_tags JSON should fail")
	}
}

func TestGetCustomer_MissingRowWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from cust_info", cols: strings.Split(custCols, ",")})
	r := NewCustomerRepo(db.open(), &stubAccountReader{})
	_, err := r.GetCustomer(context.Background(), "C-NOPE")
	if err == nil || !errors.Is(err, sql.ErrNoRows) {
		t.Fatalf("want sql.ErrNoRows wrapped, got %v", err)
	}
}

func TestListCustomers_MapsRowsAndDefaultsLimit(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{marker: "from cust_info", cols: strings.Split(custCols, ","), rows: [][]driver.Value{
		custRow("C0000001"),
		{"C0000002", nil, "Bob", "idcard", "110101199001011235", nil, nil, "CN", "R1", "pending", "frozen", "[]", "2026-02-01"},
	}})
	r := NewCustomerRepo(db.open(), &stubAccountReader{})
	list, err := r.ListCustomers(context.Background(), "personal", "passed", 0, 0)
	if err != nil {
		t.Fatalf("ListCustomers: %v", err)
	}
	if len(list) != 2 {
		t.Fatalf("customers = %d, want 2", len(list))
	}
	if list[1].CustType != "" || list[1].Gender != "" {
		t.Errorf("NULL cust_type/gender should map to empty: %+v", list[1])
	}
	if len(list[1].RiskTags) != 0 {
		t.Errorf("empty tags array should decode to empty slice: %#v", list[1].RiskTags)
	}
	if call := db.lastCallWith("from cust_info"); call == nil || call.args[0] != "personal" || call.args[1] != "passed" || call.args[2] != int64(50) {
		t.Errorf("default limit not applied: %+v", call)
	}
}

func TestListCustomers_BadTagsJSONFails(t *testing.T) {
	db := &fakeDB{}
	row := custRow("C0000001")
	row[11] = "[broken"
	db.add(queryPlan{marker: "from cust_info", cols: strings.Split(custCols, ","), rows: [][]driver.Value{row}})
	r := NewCustomerRepo(db.open(), &stubAccountReader{})
	if _, err := r.ListCustomers(context.Background(), "", "", 0, 10); err == nil {
		t.Fatal("malformed risk_tags JSON should fail the listing")
	}
}

func TestGetCustAccounts_JoinsCoreBanking(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from cust_account_rel",
		cols:   []string{"account_no", "role"},
		rows:   [][]driver.Value{{"6222000000000001", "owner"}, {"6222000000000002", "joint"}},
	})
	core := &stubAccountReader{}
	r := NewCustomerRepo(db.open(), core)
	accts, err := r.GetCustAccounts(context.Background(), "C0000001")
	if err != nil {
		t.Fatalf("GetCustAccounts: %v", err)
	}
	if len(accts) != 2 {
		t.Fatalf("accounts = %d, want 2", len(accts))
	}
	a := accts[0]
	if a.AccountNo != "6222000000000001" || a.Role != "owner" || a.Ccy != "CNY" || a.Status != "active" || a.BranchCode != "BR-01" || a.OpenBizDate != "2026-01-10" {
		t.Errorf("account mapping wrong: %+v", a)
	}
	if len(core.calls) != 2 {
		t.Errorf("core GetAccount calls = %v, want 2", core.calls)
	}
}

func TestGetCustAccounts_CoreFailureWrapped(t *testing.T) {
	db := &fakeDB{}
	db.add(queryPlan{
		marker: "from cust_account_rel",
		cols:   []string{"account_no", "role"},
		rows:   [][]driver.Value{{"6222000000000001", "owner"}},
	})
	r := NewCustomerRepo(db.open(), &stubAccountReader{err: errors.New("grpc down")})
	_, err := r.GetCustAccounts(context.Background(), "C0000001")
	if err == nil || !strings.Contains(err.Error(), "grpc down") {
		t.Fatalf("want core error surfaced, got %v", err)
	}
}
