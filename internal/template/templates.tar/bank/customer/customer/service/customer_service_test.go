package service

// Tests for the query-orchestration layer: every method must pass its
// arguments through to the store unchanged and surface the store error.

import (
	"context"
	"errors"
	"testing"

	"bank/customer/customer/domain"
)

type recordingStore struct {
	gotCustID    string
	gotCustType  string
	gotKycStatus string
	gotOffset    int
	gotLimit     int

	err error
}

func (s *recordingStore) GetCustomer(_ context.Context, custID string) (domain.Customer, error) {
	s.gotCustID = custID
	if s.err != nil {
		return domain.Customer{}, s.err
	}
	return domain.Customer{CustID: custID, Name: "Alice"}, nil
}

func (s *recordingStore) ListCustomers(_ context.Context, custType, kycStatus string, offset, limit int) ([]domain.Customer, error) {
	s.gotCustType, s.gotKycStatus, s.gotOffset, s.gotLimit = custType, kycStatus, offset, limit
	if s.err != nil {
		return nil, s.err
	}
	return []domain.Customer{{CustID: "C1"}}, nil
}

func (s *recordingStore) GetCustAccounts(_ context.Context, custID string) ([]domain.CustAccount, error) {
	s.gotCustID = custID
	if s.err != nil {
		return nil, s.err
	}
	return []domain.CustAccount{{AccountNo: "A1"}}, nil
}

func TestCustomerService_PassesFiltersThrough(t *testing.T) {
	store := &recordingStore{}
	svc := NewCustomerService(store)
	ctx := context.Background()

	c, err := svc.Get(ctx, "C0000001")
	if err != nil || c.CustID != "C0000001" {
		t.Fatalf("Get: %+v %v", c, err)
	}
	if _, err := svc.List(ctx, "personal", "passed", 10, 5); err != nil {
		t.Fatal(err)
	}
	if store.gotCustType != "personal" || store.gotKycStatus != "passed" || store.gotOffset != 10 || store.gotLimit != 5 {
		t.Errorf("List args wrong: %+v", store)
	}
	accts, err := svc.Accounts(ctx, "C0000001")
	if err != nil || len(accts) != 1 {
		t.Fatalf("Accounts: %+v %v", accts, err)
	}
	if store.gotCustID != "C0000001" {
		t.Errorf("Accounts custID wrong: %+v", store)
	}
}

func TestCustomerService_SurfacesStoreErrors(t *testing.T) {
	boom := errors.New("boom")
	svc := NewCustomerService(&recordingStore{err: boom})
	ctx := context.Background()

	if _, err := svc.Get(ctx, "x"); !errors.Is(err, boom) {
		t.Errorf("Get err = %v", err)
	}
	if _, err := svc.List(ctx, "", "", 0, 0); !errors.Is(err, boom) {
		t.Errorf("List err = %v", err)
	}
	if _, err := svc.Accounts(ctx, "x"); !errors.Is(err, boom) {
		t.Errorf("Accounts err = %v", err)
	}
}
