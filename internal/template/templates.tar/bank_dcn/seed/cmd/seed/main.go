// seed opens accounts through the full GNS flow to inject deterministic test data (simulating production route registration).
// The jiade CLI invokes it hard-coded: go run ./cmd/seed --scale=<dev|full> [--reset]
package main

import (
	"bytes"
	"context"
	"database/sql"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"math/rand"
	"net/http"
	"os"
	"time"

	_ "github.com/go-sql-driver/mysql"
	"github.com/redis/go-redis/v9"
)

var (
	scale = flag.String("scale", "dev", "dev|full")
	reset = flag.Bool("reset", false, "clear all business data before seeding")
)

var surnames = []string{"赵", "钱", "孙", "李", "周", "吴", "郑", "王", "冯", "陈", "褚", "卫", "蒋", "沈", "韩", "杨"}

var givenNames = []string{"伟", "芳", "娜", "敏", "静", "磊", "军", "洋", "勇", "艳", "杰", "娟", "涛", "明", "超", "秀兰", "霞", "平", "刚", "桂英"}

// personName composes a Chinese name from the vocabulary lists.
func personName(r *rand.Rand) string {
	return surnames[r.Intn(len(surnames))] + givenNames[r.Intn(len(givenNames))]
}

// initialBalance fixes the first 2 accounts of each unit at 1000.00 (depended on by verify/README); the rest are random in 100–100000.
func initialBalance(r *rand.Rand, i int) string {
	if i < 2 {
		return "1000.00"
	}
	cents := 10000 + r.Int63n(9990001) // 100.00 ~ 100000.00 (unit: cents)
	return fmt.Sprintf("%.2f", float64(cents)/100)
}

func envOr(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

// perScaleCount returns how many accounts to open per route segment for a scale,
// and whether the scale is known at all.
func perScaleCount(scale string) (int, bool) {
	counts := map[string]int{"dev": 50, "full": 2000}
	n, ok := counts[scale]
	return n, ok
}

func main() {
	flag.Parse()
	if _, ok := perScaleCount(*scale); !ok {
		log.Fatalf("unknown scale %q (want dev|full)", *scale)
	}
	if *reset {
		resetAll()
	}
	gns := envOr("GNS_ENDPOINT", "http://localhost:18080")
	hc := &http.Client{Timeout: 10 * time.Second}
	if err := openAccounts(gns, hc, *scale); err != nil {
		log.Fatal(err)
	}
	fmt.Println("seed done")
}

// openAccounts walks every route segment and opens perScaleCount(scale) accounts per
// segment through GNS, printing one "seeded: <response>" line per account (the final
// "seed done" stays in main). Errors are returned instead of exiting so main() owns
// the fatal decision and tests can drive the loop against a fake GNS.
func openAccounts(gnsBase string, hc *http.Client, scale string) error {
	n, ok := perScaleCount(scale)
	if !ok {
		return fmt.Errorf("unknown scale %q (want dev|full)", scale)
	}
	for _, seg := range []int{1000, 2000, 3000} {
		r := rand.New(rand.NewSource(int64(seg))) // deterministic per unit
		for i := 0; i < n; i++ {
			name := personName(r)
			bal := initialBalance(r, i)
			body, _ := json.Marshal(map[string]string{
				"name":        name,
				"initBalance": bal,
				"requestId":   fmt.Sprintf("seed-%s-%d-%d", scale, seg, i), // idempotency key
			})
			resp, err := hc.Post(gnsBase+"/accounts", "application/json", bytes.NewReader(body))
			if err != nil {
				return fmt.Errorf("open account via GNS: %w", err)
			}
			raw, _ := io.ReadAll(resp.Body)
			resp.Body.Close()
			if resp.StatusCode >= 300 {
				return fmt.Errorf("GNS returned %d: %s", resp.StatusCode, raw)
			}
			fmt.Printf("seeded: %s\n", raw)
		}
	}
	return nil
}

// resetAll clears business data (keeping route_segment) and flushes the GNS route cache.
func resetAll() {
	dbs := map[string][]string{
		envOr("SEED_DSN_GNS", "root:dcn123@tcp(127.0.0.1:13309)/gns_db"):     {"account_route"},
		envOr("SEED_DSN_RMB", "root:dcn123@tcp(127.0.0.1:13310)/rmb_db"):     {"tx_step_log", "tx_log"},
		envOr("SEED_DSN_ADM", "root:dcn123@tcp(127.0.0.1:13311)/adm_db"):     {"event_log", "global_balance"},
		envOr("SEED_DSN_DCN01", "root:dcn123@tcp(127.0.0.1:13306)/dcn01_db"): {"journal", "account"},
		envOr("SEED_DSN_DCN02", "root:dcn123@tcp(127.0.0.1:13307)/dcn02_db"): {"journal", "account"},
		envOr("SEED_DSN_DCN03", "root:dcn123@tcp(127.0.0.1:13308)/dcn03_db"): {"journal", "account"},
		envOr("SEED_DSN_BATCH", "root:dcn123@tcp(127.0.0.1:13313)/batch_db"): {"batch_unit_result", "batch_job"},
	}
	for dsn, tables := range dbs {
		db, err := sql.Open("mysql", dsn)
		if err != nil {
			log.Fatalf("open %s: %v", dsn, err)
		}
		for _, t := range tables {
			if _, err := db.Exec("DELETE FROM " + t); err != nil {
				log.Fatalf("clear %s: %v", t, err)
			}
		}
		db.Close()
	}
	rdb := redis.NewClient(&redis.Options{Addr: envOr("SEED_REDIS_ADDR", "127.0.0.1:16379")})
	if err := rdb.FlushDB(context.Background()).Err(); err != nil {
		log.Printf("warn: flush gns redis: %v", err)
	}
	fmt.Println("reset done")
}
