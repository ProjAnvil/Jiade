package metrics

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestMountExposesMetricsAndCountsRequests(t *testing.T) {
	inner := http.NewServeMux()
	Handle(inner, "testsvc", "GET /accounts/{id}/balance", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(200)
	}))
	h := Mount(inner)

	// A business request is counted.
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", "/accounts/1001/balance", nil))
	if rec.Code != 200 {
		t.Fatalf("inner handler code = %d", rec.Code)
	}

	// /metrics is exposed and contains this service's count; the handler label
	// uses the route template instead of the raw path (to prevent cardinality explosion).
	rec = httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest("GET", "/metrics", nil))
	body := rec.Body.String()
	if !strings.Contains(body, `http_requests_total{code="200",handler="/accounts/{id}/balance",service="testsvc"} 1`) {
		t.Fatalf("metrics missing request count:\n%s", body)
	}
	if !strings.Contains(body, `http_request_duration_seconds_count{code_class="2xx",handler="/accounts/{id}/balance",service="testsvc"} 1`) {
		t.Fatalf("metrics missing duration count:\n%s", body)
	}
}

func TestIncTx(t *testing.T) {
	IncTx("TESTSTATUS")
	rec := httptest.NewRecorder()
	Mount(http.NewServeMux()).ServeHTTP(rec, httptest.NewRequest("GET", "/metrics", nil))
	if !strings.Contains(rec.Body.String(), `rmb_tx_total{status="TESTSTATUS"} 1`) {
		t.Fatalf("missing rmb_tx_total:\n%s", rec.Body.String())
	}
}
