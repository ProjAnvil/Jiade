package fulfillment

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"commerce/lib/messaging"
	amqp "github.com/rabbitmq/amqp091-go"
)

// newTestConsumer binds a Consumer to the fixture service. applyEvent only
// touches consumer.service; a nil PostgresStore is sufficient for the unit
// path (ProcessDelivery is not exercised here).
func newTestConsumer(service *Service) *Consumer {
	return &Consumer{service: service, policy: messaging.RetryPolicy{}}
}

func placedPaidEvent(orderID string, body []byte) messaging.Event {
	event := messaging.NewEvent("order.paid.v1", orderID, "corr-ful", "cause-ful",
		body, func() time.Time { return fixedFulfillmentClock() })
	event.ID = "evt-" + orderID
	return event
}

func TestConsumerApplyOrderPaidFulfillsOrder(t *testing.T) {
	fixture := newFulfillmentFixture()
	fixture.inventory.seed("ORD-C-1", allocationList{
		{SKU: "SKU-A", LocationID: "LOC-1", Quantity: 2},
		{SKU: "SKU-B", LocationID: "LOC-2", Quantity: 1},
	})
	consumer := newTestConsumer(fixture.service)
	body, _ := json.Marshal(orderIDEventPayload{OrderID: "ORD-C-1"})
	if err := consumer.applyEvent(placedPaidEvent("ORD-C-1", body)); err != nil {
		t.Fatalf("applyEvent(order.paid.v1) error: %v", err)
	}
	orders, err := fixture.store.GetFulfillmentsByOrder(context.Background(), "ORD-C-1")
	if err != nil {
		t.Fatalf("GetFulfillmentsByOrder error: %v", err)
	}
	if len(orders) != 2 {
		t.Fatalf("fulfillment orders=%d, want 2 (one per location)", len(orders))
	}
	if len(fixture.store.capturedEvents) != 1 ||
		fixture.store.capturedEvents[0].Type != EventFulfillmentCompleted {
		t.Fatalf("captured events=%v, want single %s",
			eventTypes(fixture.store.capturedEvents), EventFulfillmentCompleted)
	}
}

func TestConsumerApplyOrderPaidRejectsMismatchedSubject(t *testing.T) {
	fixture := newFulfillmentFixture()
	consumer := newTestConsumer(fixture.service)
	body, _ := json.Marshal(orderIDEventPayload{OrderID: "ORD-OTHER"})
	err := consumer.applyEvent(placedPaidEvent("ORD-C-2", body))
	if err == nil || !strings.Contains(err.Error(), "does not match subject") {
		t.Fatalf("applyEvent error=%v, want subject mismatch", err)
	}
	if len(fixture.store.capturedEvents) != 0 {
		t.Fatalf("captured events=%v, want none on rejection", fixture.store.capturedEvents)
	}
}

func TestConsumerApplyOrderCancelledUsesReasonOrDefault(t *testing.T) {
	fixture := newFulfillmentFixture()
	fixture.inventory.seed("ORD-C-3", allocationList{
		{SKU: "SKU-A", LocationID: "LOC-1", Quantity: 1},
	})
	if _, err := fixture.service.FulfillOrder(context.Background(), FulfillCommand{
		OrderID: "ORD-C-3", IdempotencyKey: "paid-c-3",
	}); err != nil {
		t.Fatalf("FulfillOrder error: %v", err)
	}
	fixture.store.resetEvents()
	consumer := newTestConsumer(fixture.service)

	// Explicit reason is passed through to the cancel command.
	withReason, _ := json.Marshal(orderCancelledPayload{OrderID: "ORD-C-3", Reason: "buyer_cancelled"})
	event := messaging.NewEvent("order.cancelled.v1", "ORD-C-3", "corr-c-3", "cause-c-3",
		withReason, func() time.Time { return fixedFulfillmentClock() })
	if err := consumer.applyEvent(event); err != nil {
		t.Fatalf("applyEvent(order.cancelled.v1) error: %v", err)
	}
	if len(fixture.store.capturedEvents) != 1 ||
		fixture.store.capturedEvents[0].Type != EventFulfillmentCancelled {
		t.Fatalf("captured events=%v, want single %s",
			eventTypes(fixture.store.capturedEvents), EventFulfillmentCancelled)
	}

	// Missing reason falls back to the documented default.
	fixture.store.resetEvents()
	withoutReason, _ := json.Marshal(orderCancelledPayload{OrderID: "ORD-C-3"})
	event = messaging.NewEvent("order.cancelled.v1", "ORD-C-3", "corr-c-3b", "cause-c-3b",
		withoutReason, func() time.Time { return fixedFulfillmentClock() })
	event.ID = "evt-cancel-default"
	if err := consumer.applyEvent(event); err != nil {
		t.Fatalf("applyEvent(order.cancelled.v1 default reason) error: %v", err)
	}
}

func TestConsumerApplyCancelRequestedCancelsOpenFulfillment(t *testing.T) {
	fixture := newFulfillmentFixture()
	fixture.store.seedOrder(FulfillmentOrder{
		FulfillmentID: deterministicFulfillmentID("ORD-C-4", "LOC-1"),
		OrderID:       "ORD-C-4", LocationID: "LOC-1", Status: StatusInProgress,
		CreatedAt: fixedFulfillmentClock(),
	})
	consumer := newTestConsumer(fixture.service)
	body, _ := json.Marshal(orderCancelledPayload{OrderID: "ORD-C-4", Reason: "saga_compensation"})
	event := messaging.NewEvent("fulfillment.cancel-requested.v1", "ORD-C-4", "corr-c-4", "cause-c-4",
		body, func() time.Time { return fixedFulfillmentClock() })
	if err := consumer.applyEvent(event); err != nil {
		t.Fatalf("applyEvent(fulfillment.cancel-requested.v1) error: %v", err)
	}
	orders, err := fixture.store.GetFulfillmentsByOrder(context.Background(), "ORD-C-4")
	if err != nil {
		t.Fatalf("GetFulfillmentsByOrder error: %v", err)
	}
	if len(orders) != 1 || orders[0].Status != StatusCancelled {
		t.Fatalf("orders=%+v, want single cancelled projection", orders)
	}
}

func TestConsumerApplyUnsupportedEventTypeIsRejected(t *testing.T) {
	fixture := newFulfillmentFixture()
	consumer := newTestConsumer(fixture.service)
	body, _ := json.Marshal(orderIDEventPayload{OrderID: "ORD-C-5"})
	event := messaging.NewEvent("order.unknown.v1", "ORD-C-5", "corr", "cause", body,
		func() time.Time { return fixedFulfillmentClock() })
	err := consumer.applyEvent(event)
	if err == nil || !strings.Contains(err.Error(), "unsupported fulfillment event type") {
		t.Fatalf("applyEvent error=%v, want unsupported type rejection", err)
	}
}

func TestFulfillmentKeyNamespacesKindsAndEventIDs(t *testing.T) {
	got := fulfillmentKey("ORD-1", "paid", "evt-9")
	if got != "paid:ORD-1:evt-9" {
		t.Fatalf("fulfillmentKey=%q", got)
	}
	if fulfillmentKey("ORD-1", "cancel", "evt-9") == got {
		t.Fatalf("paid and cancel keys must not collide for the same order/event")
	}
}

func TestDecodeFulfillmentEnvelope(t *testing.T) {
	valid := messaging.NewEvent("order.paid.v1", "ORD-E", "corr", "cause",
		[]byte(`{"order_id":"ORD-E"}`), func() time.Time { return fixedFulfillmentClock() })
	zeroClock := func() time.Time { return time.Time{} }
	tests := []struct {
		name      string
		event     messaging.Event
		data      string
		wantErr   string
		emptyDest bool
	}{
		{
			name:    "valid payload",
			event:   valid,
			data:    `{"order_id":"ORD-E"}`,
			wantErr: "",
		},
		{
			name: "stale schema version",
			event: messaging.Event{Type: "order.paid.v1", Subject: "ORD-E",
				SchemaVersion: messaging.CurrentSchemaVersion + 1,
				OccurredAt:    fixedFulfillmentClock(), Data: []byte(`{"order_id":"ORD-E"}`)},
			wantErr: "invalid order.paid.v1 envelope or payload",
		},
		{
			name: "empty subject",
			event: messaging.Event{Type: "order.paid.v1",
				SchemaVersion: messaging.CurrentSchemaVersion,
				OccurredAt:    fixedFulfillmentClock(), Data: []byte(`{"order_id":"ORD-E"}`)},
			wantErr: "invalid order.paid.v1 envelope or payload",
		},
		{
			name: "zero occurred_at",
			event: messaging.Event{Type: "order.paid.v1", Subject: "ORD-E",
				SchemaVersion: messaging.CurrentSchemaVersion,
				Data:          []byte(`{"order_id":"ORD-E"}`)},
			wantErr: "invalid order.paid.v1 envelope or payload",
		},
		{
			name: "empty data",
			event: messaging.Event{Type: "order.paid.v1", Subject: "ORD-E",
				SchemaVersion: messaging.CurrentSchemaVersion, OccurredAt: fixedFulfillmentClock()},
			wantErr: "invalid order.paid.v1 envelope or payload",
		},
		{
			name: "malformed json",
			event: messaging.Event{Type: "order.paid.v1", Subject: "ORD-E",
				SchemaVersion: messaging.CurrentSchemaVersion,
				OccurredAt:    fixedFulfillmentClock(), Data: []byte(`{"order_id":`)},
			wantErr: "invalid order.paid.v1 envelope or payload",
		},
		{
			name: "unknown field rejected by strict decoder",
			event: messaging.Event{Type: "order.paid.v1", Subject: "ORD-E",
				SchemaVersion: messaging.CurrentSchemaVersion,
				OccurredAt:    fixedFulfillmentClock(), Data: []byte(`{"order_id":"ORD-E","extra":1}`)},
			wantErr: "decode order.paid.v1 payload",
		},
		{
			// A destination with no fields marshals back to "{}" which the
			// decoder must reject as an empty payload.
			name: "empty object payload",
			event: messaging.Event{Type: "order.paid.v1", Subject: "ORD-E",
				SchemaVersion: messaging.CurrentSchemaVersion,
				OccurredAt:    fixedFulfillmentClock(), Data: []byte(`{}`)},
			wantErr:  "empty order.paid.v1 payload",
			emptyDest: true,
		},
		{
			// NewEvent with a zero clock produces a zero OccurredAt, exercising
			// the same guard through the public constructor.
			name:    "constructed with zero clock",
			event:   messaging.NewEvent("order.cancelled.v1", "ORD-E", "corr", "", []byte(`{"order_id":"ORD-E","reason":"x"}`), zeroClock),
			wantErr: "invalid order.cancelled.v1 envelope or payload",
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			var payload orderIDEventPayload
			var empty struct{}
			destination := any(&payload)
			if test.emptyDest {
				destination = &empty
			}
			err := decodeFulfillmentEnvelope(test.event, destination)
			if test.wantErr == "" {
				if err != nil {
					t.Fatalf("decodeFulfillmentEnvelope error: %v", err)
				}
				if payload.OrderID != "ORD-E" {
					t.Fatalf("payload.OrderID=%q, want ORD-E", payload.OrderID)
				}
				return
			}
			if err == nil || !strings.Contains(err.Error(), test.wantErr) {
				t.Fatalf("decodeFulfillmentEnvelope error=%v, want %q", err, test.wantErr)
			}
		})
	}
}

func TestValidateFulfillmentSubject(t *testing.T) {
	event := messaging.Event{Type: "order.paid.v1", Subject: "ORD-S"}
	if err := validateFulfillmentSubject(event, "ORD-S"); err != nil {
		t.Fatalf("matching subject error: %v", err)
	}
	if err := validateFulfillmentSubject(event, ""); err == nil {
		t.Fatal("empty order_id must be rejected")
	}
	if err := validateFulfillmentSubject(event, "ORD-T"); err == nil {
		t.Fatal("mismatched order_id must be rejected")
	}
}

func TestFulfillmentProcessDeliveryRequiresStorePool(t *testing.T) {
	fixture := newFulfillmentFixture()
	consumer := newTestConsumer(fixture.service)
	if err := consumer.ProcessDelivery(context.Background(), amqp.Delivery{}); err == nil ||
		!strings.Contains(err.Error(), "store is unavailable") {
		t.Fatalf("ProcessDelivery error=%v, want unavailable store", err)
	}
	var nilConsumer *Consumer
	if err := nilConsumer.ProcessDelivery(context.Background(), amqp.Delivery{}); err == nil {
		t.Fatal("nil consumer ProcessDelivery must fail")
	}
}

func TestRunConsumerRejectsMissingCollaborators(t *testing.T) {
	consumer := newTestConsumer(newFulfillmentFixture().service)
	routing := DeliveryRouting{}
	ctx := context.Background()
	if err := RunConsumer(ctx, nil, nilRouterStub{}, "queue", consumer, routing); err == nil {
		t.Fatal("nil channel must be rejected")
	}
	if err := RunConsumer(ctx, &amqp.Channel{}, nilRouterStub{}, "queue", nil, routing); err == nil {
		t.Fatal("nil consumer must be rejected")
	}
	if err := RunConsumer(ctx, &amqp.Channel{}, nil, "queue", consumer, routing); err == nil {
		t.Fatal("nil router must be rejected")
	}
}

func TestFulfillmentRetryAcknowledgerSettlesTransientAndTerminal(t *testing.T) {
	original := &acknowledgerStub{}
	publisher := &retryPublisherStub{}
	routing := DeliveryRouting{
		RetryExchange: "ful.retry.exchange", RetryRoutingKey: "ful.retry",
		DeadExchange: "ful.dead.exchange", DeadRoutingKey: "ful.dead",
	}
	acknowledger := &retryAcknowledger{
		original: original, publisher: publisher,
		delivery: amqp.Delivery{DeliveryTag: 3, MessageId: "evt-3", Body: []byte(`{}`)},
		routing:  routing, ctx: context.Background(),
	}

	// Transient Nack (no requeue, single delivery) routes to the retry queue.
	if err := acknowledger.Nack(3, false, false); err != nil {
		t.Fatal(err)
	}
	if publisher.exchange != routing.RetryExchange || publisher.key != routing.RetryRoutingKey {
		t.Fatalf("transient route=%s/%s, want retry queue", publisher.exchange, publisher.key)
	}
	if original.acks != 1 || original.nacks != 0 {
		t.Fatalf("acks=%d nacks=%d, want routed ack only", original.acks, original.nacks)
	}

	// Terminal Reject routes to the dead-letter exchange.
	original, publisher = &acknowledgerStub{}, &retryPublisherStub{}
	acknowledger = &retryAcknowledger{
		original: original, publisher: publisher,
		delivery: amqp.Delivery{DeliveryTag: 4, MessageId: "evt-4", Body: []byte(`{}`)},
		routing:  routing, ctx: context.Background(),
	}
	if err := acknowledger.Reject(4, false); err != nil {
		t.Fatal(err)
	}
	if publisher.exchange != routing.DeadExchange || publisher.key != routing.DeadRoutingKey {
		t.Fatalf("terminal route=%s/%s, want dead letter", publisher.exchange, publisher.key)
	}
	if original.rejects != 0 || original.acks != 1 {
		t.Fatalf("acks=%d rejects=%d, want routed ack only", original.acks, original.rejects)
	}
}

func TestFulfillmentRetryAcknowledgerPassthroughAndFailures(t *testing.T) {
	routing := DeliveryRouting{RetryExchange: "r", RetryRoutingKey: "r", DeadExchange: "d", DeadRoutingKey: "d"}
	delivery := amqp.Delivery{DeliveryTag: 9, MessageId: "evt-9", Body: []byte(`{}`)}

	// Requeue Nack and multiple Nack pass through to the original acknowledger.
	original := &acknowledgerStub{}
	acknowledger := &retryAcknowledger{original: original, routing: routing}
	if err := acknowledger.Nack(9, false, true); err != nil {
		t.Fatal(err)
	}
	if err := acknowledger.Nack(9, true, false); err != nil {
		t.Fatal(err)
	}
	// Requeue Reject passes through too.
	if err := acknowledger.Reject(9, true); err != nil {
		t.Fatal(err)
	}
	if original.nacks != 2 || original.rejects != 1 {
		t.Fatalf("nacks=%d rejects=%d, want passthrough settlements", original.nacks, original.rejects)
	}

	// Missing original acknowledger / publisher / routing is an error, and no
	// settlement may be acknowledged through a nil chain.
	if err := (&retryAcknowledger{publisher: retryPublisherNoop{}}).Nack(9, false, false); err == nil {
		t.Fatal("nil original acknowledger must fail")
	}
	if err := (&retryAcknowledger{original: &acknowledgerStub{}}).Reject(9, false); err == nil {
		t.Fatal("nil publisher must fail")
	}
	if err := (&retryAcknowledger{original: &acknowledgerStub{}, publisher: retryPublisherNoop{}}).
		Nack(9, false, false); err == nil {
		t.Fatal("empty routing must fail")
	}

	// A publish that is not confirmed must not ack the original delivery.
	original = &acknowledgerStub{}
	acknowledger = &retryAcknowledger{
		original: original, publisher: &retryPublisherStub{err: errors.New("nack confirmation")},
		delivery: delivery, routing: routing, ctx: context.Background(),
	}
	if err := acknowledger.Nack(9, false, false); err == nil {
		t.Fatal("unconfirmed route returned nil")
	}
	if original.acks != 0 {
		t.Fatalf("acks=%d, want zero on unconfirmed route", original.acks)
	}

	// A confirmed route whose ack fails surfaces the ack error.
	acknowledger = &retryAcknowledger{
		original: &failingAckStub{}, publisher: retryPublisherNoop{},
		delivery: delivery, routing: routing, ctx: context.Background(),
	}
	if err := acknowledger.Reject(9, false); err == nil || !strings.Contains(err.Error(), "ack routed") {
		t.Fatalf("ack failure error=%v, want ack error", err)
	}

	// Nil ctx defaults to context.Background instead of panicking.
	acknowledger = &retryAcknowledger{
		original: &acknowledgerStub{}, publisher: retryPublisherNoop{},
		delivery: delivery, routing: routing,
	}
	if err := acknowledger.Nack(9, false, false); err != nil {
		t.Fatalf("nil ctx route error: %v", err)
	}
}

func TestFulfillmentWorkerLifecycleWaitAndErrIfStopped(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	lifecycle := NewWorkerLifecycle(ctx, func(ctx context.Context) error {
		<-ctx.Done()
		return errors.New("fulfillment relay stopped")
	})
	if err := lifecycle.ErrIfStopped(); err != nil {
		t.Fatalf("running worker ErrIfStopped=%v, want nil", err)
	}
	cancel()
	waitCtx, waitCancel := context.WithTimeout(context.Background(), time.Second)
	defer waitCancel()
	if err := lifecycle.Wait(waitCtx); err == nil || err.Error() != "fulfillment relay stopped" {
		t.Fatalf("Wait error=%v, want terminal worker error", err)
	}
	if err := lifecycle.ErrIfStopped(); err == nil {
		t.Fatal("stopped worker ErrIfStopped must be non-nil")
	}
	select {
	case <-lifecycle.Done():
	default:
		t.Fatal("Done must be closed after the worker terminates")
	}

	// A clean exit yields the generic stopped sentinel.
	clean := NewWorkerLifecycle(context.Background(), func(context.Context) error { return nil })
	if err := clean.Wait(waitCtx); err != nil {
		t.Fatalf("clean Wait error=%v", err)
	}
	if err := clean.ErrIfStopped(); err == nil || !strings.Contains(err.Error(), "worker stopped") {
		t.Fatalf("clean ErrIfStopped=%v, want stopped sentinel", err)
	}

	// Wait honours caller cancellation, and nil lifecycles report unavailable.
	expiredCtx, expiredCancel := context.WithCancel(context.Background())
	expiredCancel()
	running := NewWorkerLifecycle(context.Background(), func(context.Context) error {
		time.Sleep(50 * time.Millisecond)
		return nil
	})
	if err := running.Wait(expiredCtx); !errors.Is(err, context.Canceled) {
		t.Fatalf("cancelled Wait error=%v, want context.Canceled", err)
	}
	var nilLifecycle *WorkerLifecycle
	if err := nilLifecycle.Wait(context.Background()); err == nil {
		t.Fatal("nil lifecycle Wait must fail")
	}
	if err := nilLifecycle.ErrIfStopped(); err == nil {
		t.Fatal("nil lifecycle ErrIfStopped must fail")
	}
}

func TestCombinePublisherAvailability(t *testing.T) {
	tests := []struct {
		name       string
		publishers []publisherAvailability
		want       bool
	}{
		{"empty is unavailable", nil, false},
		{"nil member is unavailable", []publisherAvailability{availabilityStub(true), nil}, false},
		{"single available", []publisherAvailability{availabilityStub(true)}, true},
		{"any unavailable blocks", []publisherAvailability{availabilityStub(true), availabilityStub(false)}, false},
		{"all available", []publisherAvailability{availabilityStub(true), availabilityStub(true)}, true},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if got := CombinePublisherAvailability(test.publishers...).Available(); got != test.want {
				t.Fatalf("Available()=%v, want %v", got, test.want)
			}
		})
	}
}

func TestFulfillmentRuntimeReadinessBranches(t *testing.T) {
	healthyWorker := func() *WorkerLifecycle {
		ctx, cancel := context.WithCancel(context.Background())
		t.Cleanup(cancel)
		return NewWorkerLifecycle(ctx, func(ctx context.Context) error {
			<-ctx.Done()
			return nil
		})
	}
	stoppedWorker := func() *WorkerLifecycle {
		return NewWorkerLifecycle(context.Background(), func(context.Context) error {
			return errors.New("boom")
		})
	}
	tests := []struct {
		name string
		build func() (func(context.Context) error, publisherAvailability, func() bool, []func(context.Context) error, []*WorkerLifecycle)
		wantErr  string
		waitFirst bool
	}{
		{
			name: "healthy",
			build: func() (func(context.Context) error, publisherAvailability, func() bool, []func(context.Context) error, []*WorkerLifecycle) {
				return func(context.Context) error { return nil }, availabilityStub(true),
					func() bool { return false }, nil, []*WorkerLifecycle{healthyWorker()}
			},
		},
		{
			name: "database probe unavailable",
			build: func() (func(context.Context) error, publisherAvailability, func() bool, []func(context.Context) error, []*WorkerLifecycle) {
				return nil, availabilityStub(true), nil, nil, nil
			},
			wantErr: "database readiness is unavailable",
		},
		{
			name: "database probe fails",
			build: func() (func(context.Context) error, publisherAvailability, func() bool, []func(context.Context) error, []*WorkerLifecycle) {
				return func(context.Context) error { return errors.New("pg down") }, availabilityStub(true),
					func() bool { return false }, nil, nil
			},
			wantErr: "pg down",
		},
		{
			name: "broker closed",
			build: func() (func(context.Context) error, publisherAvailability, func() bool, []func(context.Context) error, []*WorkerLifecycle) {
				return func(context.Context) error { return nil }, availabilityStub(true),
					func() bool { return true }, nil, nil
			},
			wantErr: "broker connection is closed",
		},
		{
			name: "publisher unavailable",
			build: func() (func(context.Context) error, publisherAvailability, func() bool, []func(context.Context) error, []*WorkerLifecycle) {
				return func(context.Context) error { return nil }, availabilityStub(false),
					func() bool { return false }, nil, nil
			},
			wantErr: "publisher is unavailable",
		},
		{
			name: "dependency probe nil",
			build: func() (func(context.Context) error, publisherAvailability, func() bool, []func(context.Context) error, []*WorkerLifecycle) {
				return func(context.Context) error { return nil }, availabilityStub(true),
					func() bool { return false }, []func(context.Context) error{nil}, nil
			},
			wantErr: "dependency 0 readiness is unavailable",
		},
		{
			name: "dependency probe fails",
			build: func() (func(context.Context) error, publisherAvailability, func() bool, []func(context.Context) error, []*WorkerLifecycle) {
				return func(context.Context) error { return nil }, availabilityStub(true),
					func() bool { return false }, []func(context.Context) error{
						func(context.Context) error { return errors.New("inventory down") },
					}, nil
			},
			wantErr: "dependency 0 is unavailable",
		},
		{
			name: "no workers",
			build: func() (func(context.Context) error, publisherAvailability, func() bool, []func(context.Context) error, []*WorkerLifecycle) {
				return func(context.Context) error { return nil }, availabilityStub(true),
					func() bool { return false }, nil, nil
			},
			wantErr: "workers are unavailable",
		},
		{
			name: "worker stopped",
			build: func() (func(context.Context) error, publisherAvailability, func() bool, []func(context.Context) error, []*WorkerLifecycle) {
				return func(context.Context) error { return nil }, availabilityStub(true),
					func() bool { return false }, nil, []*WorkerLifecycle{stoppedWorker()}
			},
			wantErr: "worker stopped",
			waitFirst: true,
		},
	}
	waitForWorkers := func(workers []*WorkerLifecycle) {
		waitCtx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		for _, worker := range workers {
			_ = worker.Wait(waitCtx)
		}
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			database, publisher, brokerClosed, dependencies, workers := test.build()
			if test.waitFirst {
				// The stopped-worker branch is only observable after the worker
				// goroutine has actually terminated.
				waitForWorkers(workers)
			}
			ready := NewRuntimeReadinessWithDependencies(
				database, publisher, brokerClosed, dependencies, workers...)
			err := ready(context.Background())
			waitForWorkers(workers)
			if test.wantErr == "" {
				if err != nil {
					t.Fatalf("readiness error=%v, want healthy", err)
				}
				return
			}
			if err == nil || !strings.Contains(err.Error(), test.wantErr) {
				t.Fatalf("readiness error=%v, want %q", err, test.wantErr)
			}
		})
	}

	// NewRuntimeReadiness delegates to the dependency-aware constructor.
	ready := NewRuntimeReadiness(
		func(context.Context) error { return nil }, availabilityStub(true), nil, healthyWorker())
	if err := ready(context.Background()); err != nil {
		t.Fatalf("NewRuntimeReadiness healthy error=%v", err)
	}
}

func TestNewConsumerAndWithRetryQueue(t *testing.T) {
	fixture := newFulfillmentFixture()
	consumer := NewConsumer(nil, fixture.service, messaging.RetryPolicy{MaxAttempts: 3})
	if consumer.service != fixture.service {
		t.Fatal("NewConsumer did not bind the service")
	}
	if got := consumer.WithRetryQueue("fulfillment.retry").retryQueue; got != "fulfillment.retry" {
		t.Fatalf("WithRetryQueue=%q", got)
	}
	// A nil receiver must not panic; the chain simply returns itself.
	var nilConsumer *Consumer
	if nilConsumer.WithRetryQueue("x") != nilConsumer {
		t.Fatal("WithRetryQueue on nil consumer must return the nil receiver")
	}
}

func TestFulfillmentRetryAcknowledgerAckPassthrough(t *testing.T) {
	original := &acknowledgerStub{}
	acknowledger := &retryAcknowledger{original: original}
	if err := acknowledger.Ack(11, false); err != nil {
		t.Fatal(err)
	}
	if original.acks != 1 {
		t.Fatalf("acks=%d, want passthrough ack", original.acks)
	}
	if err := (&retryAcknowledger{}).Ack(11, false); err == nil {
		t.Fatal("nil original acknowledger Ack must fail")
	}
}

func TestServicePropagatesStoreErrors(t *testing.T) {
	command := FulfillCommand{OrderID: "ORD-ERR", IdempotencyKey: "k-1"}
	cancel := CancelCommand{OrderID: "ORD-ERR", Reason: "x", IdempotencyKey: "k-2"}
	tests := []struct {
		name   string
		store  Store
		check  func(service *Service) error
		wantOp string
	}{
		{
			name:  "find fulfillment fails",
			store: &erroringStore{findFulfillment: errors.New("find down")},
			check: func(service *Service) error {
				_, err := service.FulfillOrder(context.Background(), command)
				return err
			},
			wantOp: "find fulfillment",
		},
		{
			name: "save fulfill fails",
			store: &erroringStore{saveFulfill: errors.New("save down")},
			check: func(service *Service) error {
				service.inventory = seededInventoryClient("ORD-ERR", allocationList{
					{SKU: "SKU-A", LocationID: "LOC-1", Quantity: 1},
				})
				_, err := service.FulfillOrder(context.Background(), command)
				return err
			},
			wantOp: "save down",
		},
		{
			name:  "list for cancel fails",
			store: &erroringStore{listByOrder: errors.New("list down")},
			check: func(service *Service) error {
				_, err := service.CancelOrder(context.Background(), cancel)
				return err
			},
			wantOp: "list fulfillment orders",
		},
		{
			name: "cancel save fails",
			store: &erroringStore{
				saveCancel: errors.New("cancel down"),
				orders: []FulfillmentOrder{{
					FulfillmentID: deterministicFulfillmentID("ORD-ERR", "LOC-1"),
					OrderID:       "ORD-ERR", LocationID: "LOC-1", Status: StatusOpen,
				}},
			},
			check: func(service *Service) error {
				_, err := service.CancelOrder(context.Background(), cancel)
				return err
			},
			wantOp: "cancel down",
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			service := NewService(test.store, nil, ServiceOptions{Clock: fixedFulfillmentClock})
			err := test.check(service)
			if err == nil {
				t.Fatal("expected store error to propagate")
			}
			if test.wantOp != "" && !strings.Contains(err.Error(), test.wantOp) {
				t.Fatalf("error=%v, want %q context", err, test.wantOp)
			}
		})
	}
}

// erroringStore injects failures per operation while succeeding elsewhere.
type erroringStore struct {
	findFulfillment error
	saveFulfill     error
	saveCancel      error
	listByOrder     error
	orders          []FulfillmentOrder
}

// seededInventoryClient returns a fake inventory client with one reservation
// set so FulfillOrder can reach the store write.
func seededInventoryClient(orderID string, allocations allocationList) *fakeInventoryClient {
	client := newFakeInventoryClient()
	client.seed(orderID, allocations)
	return client
}

func (store *erroringStore) FindFulfillment(context.Context, string) (FulfillOutcome, bool, error) {
	if store.findFulfillment != nil {
		return FulfillOutcome{}, false, store.findFulfillment
	}
	return FulfillOutcome{}, false, nil
}

func (store *erroringStore) SaveFulfill(_ context.Context, outcome FulfillOutcome) (FulfillResult, error) {
	if store.saveFulfill != nil {
		return FulfillResult{}, store.saveFulfill
	}
	return FulfillResult{FulfillmentOrders: outcome.FulfillmentOrders, Events: outcome.Events}, nil
}

func (store *erroringStore) SaveCancel(_ context.Context, outcome CancelOutcome) (CancelResult, error) {
	if store.saveCancel != nil {
		return CancelResult{}, store.saveCancel
	}
	return CancelResult{FulfillmentOrders: outcome.FulfillmentOrders, Events: outcome.Events}, nil
}

func (store *erroringStore) GetFulfillmentsByOrder(context.Context, string) ([]FulfillmentOrder, error) {
	if store.listByOrder != nil {
		return nil, store.listByOrder
	}
	return append([]FulfillmentOrder(nil), store.orders...), nil
}

var _ Store = (*erroringStore)(nil)

func TestConsumerApplyOrderPaidPropagatesServiceErrors(t *testing.T) {
	// No reservations seeded: the consumer surfaces ErrNoReservations so the
	// inbox settles the delivery terminally (re-delivery cannot fix upstream).
	fixture := newFulfillmentFixture()
	consumer := newTestConsumer(fixture.service)
	body, _ := json.Marshal(orderIDEventPayload{OrderID: "ORD-C-NORES"})
	event := messaging.NewEvent("order.paid.v1", "ORD-C-NORES", "corr", "", body,
		func() time.Time { return fixedFulfillmentClock() })
	if _, err := consumer.service.FulfillOrder(context.Background(), FulfillCommand{
		OrderID: "ORD-C-NORES", IdempotencyKey: "k",
	}); !errors.Is(err, ErrNoReservations) {
		t.Fatalf("FulfillOrder error=%v, want ErrNoReservations", err)
	}
	if err := consumer.applyEvent(event); err == nil {
		t.Fatal("applyEvent must propagate the service failure")
	}

	// A missing inventory client fails closed with ErrUpstreamUnavailable.
	bare := NewService(newFakeStore(), nil, ServiceOptions{Clock: fixedFulfillmentClock})
	if _, err := bare.FulfillOrder(context.Background(), FulfillCommand{
		OrderID: "ORD-C-NOCLIENT", IdempotencyKey: "k2",
	}); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("nil inventory client error=%v, want ErrUpstreamUnavailable", err)
	}
}

// --- shared stubs (fulfillment flavour; order keeps its own copies) ---

type acknowledgerStub struct {
	acks, nacks, rejects int
}

func (acknowledger *acknowledgerStub) Ack(uint64, bool) error {
	acknowledger.acks++
	return nil
}

func (acknowledger *acknowledgerStub) Nack(uint64, bool, bool) error {
	acknowledger.nacks++
	return nil
}

func (acknowledger *acknowledgerStub) Reject(uint64, bool) error {
	acknowledger.rejects++
	return nil
}

// failingAckStub fails the final Ack so the ack-error branch is observable.
type failingAckStub struct{ acknowledgerStub }

func (acknowledger *failingAckStub) Ack(uint64, bool) error {
	acknowledger.acks++
	return errors.New("channel closed")
}

type retryPublisherStub struct {
	exchange, key string
	err           error
	routed        atomic.Int32
}

func (publisher *retryPublisherStub) Route(_ context.Context, exchange, key string, _ amqp.Publishing) error {
	publisher.routed.Add(1)
	publisher.exchange, publisher.key = exchange, key
	return publisher.err
}

// retryPublisherNoop always confirms the route.
type retryPublisherNoop struct{}

func (retryPublisherNoop) Route(context.Context, string, string, amqp.Publishing) error {
	return nil
}

// nilRouterStub satisfies confirmedFulfillmentRouter without a broker.
type nilRouterStub struct{}

func (nilRouterStub) Route(context.Context, string, string, amqp.Publishing) error {
	return http.ErrNotSupported
}

type availabilityStub bool

func (available availabilityStub) Available() bool { return bool(available) }
