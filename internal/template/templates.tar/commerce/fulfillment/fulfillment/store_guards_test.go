package fulfillment

import (
	"context"
	"errors"
	"testing"
)

// TestPostgresStoreFailsClosedWithoutPool verifies every store operation
// degrades to a typed error (not a panic) when the pool is absent. The success
// paths execute real SQL against PostgreSQL and are covered by the
// integration suite behind the integration build tag.
func TestPostgresStoreFailsClosedWithoutPool(t *testing.T) {
	store := NewPostgresStore(nil, nil) // nil clock must default to time.Now
	ctx := context.Background()

	if _, found, err := store.FindFulfillment(ctx, "key"); found || err == nil {
		t.Fatalf("FindFulfillment found=%v err=%v, want unavailable error", found, err)
	}
	if _, err := store.GetFulfillmentsByOrder(ctx, "ORD-1"); err == nil {
		t.Fatal("GetFulfillmentsByOrder must fail without a pool")
	}
	if _, found, err := store.GetFulfillmentByID(ctx, "ful_1"); found || err == nil {
		t.Fatalf("GetFulfillmentByID found=%v err=%v, want unavailable error", found, err)
	}
	if _, err := store.ListItemsByFulfillment(ctx, "ful_1"); err == nil {
		t.Fatal("ListItemsByFulfillment must fail without a pool")
	}
	if _, err := store.ListPackagesByFulfillment(ctx, "ful_1"); err == nil {
		t.Fatal("ListPackagesByFulfillment must fail without a pool")
	}
	if _, err := store.GetShipmentByFulfillment(ctx, "ful_1"); err == nil {
		t.Fatal("GetShipmentByFulfillment must fail without a pool")
	}
	if _, err := store.SaveFulfill(ctx, FulfillOutcome{}); err == nil ||
		!errors.Is(err, err) {
		t.Fatal("SaveFulfill must fail without a pool")
	}
	if _, err := store.SaveCancel(ctx, CancelOutcome{}); err == nil {
		t.Fatal("SaveCancel must fail without a pool")
	}
}
