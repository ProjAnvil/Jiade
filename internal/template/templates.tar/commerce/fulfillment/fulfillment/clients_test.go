package fulfillment

import (
	"context"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	platformclient "commerce/lib/client"
)

// fulfillmentRoundTripper captures the upstream request and replies with a
// canned status/body, mirroring order's dependency-client test transport.
type fulfillmentRoundTripper struct {
	status int
	body   string
	err    error
	requests []*http.Request
}

func (transport *fulfillmentRoundTripper) RoundTrip(request *http.Request) (*http.Response, error) {
	transport.requests = append(transport.requests, request)
	if transport.err != nil {
		return nil, transport.err
	}
	return &http.Response{
		StatusCode: transport.status,
		Header:     http.Header{"Content-Type": []string{"application/json"}},
		Body:       io.NopCloser(strings.NewReader(transport.body)),
		Request:    request,
	}, nil
}

func newTestInventoryClient(handler http.HandlerFunc) (*InventoryHTTPClient, *httptest.Server) {
	server := httptest.NewServer(handler)
	resilient := platformclient.New(platformclient.Config{
		HTTPClient:   &http.Client{},
		MaxAttempts:  1,
		BaseBackoff:  time.Millisecond,
	})
	return NewInventoryHTTPClient(server.URL, resilient), server
}

func TestInventoryClientListReservationsDecodesAllocations(t *testing.T) {
	client, server := newTestInventoryClient(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			t.Errorf("method=%s, want GET", r.Method)
		}
		if !strings.HasSuffix(r.URL.Path, "/api/v1/reservations/ORD-CL-1") {
			t.Errorf("path=%q, want reservations lookup", r.URL.Path)
		}
		_, _ = w.Write([]byte(`{
			"order_id": "ORD-CL-1",
			"allocations": [
				{"sku": "SKU-A", "location_id": "LOC-1", "quantity": 2},
				{"sku": "", "location_id": "LOC-1", "quantity": 1},
				{"sku": "SKU-B", "location_id": "", "quantity": 1},
				{"sku": "SKU-C", "location_id": "LOC-2", "quantity": 0},
				{"sku": "SKU-D", "location_id": "LOC-2", "quantity": 5, "reserved_at": "extra"}
			]
		}`))
	})
	defer server.Close()

	result, err := client.ListReservations(context.Background(), "ORD-CL-1")
	if err != nil {
		t.Fatalf("ListReservations error: %v", err)
	}
	if result.OrderID != "ORD-CL-1" {
		t.Fatalf("OrderID=%q, want ORD-CL-1", result.OrderID)
	}
	// Invalid entries (blank sku/location, non-positive quantity) are dropped;
	// additive upstream fields (reserved_at) are tolerated by the lenient decoder.
	if len(result.Allocations) != 2 {
		t.Fatalf("allocations=%+v, want 2 valid entries", result.Allocations)
	}
	if result.Allocations[0].SKU != "SKU-A" || result.Allocations[1].SKU != "SKU-D" {
		t.Fatalf("allocations=%+v, want SKU-A and SKU-D", result.Allocations)
	}
}

func TestInventoryClientListReservationsDefaultsOrderID(t *testing.T) {
	client, server := newTestInventoryClient(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte(`{"order_id":"","allocations":[{"sku":"SKU-A","location_id":"LOC-1","quantity":1}]}`))
	})
	defer server.Close()

	result, err := client.ListReservations(context.Background(), "ORD-CL-2")
	if err != nil {
		t.Fatalf("ListReservations error: %v", err)
	}
	if result.OrderID != "ORD-CL-2" {
		t.Fatalf("OrderID=%q, want requested ORD-CL-2 when upstream omits it", result.OrderID)
	}
}

func TestInventoryClientListReservationsTreatsNotFoundAsEmpty(t *testing.T) {
	client, server := newTestInventoryClient(http.NotFound)
	defer server.Close()

	result, err := client.ListReservations(context.Background(), "ORD-CL-3")
	if err != nil {
		t.Fatalf("ListReservations error: %v (404 must not be an error)", err)
	}
	if result.OrderID != "ORD-CL-3" || len(result.Allocations) != 0 {
		t.Fatalf("result=%+v, want empty allocations for missing reservation", result)
	}
}

func TestInventoryClientListReservationsRejectsUpstreamFailures(t *testing.T) {
	tests := []struct {
		name    string
		handler http.HandlerFunc
	}{
		{"server error", func(w http.ResponseWriter, r *http.Request) {
			w.WriteHeader(http.StatusInternalServerError)
		}},
		{"malformed json", func(w http.ResponseWriter, r *http.Request) {
			_, _ = w.Write([]byte(`{not json`))
		}},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			client, server := newTestInventoryClient(test.handler)
			defer server.Close()
			if _, err := client.ListReservations(context.Background(), "ORD-CL-4"); !errors.Is(err, ErrUpstreamUnavailable) {
				t.Fatalf("ListReservations error=%v, want ErrUpstreamUnavailable", err)
			}
		})
	}
}

func TestInventoryClientListReservationsGuards(t *testing.T) {
	var nilClient *InventoryHTTPClient
	if _, err := nilClient.ListReservations(context.Background(), "ORD-1"); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("nil client error=%v, want ErrUpstreamUnavailable", err)
	}
	bare := &InventoryHTTPClient{}
	if _, err := bare.ListReservations(context.Background(), "ORD-1"); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("missing resilient client error=%v, want ErrUpstreamUnavailable", err)
	}
	client, server := newTestInventoryClient(func(w http.ResponseWriter, r *http.Request) {
		t.Error("no upstream call expected for an empty order id")
	})
	defer server.Close()
	if _, err := client.ListReservations(context.Background(), "   "); !errors.Is(err, ErrInvalidCommand) {
		t.Fatalf("blank order id error=%v, want ErrInvalidCommand", err)
	}
}

func TestInventoryClientReadyProbesReadiness(t *testing.T) {
	tests := []struct {
		name    string
		status  int
		wantErr bool
	}{
		{"ready", http.StatusOK, false},
		{"unavailable", http.StatusServiceUnavailable, true},
		{"server error", http.StatusInternalServerError, true},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			client, server := newTestInventoryClient(func(w http.ResponseWriter, r *http.Request) {
				if !strings.HasSuffix(r.URL.Path, "/readyz") {
					t.Errorf("path=%q, want /readyz", r.URL.Path)
				}
				w.WriteHeader(test.status)
			})
			defer server.Close()
			err := client.Ready(context.Background())
			if (err != nil) != test.wantErr {
				t.Fatalf("Ready() error=%v, wantErr=%v", err, test.wantErr)
			}
		})
	}
}

func TestInventoryClientReadyGuards(t *testing.T) {
	var nilClient *InventoryHTTPClient
	if err := nilClient.Ready(context.Background()); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("nil client Ready error=%v, want ErrUpstreamUnavailable", err)
	}
	if err := (&InventoryHTTPClient{}).Ready(context.Background()); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("missing resilient client Ready error=%v, want ErrUpstreamUnavailable", err)
	}
	if err := (&InventoryHTTPClient{client: platformclient.New(platformclient.Config{})}).
		Ready(context.Background()); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("blank base URL Ready error=%v, want ErrUpstreamUnavailable", err)
	}
}

func TestNewInventoryHTTPClientTrimsTrailingSlash(t *testing.T) {
	client := NewInventoryHTTPClient("http://inventory.test/", nil)
	if client.baseURL != "http://inventory.test" {
		t.Fatalf("baseURL=%q, want trailing slash trimmed", client.baseURL)
	}
}
