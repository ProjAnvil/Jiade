package fulfillment

import (
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
)

// The HTTP surface binds NewHandler to the concrete PostgresStore (live
// database required), but the response writers are package-level helpers with
// pure behaviour; these tests exercise them directly.

func TestWriteFulfillmentJSONEncodesBody(t *testing.T) {
	recorder := httptest.NewRecorder()
	writeFulfillmentJSON(recorder, http.StatusCreated, map[string]any{"order_id": "ORD-H-1"})
	if recorder.Code != http.StatusCreated {
		t.Fatalf("status=%d, want 201", recorder.Code)
	}
	if mediaType := recorder.Header().Get("Content-Type"); mediaType != "application/json" {
		t.Fatalf("content-type=%q", mediaType)
	}
	var body map[string]any
	if err := json.Unmarshal(recorder.Body.Bytes(), &body); err != nil {
		t.Fatalf("decode body: %v", err)
	}
	if body["order_id"] != "ORD-H-1" {
		t.Fatalf("body=%v", body)
	}
}

func TestWriteFulfillmentProblemIncludesInstance(t *testing.T) {
	recorder := httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodGet, "/api/v1/fulfillment/orders/ORD-404", nil)
	writeFulfillmentProblem(recorder, request, http.StatusNotFound, "fulfillment_not_found")
	if recorder.Code != http.StatusNotFound {
		t.Fatalf("status=%d, want 404", recorder.Code)
	}
	var problem struct {
		Status   int    `json:"status"`
		Code     string `json:"code"`
		Instance string `json:"instance"`
	}
	if err := json.Unmarshal(recorder.Body.Bytes(), &problem); err != nil {
		t.Fatalf("decode problem: %v", err)
	}
	if problem.Code != "fulfillment_not_found" || problem.Instance != "/api/v1/fulfillment/orders/ORD-404" {
		t.Fatalf("problem=%+v", problem)
	}
}

func TestWriteFulfillmentStoreErrorClassifies(t *testing.T) {
	request := httptest.NewRequest(http.MethodGet, "/api/v1/fulfillment/x", nil)

	recorder := httptest.NewRecorder()
	if handled := writeFulfillmentStoreError(recorder, request, nil); handled {
		t.Fatal("nil error must not be handled")
	}

	recorder = httptest.NewRecorder()
	if handled := writeFulfillmentStoreError(recorder, request, ErrFulfillmentNotFound); !handled {
		t.Fatal("not-found error must be handled")
	}
	if recorder.Code != http.StatusNotFound {
		t.Fatalf("not-found status=%d, want 404", recorder.Code)
	}

	recorder = httptest.NewRecorder()
	if handled := writeFulfillmentStoreError(recorder, request, errors.New("pool exhausted")); !handled {
		t.Fatal("unexpected error must be handled")
	}
	if recorder.Code != http.StatusInternalServerError {
		t.Fatalf("internal status=%d, want 500", recorder.Code)
	}
}

// TestFulfillmentHandlerValidationAndStoreErrors drives the read-only handler
// against a store with no pool: assert() degrades to an error instead of
// panicking, so the validation and error-mapping branches are observable
// without a live database. The success projections require postgres and are
// covered by the integration suite.
func TestFulfillmentHandlerValidationAndStoreErrors(t *testing.T) {
	handler := NewHandler(NewPostgresStore(nil, fixedFulfillmentClock))

	// Blank order id is rejected before the store is touched.
	recorder := httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodGet, "/api/v1/fulfillment/orders/%20", nil)
	request.SetPathValue("id", "  ")
	handler.ServeHTTP(recorder, request)
	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("blank order id status=%d, want 400", recorder.Code)
	}

	// Blank fulfillment id is rejected before the store is touched.
	recorder = httptest.NewRecorder()
	request = httptest.NewRequest(http.MethodGet, "/api/v1/fulfillment/%20", nil)
	request.SetPathValue("fulfillment_id", "  ")
	handler.ServeHTTP(recorder, request)
	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("blank fulfillment id status=%d, want 400", recorder.Code)
	}

	// A store without a pool surfaces as the mapped internal problem for both
	// lookups instead of a panic.
	for _, path := range []string{
		"/api/v1/fulfillment/orders/ORD-STORE",
		"/api/v1/fulfillment/ful_STORE",
	} {
		recorder = httptest.NewRecorder()
		request = httptest.NewRequest(http.MethodGet, path, nil)
		handler.ServeHTTP(recorder, request)
		if recorder.Code != http.StatusInternalServerError {
			t.Fatalf("GET %s status=%d, want 500 (store unavailable)", path, recorder.Code)
		}
		var problem struct {
			Code string `json:"code"`
		}
		if err := json.Unmarshal(recorder.Body.Bytes(), &problem); err != nil {
			t.Fatalf("decode problem: %v", err)
		}
		if problem.Code != "internal_error" {
			t.Fatalf("GET %s code=%q, want internal_error", path, problem.Code)
		}
	}
}
