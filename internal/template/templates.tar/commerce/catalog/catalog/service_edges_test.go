package catalog

import (
	"context"
	"encoding/base64"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestDecodeCursorRejectsMalformedInput(t *testing.T) {
	raw := func(body string) string {
		return base64.RawURLEncoding.EncodeToString([]byte(body))
	}
	tests := []struct {
		name   string
		cursor string
	}{
		{"not base64", "!!!"},
		{"not json", raw("plain")},
		{"wrong version", raw(`{"v":2,"id":"p1"}`)},
		{"empty id", raw(`{"v":1,"id":""}`)},
		{"padded id", raw(`{"v":1,"id":" p1"}`)},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if _, err := decodeCursor(test.cursor); !errors.Is(err, errInvalidCursor) {
				t.Fatalf("decodeCursor(%q) error=%v, want errInvalidCursor", test.cursor, err)
			}
		})
	}
	if id, err := decodeCursor(""); err != nil || id != "" {
		t.Fatalf("empty cursor id=%q err=%v", id, err)
	}
	if id, err := decodeCursor(encodeCursor("p1")); err != nil || id != "p1" {
		t.Fatalf("round trip id=%q err=%v", id, err)
	}
}

func TestNormalizePageSizeBounds(t *testing.T) {
	tests := []struct{ requested, want int }{
		{0, DefaultPageSize},
		{-3, DefaultPageSize},
		{1, 1},
		{MaxPageSize, MaxPageSize},
		{MaxPageSize + 1, MaxPageSize},
	}
	for _, test := range tests {
		if got := normalizePageSize(test.requested); got != test.want {
			t.Errorf("normalizePageSize(%d)=%d, want %d", test.requested, got, test.want)
		}
	}
}

func TestGetProductValidationAndStoreErrors(t *testing.T) {
	service := NewService(&catalogStoreStub{})
	if _, err := service.GetProduct(context.Background(), "   "); !errors.Is(err, ErrProductNotFound) {
		t.Fatalf("blank id error=%v, want ErrProductNotFound", err)
	}
	failing := NewService(&catalogStoreStub{err: errors.New("pool exhausted")})
	if _, err := failing.GetProduct(context.Background(), "p1"); err == nil {
		t.Fatal("store errors must propagate")
	}
	if _, err := failing.ListProducts(context.Background(), "", 10); err == nil ||
		!strings.Contains(err.Error(), "list catalog products") {
		t.Fatal("ListProducts must wrap store errors")
	}
	if _, err := failing.GetCheckoutSnapshot(context.Background(), "SKU-1"); err == nil {
		t.Fatal("GetCheckoutSnapshot must propagate store errors")
	}
}

func TestListProductsEmptyTailPageIsNotNull(t *testing.T) {
	store := &catalogStoreStub{products: []Product{{ID: "p1"}}}
	service := NewService(store)
	// A cursor past the last product yields an empty, non-nil items array.
	pastEnd := encodeCursor("p9")
	page, err := service.ListProducts(context.Background(), pastEnd, 10)
	if err != nil {
		t.Fatal(err)
	}
	if page.Items == nil || len(page.Items) != 0 {
		t.Fatalf("items=%v, want empty non-nil", page.Items)
	}
	if page.NextCursor != "" {
		t.Fatalf("next cursor=%q, want empty", page.NextCursor)
	}
}

func TestGetCheckoutSnapshotValidatesSaleability(t *testing.T) {
	valid := CheckoutSnapshot{
		ProductID: "prod-1", SKU: "SKU-1", ProductTitle: "Shirt", VariantTitle: "Blue",
		UnitPriceMinor: 1000, Currency: "CNY", Status: "active",
	}
	tests := []struct {
		name   string
		mutate func(*CheckoutSnapshot)
	}{
		{"missing product id", func(snapshot *CheckoutSnapshot) { snapshot.ProductID = "" }},
		{"sku mismatch", func(snapshot *CheckoutSnapshot) { snapshot.SKU = "SKU-OTHER" }},
		{"missing product title", func(snapshot *CheckoutSnapshot) { snapshot.ProductTitle = "" }},
		{"missing variant title", func(snapshot *CheckoutSnapshot) { snapshot.VariantTitle = "" }},
		{"negative price", func(snapshot *CheckoutSnapshot) { snapshot.UnitPriceMinor = -1 }},
		{"bad currency length", func(snapshot *CheckoutSnapshot) { snapshot.Currency = "CNYX" }},
		{"inactive status", func(snapshot *CheckoutSnapshot) { snapshot.Status = "inactive" }},
		{"unknown channel", func(snapshot *CheckoutSnapshot) { snapshot.Channel = "pos" }},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			snapshot := valid
			test.mutate(&snapshot)
			service := NewService(&catalogStoreStub{snapshot: snapshot})
			if _, err := service.GetCheckoutSnapshot(context.Background(), "SKU-1"); !errors.Is(err, ErrSKUNotSaleable) {
				t.Fatalf("error=%v, want ErrSKUNotSaleable", err)
			}
		})
	}

	// Blank SKU short-circuits to not-found without a store hit.
	if _, err := NewService(&catalogStoreStub{}).GetCheckoutSnapshot(context.Background(), "  "); !errors.Is(err, ErrSKUNotFound) {
		t.Fatalf("blank sku error=%v, want ErrSKUNotFound", err)
	}

	// A valid snapshot is defaulted and flagged for sale.
	service := NewService(&catalogStoreStub{snapshot: valid})
	snapshot, err := service.GetCheckoutSnapshot(context.Background(), "SKU-1")
	if err != nil {
		t.Fatal(err)
	}
	if !snapshot.AvailableForSale {
		t.Fatal("valid snapshot must be flagged available")
	}
	if snapshot.Title != "Shirt — Blue" {
		t.Fatalf("Title=%q, want composed default", snapshot.Title)
	}
	if snapshot.Attributes == nil {
		t.Fatal("Attributes must default to an empty map, not null")
	}
	// Explicit titles and attributes pass through untouched.
	explicit := valid
	explicit.Title = "Custom"
	explicit.Attributes = map[string]any{"color": "blue"}
	got, err := NewService(&catalogStoreStub{snapshot: explicit}).GetCheckoutSnapshot(context.Background(), "SKU-1")
	if err != nil {
		t.Fatal(err)
	}
	if got.Title != "Custom" || got.Attributes["color"] != "blue" {
		t.Fatalf("snapshot=%+v, want explicit fields preserved", got)
	}
}

func TestCatalogHandlerMapsValidationAndStoreErrors(t *testing.T) {
	handler := NewHandler(NewService(&catalogStoreStub{}))

	// Blank product id maps to product-not-found.
	recorder := httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodGet, "/api/v1/products/%20", nil)
	request.SetPathValue("id", "  ")
	handler.ServeHTTP(recorder, request)
	if recorder.Code != http.StatusNotFound {
		t.Fatalf("blank product id status=%d, want 404", recorder.Code)
	}

	// Invalid page size is a 400.
	recorder = httptest.NewRecorder()
	handler.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/products?page_size=0", nil))
	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("page_size=0 status=%d, want 400", recorder.Code)
	}

	// Store failures surface as internal_error on all three endpoints.
	failing := NewHandler(NewService(&catalogStoreStub{
		err: errors.New("db down"), snapshotErr: errors.New("db down"),
	}))
	for _, path := range []string{"/api/v1/products", "/api/v1/products/p1", "/internal/v1/catalog/skus/SKU-1"} {
		recorder = httptest.NewRecorder()
		failing.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, path, nil))
		if recorder.Code != http.StatusInternalServerError {
			t.Fatalf("GET %s status=%d, want 500", path, recorder.Code)
		}
	}
}

func TestParsePageSizeValidation(t *testing.T) {
	tests := []struct {
		raw     string
		want    int
		wantErr bool
	}{
		{"", 0, false},
		{"15", 15, false},
		{"0", 0, true},
		{"-2", 0, true},
		{"NaN", 0, true},
	}
	for _, test := range tests {
		request := httptest.NewRequest(http.MethodGet, "/api/v1/products?page_size="+test.raw, nil)
		size, err := parsePageSize(request)
		if (err != nil) != test.wantErr {
			t.Errorf("parsePageSize(%q) error=%v", test.raw, err)
			continue
		}
		if size != test.want {
			t.Errorf("parsePageSize(%q)=%d, want %d", test.raw, size, test.want)
		}
	}
}
