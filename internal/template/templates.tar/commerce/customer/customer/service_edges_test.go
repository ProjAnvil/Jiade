package customer

import (
	"context"
	"encoding/base64"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func usableTestAddress() Address {
	return Address{
		ID: "ADDR-1", CustomerID: "CUS-1", Recipient: "Buyer", Phone: "13800000000",
		CountryCode: "CN", Province: "GD", City: "SZ", District: "NS", Line1: "1 Way", PostalCode: "518000",
	}
}

func TestDecodeCustomerCursorRejectsMalformedInput(t *testing.T) {
	raw := func(body string) string {
		return base64.RawURLEncoding.EncodeToString([]byte(body))
	}
	tests := []struct {
		name   string
		cursor string
	}{
		{"not base64", "!!!"},
		{"not json", raw("plain")},
		{"wrong version", raw(`{"v":0,"id":"c1"}`)},
		{"empty id", raw(`{"v":1,"id":""}`)},
		{"padded id", raw(`{"v":1,"id":" c1"}`)},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if _, err := decodeCustomerCursor(test.cursor); !errors.Is(err, errInvalidCursor) {
				t.Fatalf("decodeCustomerCursor(%q) error=%v, want errInvalidCursor", test.cursor, err)
			}
		})
	}
	if id, err := decodeCustomerCursor(""); err != nil || id != "" {
		t.Fatalf("empty cursor id=%q err=%v", id, err)
	}
	if id, err := decodeCustomerCursor(encodeCustomerCursor("c1")); err != nil || id != "c1" {
		t.Fatalf("round trip id=%q err=%v", id, err)
	}
}

func TestNormalizeCustomerPageSizeBounds(t *testing.T) {
	tests := []struct{ requested, want int }{
		{0, DefaultPageSize},
		{-1, DefaultPageSize},
		{7, 7},
		{MaxPageSize, MaxPageSize},
		{MaxPageSize + 1, MaxPageSize},
	}
	for _, test := range tests {
		if got := normalizeCustomerPageSize(test.requested); got != test.want {
			t.Errorf("normalizeCustomerPageSize(%d)=%d, want %d", test.requested, got, test.want)
		}
	}
}

func TestListCustomersCanonicalisesAndHandlesEmptyTail(t *testing.T) {
	chinaZone := time.FixedZone("CST", 8*60*60)
	store := &customerStoreStub{customers: []Customer{{
		ID: "CUS-1", Status: "active",
		CreatedAt: time.Date(2026, 7, 24, 20, 0, 0, 0, chinaZone),
	}}}
	service := NewService(store)

	// A cursor past the last customer yields an empty, non-nil items array.
	page, err := service.ListCustomers(context.Background(), encodeCustomerCursor("CUS-9"), 10)
	if err != nil {
		t.Fatal(err)
	}
	if page.Items == nil || len(page.Items) != 0 {
		t.Fatalf("items=%v, want empty non-nil", page.Items)
	}
	// The first page canonicalises timestamps to UTC.
	page, err = service.ListCustomers(context.Background(), "", 10)
	if err != nil {
		t.Fatal(err)
	}
	if len(page.Items) != 1 || page.Items[0].CreatedAt.Location() != time.UTC {
		t.Fatalf("items=%+v, want canonical UTC timestamps", page.Items)
	}
}

func TestGetCustomerValidation(t *testing.T) {
	service := NewService(&customerStoreStub{})
	if _, err := service.GetCustomer(context.Background(), "   "); !errors.Is(err, ErrCustomerNotFound) {
		t.Fatalf("blank id error=%v, want ErrCustomerNotFound", err)
	}
	if _, err := service.GetCustomer(context.Background(), "CUS-MISSING"); !errors.Is(err, ErrCustomerNotFound) {
		t.Fatalf("unknown id error=%v, want ErrCustomerNotFound", err)
	}
}

func TestValidateAddressOwnershipAndStatusRules(t *testing.T) {
	address := usableTestAddress()
	tests := []struct {
		name   string
		mutate func(*AddressValidation)
	}{
		{"validation customer mismatch", func(validation *AddressValidation) {
			validation.CustomerID = "CUS-OTHER"
		}},
		{"address customer mismatch", func(validation *AddressValidation) {
			validation.Address.CustomerID = "CUS-OTHER"
		}},
		{"suspended customer", func(validation *AddressValidation) {
			validation.CustomerStatus = "suspended"
		}},
		{"missing recipient", func(validation *AddressValidation) {
			validation.Address.Recipient = " "
		}},
		{"missing phone", func(validation *AddressValidation) {
			validation.Address.Phone = ""
		}},
		{"missing province", func(validation *AddressValidation) {
			validation.Address.Province = ""
		}},
		{"missing city", func(validation *AddressValidation) {
			validation.Address.City = ""
		}},
		{"missing district", func(validation *AddressValidation) {
			validation.Address.District = ""
		}},
		{"missing line1", func(validation *AddressValidation) {
			validation.Address.Line1 = ""
		}},
		{"missing postal code", func(validation *AddressValidation) {
			validation.Address.PostalCode = ""
		}},
		{"bad country code length", func(validation *AddressValidation) {
			validation.Address.CountryCode = "CHN"
		}},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			validation := AddressValidation{
				CustomerID: "CUS-1", CustomerStatus: "active", Address: address,
			}
			test.mutate(&validation)
			service := NewService(&customerStoreStub{validation: validation})
			if _, err := service.ValidateAddress(context.Background(), "CUS-1", "ADDR-1"); !errors.Is(err, ErrAddressNotUsable) {
				t.Fatalf("error=%v, want ErrAddressNotUsable", err)
			}
		})
	}

	// Blank identifiers and store failures fail closed.
	service := NewService(&customerStoreStub{})
	if _, err := service.ValidateAddress(context.Background(), " ", "ADDR-1"); !errors.Is(err, ErrAddressNotUsable) {
		t.Fatalf("blank customer error=%v", err)
	}
	if _, err := service.ValidateAddress(context.Background(), "CUS-1", ""); !errors.Is(err, ErrAddressNotUsable) {
		t.Fatalf("blank address error=%v", err)
	}
	failing := NewService(&customerStoreStub{validationErr: errors.New("db down")})
	if _, err := failing.ValidateAddress(context.Background(), "CUS-1", "ADDR-1"); err == nil {
		t.Fatal("store errors must propagate")
	}

	// Guest customers may also validate addresses.
	guest := AddressValidation{
		CustomerID: "CUS-1", CustomerStatus: "guest", Address: address,
	}
	result, err := NewService(&customerStoreStub{validation: guest}).
		ValidateAddress(context.Background(), "CUS-1", "ADDR-1")
	if err != nil {
		t.Fatal(err)
	}
	if !result.Valid || result.Customer.ID != "CUS-1" {
		t.Fatalf("result=%+v, want valid guest validation", result)
	}
}

func TestCustomerHandlerMapsValidationAndStoreErrors(t *testing.T) {
	handler := NewHandler(NewService(&customerStoreStub{}))

	recorder := httptest.NewRecorder()
	handler.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/customers?page_size=-1", nil))
	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("page_size=-1 status=%d, want 400", recorder.Code)
	}

	recorder = httptest.NewRecorder()
	handler.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/customers?cursor=%21", nil))
	if recorder.Code != http.StatusBadRequest {
		t.Fatalf("bad cursor status=%d, want 400", recorder.Code)
	}

	recorder = httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodGet, "/api/v1/customers/%20", nil)
	request.SetPathValue("id", "  ")
	handler.ServeHTTP(recorder, request)
	if recorder.Code != http.StatusNotFound {
		t.Fatalf("blank id status=%d, want 404", recorder.Code)
	}
}

func TestParseCustomerPageSizeValidation(t *testing.T) {
	tests := []struct {
		raw     string
		want    int
		wantErr bool
	}{
		{"", 0, false},
		{"9", 9, false},
		{"0", 0, true},
		{"-4", 0, true},
		{"x", 0, true},
	}
	for _, test := range tests {
		request := httptest.NewRequest(http.MethodGet, "/api/v1/customers?page_size="+test.raw, nil)
		size, err := parseCustomerPageSize(request)
		if (err != nil) != test.wantErr {
			t.Errorf("parseCustomerPageSize(%q) error=%v", test.raw, err)
			continue
		}
		if size != test.want {
			t.Errorf("parseCustomerPageSize(%q)=%d, want %d", test.raw, size, test.want)
		}
	}
}

func TestUsableAddressRequiresEveryField(t *testing.T) {
	if !usableAddress(usableTestAddress()) {
		t.Fatal("complete address must be usable")
	}
	trimmed := usableTestAddress()
	trimmed.ID = ""
	if usableAddress(trimmed) {
		t.Fatal("address without id must be unusable")
	}
}
