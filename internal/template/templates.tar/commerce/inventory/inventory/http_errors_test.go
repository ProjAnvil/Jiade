package inventory

import (
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestInventoryListRejectsBadPageSizeAndCursor(t *testing.T) {
	handler := NewHandler(NewService(newInventoryStoreStub(), fixedInventoryClock))

	recorder := httptest.NewRecorder()
	handler.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/inventory?page_size=0", nil))
	assertInventoryProblem(t, recorder, http.StatusBadRequest, "invalid_page_size")

	recorder = httptest.NewRecorder()
	handler.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/inventory?page_size=abc", nil))
	assertInventoryProblem(t, recorder, http.StatusBadRequest, "invalid_page_size")

	recorder = httptest.NewRecorder()
	handler.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/inventory?cursor=%21%21%21", nil))
	assertInventoryProblem(t, recorder, http.StatusBadRequest, "invalid_cursor")

	recorder = httptest.NewRecorder()
	handler.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/inventory", nil))
	if recorder.Code != http.StatusOK {
		t.Fatalf("default list status=%d body=%s", recorder.Code, recorder.Body.String())
	}
}

func TestInventorySKUEndpointMapsErrors(t *testing.T) {
	handler := NewHandler(NewService(newInventoryStoreStub(), fixedInventoryClock))

	// A SKU with no level rows is a 404, not a 500.
	recorder := httptest.NewRecorder()
	handler.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/inventory/SKU-MISSING", nil))
	assertInventoryProblem(t, recorder, http.StatusNotFound, "sku_not_found")

	// Store failures surface as internal_error.
	failing := NewHandler(NewService(&inventoryFailingStore{}, fixedInventoryClock))
	recorder = httptest.NewRecorder()
	failing.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/inventory/SKU-1", nil))
	assertInventoryProblem(t, recorder, http.StatusInternalServerError, "internal_error")

	// List store failures surface as internal_error too.
	recorder = httptest.NewRecorder()
	failing.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/inventory", nil))
	assertInventoryProblem(t, recorder, http.StatusInternalServerError, "internal_error")
}

func TestReservationsByOrderEndpoint(t *testing.T) {
	store := newInventoryStoreStub()
	store.reservations["k"] = ReservationResult{
		OrderID: "ORD-LOOKUP",
		Allocations: []ReservationAllocation{{
			ID: "RES-1", OrderID: "ORD-LOOKUP", SKU: "SKU-1", LocationID: "LOC-1",
			Quantity: 2, State: ReservationActive,
		}},
	}
	handler := NewHandler(NewService(store, fixedInventoryClock))

	recorder := httptest.NewRecorder()
	handler.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/reservations/ORD-LOOKUP", nil))
	if recorder.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", recorder.Code, recorder.Body.String())
	}
	var result ReservationResult
	if err := json.Unmarshal(recorder.Body.Bytes(), &result); err != nil {
		t.Fatal(err)
	}
	if result.OrderID != "ORD-LOOKUP" || len(result.Allocations) != 1 {
		t.Fatalf("result=%+v", result)
	}

	// Blank order id resolves to not-found without a store hit.
	recorder = httptest.NewRecorder()
	handler.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/reservations/%20", nil))
	if recorder.Code != http.StatusInternalServerError {
		t.Fatalf("blank order id status=%d, want 500 (mapped reservation error)", recorder.Code)
	}

	// Store failures surface as internal_error.
	failing := NewHandler(NewService(&inventoryFailingStore{}, fixedInventoryClock))
	recorder = httptest.NewRecorder()
	failing.ServeHTTP(recorder, httptest.NewRequest(http.MethodGet, "/api/v1/reservations/ORD-X", nil))
	assertInventoryProblem(t, recorder, http.StatusInternalServerError, "internal_error")
}

func TestReservationActionEndpointValidation(t *testing.T) {
	handler := NewHandler(NewService(newInventoryStoreStub(), fixedInventoryClock))

	// Unknown action is a 404 before the service is called.
	recorder := postInventoryJSON(handler, "/internal/v1/reservations/ORD-1/unknown", `{}`, "")
	assertInventoryProblem(t, recorder, http.StatusNotFound, "reservation_action_not_found")

	// Non-JSON content type is rejected.
	recorder = httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodPost, "/internal/v1/reservations/ORD-1/release", strings.NewReader(`{}`))
	request.Header.Set("Content-Type", "text/plain")
	handler.ServeHTTP(recorder, request)
	assertInventoryProblem(t, recorder, http.StatusUnsupportedMediaType, "json_content_type_required")

	// A trailing second JSON value is rejected.
	recorder = postInventoryJSON(handler, "/internal/v1/reservations/ORD-1/release", `{} {}`, "")
	assertInventoryProblem(t, recorder, http.StatusBadRequest, "invalid_json")

	// An invalid transition order (blank id) maps to invalid_reservation.
	recorder = postInventoryJSON(handler, "/internal/v1/reservations/%20/release", `{}`, "")
	assertInventoryProblem(t, recorder, http.StatusBadRequest, "invalid_reservation")
}

func TestWriteInventoryServiceErrorClassification(t *testing.T) {
	request := httptest.NewRequest(http.MethodPost, "/internal/v1/reservations", nil)
	tests := []struct {
		name     string
		err      error
		want     int
		wantCode string
	}{
		{"nil", nil, 0, ""},
		{"invalid command", ErrInvalidCommand, http.StatusBadRequest, "invalid_reservation"},
		{"sku not found", ErrSKUNotFound, http.StatusNotFound, "sku_not_found"},
		{"insufficient stock", ErrInsufficientStock, http.StatusConflict, "insufficient_stock"},
		{"idempotency conflict", ErrIdempotencyConflict, http.StatusConflict, "idempotency_conflict"},
		{"order terminal", ErrOrderTerminal, http.StatusConflict, "order_terminal"},
		{"reservation not found", ErrReservationNotFound, http.StatusNotFound, "reservation_not_found"},
		{"internal", errors.New("boom"), http.StatusInternalServerError, "internal_error"},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			recorder := httptest.NewRecorder()
			handled := writeInventoryServiceError(recorder, request, test.err)
			if test.want == 0 {
				if handled {
					t.Fatal("nil error must not be handled")
				}
				return
			}
			if !handled {
				t.Fatal("error must be handled")
			}
			if recorder.Code != test.want {
				t.Fatalf("status=%d, want %d", recorder.Code, test.want)
			}
			var problem struct {
				Code string `json:"code"`
			}
			if err := json.Unmarshal(recorder.Body.Bytes(), &problem); err != nil {
				t.Fatal(err)
			}
			if problem.Code != test.wantCode {
				t.Fatalf("code=%q, want %q", problem.Code, test.wantCode)
			}
		})
	}
}

func TestIsInventoryJSON(t *testing.T) {
	if !isInventoryJSON("application/json") || !isInventoryJSON("application/json; charset=utf-8") {
		t.Fatal("application/json media types must be accepted")
	}
	if isInventoryJSON("") || isInventoryJSON("text/plain") || isInventoryJSON("application/") {
		t.Fatal("non-JSON media types must be rejected")
	}
}

func TestParseInventoryPageSize(t *testing.T) {
	tests := []struct {
		raw     string
		want    int
		wantErr bool
	}{
		{"", 0, false},
		{"10", 10, false},
		{"0", 0, true},
		{"-3", 0, true},
		{"abc", 0, true},
	}
	for _, test := range tests {
		request := httptest.NewRequest(http.MethodGet, "/api/v1/inventory?page_size="+test.raw, nil)
		size, err := parseInventoryPageSize(request)
		if (err != nil) != test.wantErr {
			t.Errorf("parseInventoryPageSize(%q) error=%v", test.raw, err)
			continue
		}
		if size != test.want {
			t.Errorf("parseInventoryPageSize(%q)=%d, want %d", test.raw, size, test.want)
		}
	}
}
