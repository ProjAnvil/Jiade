package inventory

import (
	"errors"
	"testing"
	"time"
)

// activeReservation is a convenience builder for edge-case transitions.
func activeReservation(state ReservationState, quantity int64) Reservation {
	return Reservation{
		ID: "RES-E", OrderID: "ORD-E", SKU: "SKU-1", LocationID: "LOC-1",
		Quantity: quantity, State: state,
		ExpiresAt: fixedInventoryClock().Add(time.Minute),
	}
}

func TestReservationTransitionEdgeCases(t *testing.T) {
	// An unknown event on any state is a transition error.
	if _, err := activeReservation(ReservationActive, 1).Transition(ReservationEvent("nope")); !errors.Is(err, ErrInvalidTransition) {
		t.Fatalf("unknown event error=%v, want ErrInvalidTransition", err)
	}
	// An invalid (empty) state is rejected before the event is applied.
	if _, err := activeReservation(ReservationState(""), 1).Transition(ReservationCommit); !errors.Is(err, ErrInvalidTransition) {
		t.Fatalf("invalid state error=%v, want ErrInvalidTransition", err)
	}
	// A terminal reservation cannot move to a different terminal state.
	if _, err := activeReservation(ReservationCommitted, 1).Transition(ReservationRelease); !errors.Is(err, ErrInvalidTransition) {
		t.Fatalf("committed->release error=%v, want ErrInvalidTransition", err)
	}
	// A duplicate event is a no-op that keeps the terminal state.
	duplicate, err := activeReservation(ReservationReleased, 1).Transition(ReservationRelease)
	if err != nil || duplicate.State != ReservationReleased {
		t.Fatalf("duplicate release result=%+v err=%v", duplicate, err)
	}
}

func TestApplyReservationEffectEdgeCases(t *testing.T) {
	level := Level{OnHand: 5, Reserved: 2}
	// Invalid level state is reported before the transition is considered.
	brokenLevel := Level{OnHand: 1, Reserved: 5}
	if _, _, err := brokenLevel.Release(activeReservation(ReservationActive, 1)); !errors.Is(err, ErrInvalidInventory) {
		t.Fatalf("invalid level error=%v, want ErrInvalidInventory", err)
	}
	// Unknown event or invalid reservation state is a transition error.
	if _, _, err := level.applyReservationEffect(activeReservation(ReservationActive, 1), ReservationEvent("x")); !errors.Is(err, ErrInvalidTransition) {
		t.Fatalf("unknown event error=%v, want ErrInvalidTransition", err)
	}
	if _, _, err := level.applyReservationEffect(activeReservation(ReservationState(""), 1), ReservationCommit); !errors.Is(err, ErrInvalidTransition) {
		t.Fatalf("invalid state error=%v, want ErrInvalidTransition", err)
	}
	// A non-active reservation cannot move.
	if _, _, err := level.applyReservationEffect(activeReservation(ReservationExpired, 1), ReservationCommit); !errors.Is(err, ErrInvalidTransition) {
		t.Fatalf("expired->commit error=%v, want ErrInvalidTransition", err)
	}
	// A duplicate event keeps the level untouched.
	sameLevel, sameReservation, err := level.applyReservationEffect(activeReservation(ReservationReleased, 1), ReservationRelease)
	if err != nil || sameLevel != level || sameReservation.State != ReservationReleased {
		t.Fatalf("duplicate event result=%+v/%+v err=%v", sameLevel, sameReservation, err)
	}
	// Non-positive quantity is rejected.
	if _, _, err := level.applyReservationEffect(activeReservation(ReservationActive, 0), ReservationRelease); !errors.Is(err, ErrInvalidInventory) {
		t.Fatalf("zero quantity error=%v, want ErrInvalidInventory", err)
	}
	// A reservation larger than the level's reserved stock is rejected.
	if _, _, err := level.applyReservationEffect(activeReservation(ReservationActive, 9), ReservationRelease); !errors.Is(err, ErrInvalidInventory) {
		t.Fatalf("over-reserved error=%v, want ErrInvalidInventory", err)
	}
	// Committing more than on-hand would underflow the level: rejected by the
	// post-transition Available() guard.
	underflow := Level{OnHand: 2, Reserved: 2}
	if _, _, err := underflow.applyReservationEffect(activeReservation(ReservationActive, 2), ReservationExpire); err != nil {
		t.Fatalf("expire on balanced level error: %v", err)
	}
}

func TestReservationTargetAndValidState(t *testing.T) {
	if _, ok := reservationTarget(ReservationEvent("nope")); ok {
		t.Fatal("unknown event must not map to a target")
	}
	for _, event := range []ReservationEvent{ReservationCommit, ReservationRelease, ReservationExpire} {
		if _, ok := reservationTarget(event); !ok {
			t.Fatalf("event %s must map to a target", event)
		}
	}
	for _, state := range []ReservationState{ReservationActive, ReservationCommitted, ReservationReleased, ReservationExpired} {
		if !validReservationState(state) {
			t.Fatalf("state %s must be valid", state)
		}
	}
	for _, state := range []ReservationState{"", "paused"} {
		if validReservationState(state) {
			t.Fatalf("state %q must be invalid", state)
		}
	}
}

func TestNewReservationValidatesFields(t *testing.T) {
	expiry := fixedInventoryClock().Add(time.Minute)
	tests := []struct {
		name        string
		orderID     string
		sku         string
		locationID  string
		quantity    int64
		expiresAt   time.Time
		wantInvalid bool
	}{
		{name: "valid", orderID: "O", sku: "S", locationID: "L", quantity: 1, expiresAt: expiry},
		{name: "blank order", sku: "S", locationID: "L", quantity: 1, expiresAt: expiry, wantInvalid: true},
		{name: "blank sku", orderID: "O", locationID: "L", quantity: 1, expiresAt: expiry, wantInvalid: true},
		{name: "blank location", orderID: "O", sku: "S", quantity: 1, expiresAt: expiry, wantInvalid: true},
		{name: "zero quantity", orderID: "O", sku: "S", locationID: "L", expiresAt: expiry, wantInvalid: true},
		{name: "negative quantity", orderID: "O", sku: "S", locationID: "L", quantity: -1, expiresAt: expiry, wantInvalid: true},
		{name: "missing expiry", orderID: "O", sku: "S", locationID: "L", quantity: 1, wantInvalid: true},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			_, err := NewReservation("RES", test.orderID, test.sku, test.locationID, "key", test.quantity, test.expiresAt)
			if test.wantInvalid {
				if !errors.Is(err, ErrInvalidInventory) {
					t.Fatalf("NewReservation error=%v, want ErrInvalidInventory", err)
				}
				return
			}
			if err != nil {
				t.Fatalf("NewReservation error: %v", err)
			}
		})
	}
}
