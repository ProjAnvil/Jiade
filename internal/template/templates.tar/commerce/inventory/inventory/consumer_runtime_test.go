package inventory

import (
	"context"
	"errors"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"commerce/lib/messaging"
	amqp "github.com/rabbitmq/amqp091-go"
)

func TestNewInventoryConsumerAndWithRetryQueue(t *testing.T) {
	service := NewService(newInventoryStoreStub(), fixedInventoryClock)
	consumer := NewConsumer(nil, service, messaging.RetryPolicy{MaxAttempts: 2})
	if consumer.service != service {
		t.Fatal("NewConsumer did not bind the service")
	}
	if got := consumer.WithRetryQueue("inventory.retry").retryQueue; got != "inventory.retry" {
		t.Fatalf("WithRetryQueue=%q", got)
	}
	var nilConsumer *Consumer
	if nilConsumer.WithRetryQueue("x") != nilConsumer {
		t.Fatal("WithRetryQueue on nil consumer must return the nil receiver")
	}
}

func TestInventoryProcessDeliveryRequiresStorePool(t *testing.T) {
	consumer := &Consumer{store: &PostgresStore{}, service: NewService(newInventoryStoreStub(), fixedInventoryClock)}
	if err := consumer.ProcessDelivery(context.Background(), amqp.Delivery{}); err == nil ||
		!strings.Contains(err.Error(), "store is unavailable") {
		t.Fatalf("ProcessDelivery error=%v, want unavailable store", err)
	}
	var nilConsumer *Consumer
	if err := nilConsumer.ProcessDelivery(context.Background(), amqp.Delivery{}); err == nil {
		t.Fatal("nil consumer ProcessDelivery must fail")
	}
}

func TestInventoryRunConsumerRejectsMissingCollaborators(t *testing.T) {
	consumer := NewConsumer(nil, NewService(newInventoryStoreStub(), fixedInventoryClock), messaging.RetryPolicy{})
	routing := DeliveryRouting{}
	ctx := context.Background()
	if err := RunConsumer(ctx, nil, &inventoryRouteStub{}, "queue", consumer, routing); err == nil {
		t.Fatal("nil channel must be rejected")
	}
	if err := RunConsumer(ctx, &amqp.Channel{}, &inventoryRouteStub{}, "queue", nil, routing); err == nil {
		t.Fatal("nil consumer must be rejected")
	}
	if err := RunConsumer(ctx, &amqp.Channel{}, nil, "queue", consumer, routing); err == nil {
		t.Fatal("nil router must be rejected")
	}
}

func TestInventoryRetryAcknowledgerSettlesTransientAndTerminal(t *testing.T) {
	original := &inventoryAckStub{}
	publisher := &inventoryRouteStub{}
	routing := DeliveryRouting{
		RetryExchange: "inv.retry.exchange", RetryRoutingKey: "inv.retry",
		DeadExchange: "inv.dead.exchange", DeadRoutingKey: "inv.dead",
	}
	acknowledger := &retryAcknowledger{
		original: original, publisher: publisher,
		delivery: amqp.Delivery{DeliveryTag: 2, MessageId: "evt-2", Body: []byte(`{}`)},
		routing:  routing, ctx: context.Background(),
	}
	if err := acknowledger.Ack(2, false); err != nil {
		t.Fatal(err)
	}
	if original.acks != 1 {
		t.Fatalf("acks=%d, want passthrough ack", original.acks)
	}
	if err := (&retryAcknowledger{}).Ack(2, false); err == nil {
		t.Fatal("nil original acknowledger Ack must fail")
	}

	if err := acknowledger.Nack(2, false, false); err != nil {
		t.Fatal(err)
	}
	if publisher.exchange != routing.RetryExchange || publisher.key != routing.RetryRoutingKey {
		t.Fatalf("transient route=%s/%s, want retry queue", publisher.exchange, publisher.key)
	}

	original, publisher = &inventoryAckStub{}, &inventoryRouteStub{}
	acknowledger = &retryAcknowledger{
		original: original, publisher: publisher,
		delivery: amqp.Delivery{DeliveryTag: 3, MessageId: "evt-3", Body: []byte(`{}`)},
		routing:  routing, ctx: context.Background(),
	}
	if err := acknowledger.Reject(3, false); err != nil {
		t.Fatal(err)
	}
	if publisher.exchange != routing.DeadExchange || publisher.key != routing.DeadRoutingKey {
		t.Fatalf("terminal route=%s/%s, want dead letter", publisher.exchange, publisher.key)
	}
	if original.rejects != 0 || original.acks != 1 {
		t.Fatalf("acks=%d rejects=%d, want routed ack only", original.acks, original.rejects)
	}
}

func TestInventoryRetryAcknowledgerPassthroughAndFailures(t *testing.T) {
	routing := DeliveryRouting{RetryExchange: "r", RetryRoutingKey: "r", DeadExchange: "d", DeadRoutingKey: "d"}
	delivery := amqp.Delivery{DeliveryTag: 8, MessageId: "evt-8", Body: []byte(`{}`)}

	original := &inventoryAckStub{}
	acknowledger := &retryAcknowledger{original: original, routing: routing}
	if err := acknowledger.Nack(8, false, true); err != nil {
		t.Fatal(err)
	}
	if err := acknowledger.Nack(8, true, false); err != nil {
		t.Fatal(err)
	}
	if err := acknowledger.Reject(8, true); err != nil {
		t.Fatal(err)
	}
	if original.nacks != 2 || original.rejects != 1 {
		t.Fatalf("nacks=%d rejects=%d, want passthrough settlements", original.nacks, original.rejects)
	}

	if err := (&retryAcknowledger{publisher: &inventoryRouteStub{}}).Nack(8, false, false); err == nil {
		t.Fatal("nil original acknowledger must fail")
	}
	if err := (&retryAcknowledger{original: &inventoryAckStub{}}).Reject(8, false); err == nil {
		t.Fatal("nil publisher must fail")
	}
	if err := (&retryAcknowledger{original: &inventoryAckStub{}, publisher: &inventoryRouteStub{}}).
		Nack(8, false, false); err == nil {
		t.Fatal("empty routing must fail")
	}

	original = &inventoryAckStub{}
	acknowledger = &retryAcknowledger{
		original: original, publisher: &inventoryRouteStub{err: errors.New("negative confirmation")},
		delivery: delivery, routing: routing, ctx: context.Background(),
	}
	if err := acknowledger.Nack(8, false, false); err == nil {
		t.Fatal("unconfirmed route returned nil")
	}
	if original.acks != 0 {
		t.Fatalf("acks=%d, want zero on unconfirmed route", original.acks)
	}

	acknowledger = &retryAcknowledger{
		original: &inventoryFailingAckStub{}, publisher: &inventoryRouteStub{},
		delivery: delivery, routing: routing, ctx: context.Background(),
	}
	if err := acknowledger.Reject(8, false); err == nil || !strings.Contains(err.Error(), "ack routed") {
		t.Fatalf("ack failure error=%v, want ack error", err)
	}

	acknowledger = &retryAcknowledger{
		original: &inventoryAckStub{}, publisher: &inventoryRouteStub{},
		delivery: delivery, routing: routing,
	}
	if err := acknowledger.Nack(8, false, false); err != nil {
		t.Fatalf("nil ctx route error: %v", err)
	}
}

func TestInventoryWorkerLifecycleWaitAndErrIfStopped(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	lifecycle := NewWorkerLifecycle(ctx, func(ctx context.Context) error {
		<-ctx.Done()
		return errors.New("inventory consumer crashed")
	})
	if err := lifecycle.ErrIfStopped(); err != nil {
		t.Fatalf("running worker ErrIfStopped=%v, want nil", err)
	}
	cancel()
	waitCtx, waitCancel := context.WithTimeout(context.Background(), time.Second)
	defer waitCancel()
	if err := lifecycle.Wait(waitCtx); err == nil || err.Error() != "inventory consumer crashed" {
		t.Fatalf("Wait error=%v, want terminal worker error", err)
	}
	select {
	case <-lifecycle.Done():
	default:
		t.Fatal("Done must be closed after the worker terminates")
	}

	clean := NewWorkerLifecycle(context.Background(), func(context.Context) error { return nil })
	if err := clean.Wait(waitCtx); err != nil {
		t.Fatalf("clean Wait error=%v", err)
	}
	if err := clean.ErrIfStopped(); err == nil || !strings.Contains(err.Error(), "worker stopped") {
		t.Fatalf("clean ErrIfStopped=%v, want stopped sentinel", err)
	}

	expiredCtx, expiredCancel := context.WithCancel(context.Background())
	expiredCancel()
	running := NewWorkerLifecycle(context.Background(), func(context.Context) error {
		time.Sleep(50 * time.Millisecond)
		return nil
	})
	if err := running.Wait(expiredCtx); !errors.Is(err, context.Canceled) {
		t.Fatalf("cancelled Wait error=%v, want context.Canceled", err)
	}
	var nilLifecycle *WorkerLifecycle
	if err := nilLifecycle.Wait(context.Background()); err == nil {
		t.Fatal("nil lifecycle Wait must fail")
	}
	if err := nilLifecycle.ErrIfStopped(); err == nil {
		t.Fatal("nil lifecycle ErrIfStopped must fail")
	}
}

func TestInventoryCombinePublisherAvailability(t *testing.T) {
	if CombinePublisherAvailability().Available() {
		t.Fatal("empty publisher set must be unavailable")
	}
	if !CombinePublisherAvailability(staticAvailability(true)).Available() {
		t.Fatal("single available publisher must be available")
	}
	if CombinePublisherAvailability(staticAvailability(true), nil).Available() {
		t.Fatal("nil publisher member must be unavailable")
	}
	if CombinePublisherAvailability(staticAvailability(true), staticAvailability(false)).Available() {
		t.Fatal("unavailable member must block the set")
	}
}

func TestInventoryRuntimeReadinessWithDependenciesBranches(t *testing.T) {
	healthyWorker := func(t *testing.T) *WorkerLifecycle {
		t.Helper()
		ctx, cancel := context.WithCancel(context.Background())
		t.Cleanup(cancel)
		return NewWorkerLifecycle(ctx, func(ctx context.Context) error {
			<-ctx.Done()
			return nil
		})
	}
	stopped := NewWorkerLifecycle(context.Background(), func(context.Context) error {
		return errors.New("relay crashed")
	})
	waitForStopped := func() {
		waitCtx, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		_ = stopped.Wait(waitCtx)
	}
	waitForStopped()

	scenarios := []struct {
		name     string
		build    func(t *testing.T) func(context.Context) error
		wantErr  string
	}{
		{
			name: "healthy",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil }, staticAvailability(true),
					func() bool { return false }, nil, healthyWorker(t))
			},
		},
		{
			name: "database nil",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(nil, staticAvailability(true), nil, nil, stopped)
			},
			wantErr: "database readiness is unavailable",
		},
		{
			name: "database error",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return errors.New("pg down") },
					staticAvailability(true), nil, nil, stopped)
			},
			wantErr: "pg down",
		},
		{
			name: "broker closed",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil },
					staticAvailability(true), func() bool { return true }, nil, stopped)
			},
			wantErr: "broker connection is closed",
		},
		{
			name: "publisher unavailable",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil },
					staticAvailability(false), nil, nil, stopped)
			},
			wantErr: "publisher is unavailable",
		},
		{
			name: "nil dependency probe",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil }, staticAvailability(true), nil,
					[]func(context.Context) error{nil}, stopped)
			},
			wantErr: "dependency 0 readiness is unavailable",
		},
		{
			name: "failing dependency probe",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil }, staticAvailability(true), nil,
					[]func(context.Context) error{func(context.Context) error { return errors.New("catalog down") }}, stopped)
			},
			wantErr: "dependency 0 is unavailable",
		},
		{
			name: "no workers",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil }, staticAvailability(true), nil, nil)
			},
			wantErr: "workers are unavailable",
		},
		{
			name: "worker stopped",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil }, staticAvailability(true), nil, nil, stopped)
			},
			wantErr: "worker stopped",
		},
	}
	for _, scenario := range scenarios {
		t.Run(scenario.name, func(t *testing.T) {
			err := scenario.build(t)(context.Background())
			if scenario.wantErr == "" {
				if err != nil {
					t.Fatalf("readiness error=%v, want healthy", err)
				}
				return
			}
			if err == nil || !strings.Contains(err.Error(), scenario.wantErr) {
				t.Fatalf("readiness error=%v, want %q", err, scenario.wantErr)
			}
		})
	}
}

func TestDecodeInventoryEnvelope(t *testing.T) {
	valid := messaging.Event{Type: "inventory.commit-requested.v1", Subject: "ORD-I",
		SchemaVersion: messaging.CurrentSchemaVersion,
		OccurredAt:    fixedInventoryClock(), Data: []byte(`{"order_id":"ORD-I"}`)}
	tests := []struct {
		name    string
		event   messaging.Event
		wantErr string
	}{
		{"valid", valid, ""},
		{
			name: "schema version mismatch",
			event: messaging.Event{Type: "inventory.commit-requested.v1", Subject: "ORD-I",
				SchemaVersion: messaging.CurrentSchemaVersion + 1,
				OccurredAt:    fixedInventoryClock(), Data: []byte(`{"order_id":"ORD-I"}`)},
			wantErr: "invalid inventory.commit-requested.v1 envelope or payload",
		},
		{
			name: "empty subject",
			event: messaging.Event{Type: "inventory.commit-requested.v1",
				SchemaVersion: messaging.CurrentSchemaVersion,
				OccurredAt:    fixedInventoryClock(), Data: []byte(`{"order_id":"ORD-I"}`)},
			wantErr: "invalid inventory.commit-requested.v1 envelope or payload",
		},
		{
			name: "zero occurred_at",
			event: messaging.Event{Type: "inventory.commit-requested.v1", Subject: "ORD-I",
				SchemaVersion: messaging.CurrentSchemaVersion, Data: []byte(`{"order_id":"ORD-I"}`)},
			wantErr: "invalid inventory.commit-requested.v1 envelope or payload",
		},
		{
			name: "empty data",
			event: messaging.Event{Type: "inventory.commit-requested.v1", Subject: "ORD-I",
				SchemaVersion: messaging.CurrentSchemaVersion, OccurredAt: fixedInventoryClock()},
			wantErr: "invalid inventory.commit-requested.v1 envelope or payload",
		},
		{
			name: "invalid json",
			event: messaging.Event{Type: "inventory.commit-requested.v1", Subject: "ORD-I",
				SchemaVersion: messaging.CurrentSchemaVersion,
				OccurredAt:    fixedInventoryClock(), Data: []byte(`nope`)},
			wantErr: "invalid inventory.commit-requested.v1 envelope or payload",
		},
		{
			name: "unknown field",
			event: messaging.Event{Type: "inventory.commit-requested.v1", Subject: "ORD-I",
				SchemaVersion: messaging.CurrentSchemaVersion,
				OccurredAt:    fixedInventoryClock(), Data: []byte(`{"order_id":"ORD-I","x":1}`)},
			wantErr: "decode inventory.commit-requested.v1 payload",
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			var payload orderIDEventPayload
			err := decodeInventoryEnvelope(test.event, &payload)
			if test.wantErr == "" {
				if err != nil {
					t.Fatalf("decodeInventoryEnvelope error: %v", err)
				}
				if payload.OrderID != "ORD-I" {
					t.Fatalf("OrderID=%q, want ORD-I", payload.OrderID)
				}
				return
			}
			if err == nil || !strings.Contains(err.Error(), test.wantErr) {
				t.Fatalf("decodeInventoryEnvelope error=%v, want %q", err, test.wantErr)
			}
		})
	}
}

func TestValidateInventorySubject(t *testing.T) {
	event := messaging.Event{Type: "inventory.commit-requested.v1", Subject: "ORD-S"}
	if err := validateInventorySubject(event, "ORD-S"); err != nil {
		t.Fatalf("matching subject error: %v", err)
	}
	if err := validateInventorySubject(event, ""); err == nil {
		t.Fatal("empty order id must be rejected")
	}
	if err := validateInventorySubject(event, "ORD-T"); err == nil {
		t.Fatal("mismatched order id must be rejected")
	}
}

// --- shared stubs (inventory flavour) ---

type inventoryAckStub struct {
	acks, nacks, rejects int
}

func (acknowledger *inventoryAckStub) Ack(uint64, bool) error {
	acknowledger.acks++
	return nil
}

func (acknowledger *inventoryAckStub) Nack(uint64, bool, bool) error {
	acknowledger.nacks++
	return nil
}

func (acknowledger *inventoryAckStub) Reject(uint64, bool) error {
	acknowledger.rejects++
	return nil
}

// inventoryFailingAckStub confirms routes but fails the final Ack.
type inventoryFailingAckStub struct{ inventoryAckStub }

func (acknowledger *inventoryFailingAckStub) Ack(uint64, bool) error {
	acknowledger.acks++
	return errors.New("channel closed")
}

type inventoryRouteStub struct {
	exchange, key string
	err           error
	routed        atomic.Int32
}

func (publisher *inventoryRouteStub) Route(_ context.Context, exchange, key string, _ amqp.Publishing) error {
	publisher.routed.Add(1)
	publisher.exchange, publisher.key = exchange, key
	return publisher.err
}

// staticAvailability satisfies the unexported publisherAvailability interface.
type staticAvailability bool

func (available staticAvailability) Available() bool { return bool(available) }
