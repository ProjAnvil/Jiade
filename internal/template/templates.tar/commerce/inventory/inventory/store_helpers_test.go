package inventory

import (
	"errors"
	"testing"
	"time"

	"github.com/jackc/pgx/v5/pgconn"
)

func TestAllocationsMatchCommand(t *testing.T) {
	command := ReserveCommand{
		OrderID: "ORD-M",
		Lines:   []ReserveLine{{SKU: "SKU-A", Quantity: 3}, {SKU: "SKU-B", Quantity: 1}},
	}
	tests := []struct {
		name       string
		allocations []ReservationAllocation
		want       bool
	}{
		{"empty allocations", nil, false},
		{
			name: "exact match split across locations",
			allocations: []ReservationAllocation{
				{OrderID: "ORD-M", SKU: "SKU-A", Quantity: 2},
				{OrderID: "ORD-M", SKU: "SKU-A", Quantity: 1},
				{OrderID: "ORD-M", SKU: "SKU-B", Quantity: 1},
			},
			want: true,
		},
		{
			name: "different order",
			allocations: []ReservationAllocation{
				{OrderID: "ORD-OTHER", SKU: "SKU-A", Quantity: 3},
			},
			want: false,
		},
		{
			name: "quantity mismatch",
			allocations: []ReservationAllocation{
				{OrderID: "ORD-M", SKU: "SKU-A", Quantity: 2},
			},
			want: false,
		},
		{
			name: "extra sku",
			allocations: []ReservationAllocation{
				{OrderID: "ORD-M", SKU: "SKU-A", Quantity: 3},
				{OrderID: "ORD-M", SKU: "SKU-C", Quantity: 1},
			},
			want: false,
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if got := allocationsMatchCommand(test.allocations, command); got != test.want {
				t.Fatalf("allocationsMatchCommand=%v, want %v", got, test.want)
			}
		})
	}
}

func TestAllocationFromReservationCanonicalises(t *testing.T) {
	chinaZone := time.FixedZone("CST", 8*60*60)
	reservation := Reservation{
		ID: "RES-1", OrderID: "ORD-1", SKU: "SKU-1", LocationID: "LOC-1",
		Quantity: 2, State: ReservationActive,
		ExpiresAt: time.Date(2026, 7, 24, 20, 0, 0, 0, chinaZone),
	}
	allocation := allocationFromReservation(reservation)
	if allocation.ID != reservation.ID || allocation.State != ReservationActive {
		t.Fatalf("allocation=%+v", allocation)
	}
	if allocation.ExpiresAt.Location() != time.UTC {
		t.Fatalf("expires_at location=%v, want UTC", allocation.ExpiresAt.Location())
	}
}

func TestReservationKeyPrefixAndDeterministicID(t *testing.T) {
	first := reservationKeyPrefix("reserve-key")
	second := reservationKeyPrefix("reserve-key")
	if first != second || len(first) == 0 {
		t.Fatalf("prefix=%q/%q, want stable non-empty", first, second)
	}
	if first == reservationKeyPrefix("other") {
		t.Fatal("distinct keys must derive distinct prefixes")
	}
	if deterministicID("MOV", "a", "b") != deterministicID("MOV", "a", "b") {
		t.Fatal("deterministicID must be stable for identical parts")
	}
	if deterministicID("MOV", "ab") == deterministicID("MOV", "a", "b") {
		t.Fatal("part boundaries must be separated by NUL bytes")
	}
}

func TestInventoryEventType(t *testing.T) {
	tests := []struct {
		event ReservationEvent
		want  string
	}{
		{ReservationRelease, "inventory.released.v1"},
		{ReservationCommit, "inventory.committed.v1"},
		{ReservationExpire, "inventory.expired.v1"},
	}
	for _, test := range tests {
		if got := inventoryEventType(test.event); got != test.want {
			t.Errorf("inventoryEventType(%s)=%q, want %q", test.event, got, test.want)
		}
	}
	// An unknown event panics by contract; recover to keep the failure message
	// readable instead of crashing the suite.
	defer func() {
		if recover() == nil {
			t.Error("inventoryEventType(unknown) must panic")
		}
	}()
	inventoryEventType(ReservationEvent("nope"))
}

func TestIsUniqueViolation(t *testing.T) {
	if !isUniqueViolation(&pgconn.PgError{Code: "23505"}) {
		t.Fatal("23505 must be a unique violation")
	}
	if isUniqueViolation(&pgconn.PgError{Code: "23503"}) {
		t.Fatal("foreign key violation is not a unique violation")
	}
	if isUniqueViolation(errors.New("plain")) {
		t.Fatal("plain error is not a unique violation")
	}
}

func TestApplyReservationTransitionInvalidEvent(t *testing.T) {
	level := Level{OnHand: 10, Reserved: 2}
	reservation := Reservation{
		ID: "RES-1", OrderID: "ORD-1", SKU: "SKU-1", LocationID: "LOC-1",
		Quantity: 2, State: ReservationActive,
		ExpiresAt: fixedInventoryClock().Add(time.Minute),
	}
	if _, _, err := applyReservationTransition(level, reservation, ReservationEvent("nope")); !errors.Is(err, ErrInvalidCommand) {
		t.Fatalf("applyReservationTransition(unknown event) error=%v, want ErrInvalidCommand", err)
	}
	if nextLevel, nextReservation, err := applyReservationTransition(level, reservation, ReservationCommit); err != nil {
		t.Fatalf("applyReservationTransition(commit) error: %v", err)
	} else if nextLevel.OnHand != 8 || nextLevel.Reserved != 0 || nextReservation.State != ReservationCommitted {
		t.Fatalf("commit result level=%+v reservation=%+v", nextLevel, nextReservation)
	}
}
