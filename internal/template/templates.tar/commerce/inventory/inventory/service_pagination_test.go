package inventory

import (
	"context"
	"encoding/base64"
	"errors"
	"math"
	"testing"
	"time"
)

func TestListLevelsPaginatesWithOpaqueCursor(t *testing.T) {
	store := newInventoryStoreStub()
	store.levels = []InventoryLevel{
		{SKU: "SKU-A", LocationID: "LOC-1", OnHand: 10, Reserved: 4, Available: 6},
		{SKU: "SKU-A", LocationID: "LOC-2", OnHand: 5, Available: 5},
		{SKU: "SKU-B", LocationID: "LOC-1", OnHand: 7, Available: 7},
	}
	service := NewService(store, fixedInventoryClock)

	first, err := service.ListLevels(context.Background(), "", 2)
	if err != nil {
		t.Fatalf("first page error: %v", err)
	}
	if len(first.Items) != 2 {
		t.Fatalf("first page items=%d, want 2", len(first.Items))
	}
	if first.NextCursor == "" {
		t.Fatal("expected a next cursor when more levels remain")
	}
	second, err := service.ListLevels(context.Background(), first.NextCursor, 2)
	if err != nil {
		t.Fatalf("second page error: %v", err)
	}
	if len(second.Items) != 1 || second.Items[0].SKU != "SKU-B" {
		t.Fatalf("second page=%+v, want single SKU-B", second.Items)
	}
	if second.NextCursor != "" {
		t.Fatalf("last page next cursor=%q, want empty", second.NextCursor)
	}
	// A cursor past every remaining row still renders an empty (non-nil) items
	// array instead of a null body.
	pastEnd, err := service.ListLevels(context.Background(),
		encodeInventoryCursor(InventoryCursor{SKU: "SKU-Z", LocationID: "LOC-9"}), 2)
	if err != nil {
		t.Fatalf("past-end page error: %v", err)
	}
	if pastEnd.Items == nil || len(pastEnd.Items) != 0 {
		t.Fatalf("past-end items=%v, want empty non-nil", pastEnd.Items)
	}
}

func TestDecodeInventoryCursor(t *testing.T) {
	valid := encodeInventoryCursor(InventoryCursor{SKU: "SKU-A", LocationID: "LOC-1"})
	tests := []struct {
		name   string
		cursor string
		wantOK bool
	}{
		{"empty means first page", "", true},
		{"round trip", valid, true},
		{"not base64", "!!!not-base64!!!", false},
		{"not json", encodeRawInventoryCursor([]byte("plain")), false},
		{"wrong version", encodeRawInventoryCursor([]byte(`{"v":2,"after":{"sku":"S","location_id":"L"}}`)), false},
		{"missing sku", encodeRawInventoryCursor([]byte(`{"v":1,"after":{"sku":"","location_id":"L"}}`)), false},
		{"missing location", encodeRawInventoryCursor([]byte(`{"v":1,"after":{"sku":"S","location_id":""}}`)), false},
		{"padded sku", encodeRawInventoryCursor([]byte(`{"v":1,"after":{"sku":" S","location_id":"L"}}`)), false},
		{"padded location", encodeRawInventoryCursor([]byte(`{"v":1,"after":{"sku":"S","location_id":" L"}}`)), false},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			cursor, err := decodeInventoryCursor(test.cursor)
			if test.wantOK {
				if err != nil {
					t.Fatalf("decodeInventoryCursor error: %v", err)
				}
				if test.cursor != "" &&
					(cursor.SKU != "SKU-A" || cursor.LocationID != "LOC-1") {
					t.Fatalf("cursor=%+v, want round-tripped values", cursor)
				}
				return
			}
			if !errors.Is(err, errInvalidCursor) {
				t.Fatalf("decodeInventoryCursor error=%v, want errInvalidCursor", err)
			}
		})
	}
}

// encodeRawInventoryCursor builds a cursor from arbitrary raw bytes so decode
// failure modes (non-JSON, wrong envelope) are observable.
func encodeRawInventoryCursor(raw []byte) string {
	return base64.RawURLEncoding.EncodeToString(raw)
}

func TestNormalizeInventoryPageSize(t *testing.T) {
	tests := []struct {
		requested int
		want      int
	}{
		{0, DefaultPageSize},
		{-5, DefaultPageSize},
		{1, 1},
		{DefaultPageSize, DefaultPageSize},
		{MaxPageSize, MaxPageSize},
		{MaxPageSize + 1, MaxPageSize},
	}
	for _, test := range tests {
		if got := normalizeInventoryPageSize(test.requested); got != test.want {
			t.Errorf("normalizeInventoryPageSize(%d)=%d, want %d", test.requested, got, test.want)
		}
	}
}

func TestListLevelsRejectsBadCursorAndStoreErrors(t *testing.T) {
	service := NewService(newInventoryStoreStub(), fixedInventoryClock)
	if _, err := service.ListLevels(context.Background(), "!!!", 10); !errors.Is(err, errInvalidCursor) {
		t.Fatalf("ListLevels(bad cursor) error=%v, want errInvalidCursor", err)
	}
	failing := NewService(&inventoryFailingStore{}, fixedInventoryClock)
	if _, err := failing.ListLevels(context.Background(), "", 10); err == nil ||
		!errors.Is(err, errLevelsUnavailable) {
		t.Fatalf("ListLevels(store error) error=%v, want wrapped store error", err)
	}
}

func TestListReservationsByOrderValidationAndCanonicalisation(t *testing.T) {
	store := newInventoryStoreStub()
	service := NewService(store, fixedInventoryClock)
	if _, err := service.ListReservationsByOrder(context.Background(), "   "); !errors.Is(err, ErrReservationNotFound) {
		t.Fatalf("blank order error=%v, want ErrReservationNotFound", err)
	}
	seed := ReservationAllocation{
		ID: "RES-9", OrderID: "ORD-RES-1", SKU: "SKU-1", LocationID: "LOC-1",
		Quantity: 2, State: ReservationActive,
		ExpiresAt: time.Date(2026, 7, 24, 20, 0, 0, 0, time.FixedZone("CST", 8*60*60)),
	}
	store.reservations["k"] = ReservationResult{OrderID: "ORD-RES-1", Allocations: []ReservationAllocation{seed}}
	allocations, err := service.ListReservationsByOrder(context.Background(), "ORD-RES-1")
	if err != nil {
		t.Fatalf("ListReservationsByOrder error: %v", err)
	}
	if len(allocations) != 1 {
		t.Fatalf("allocations=%d, want 1", len(allocations))
	}
	if allocations[0].ExpiresAt.Location() != time.UTC {
		t.Fatalf("expires_at location=%v, want UTC canonical", allocations[0].ExpiresAt.Location())
	}
	failing := NewService(&inventoryFailingStore{}, fixedInventoryClock)
	if _, err := failing.ListReservationsByOrder(context.Background(), "ORD-X"); !errors.Is(err, errReservationsUnavailable) {
		t.Fatalf("ListReservationsByOrder(store error) error=%v, want store error", err)
	}
}

func TestReserveValidatesAndAggregatesLines(t *testing.T) {
	store := newInventoryStoreStub()
	service := NewService(store, fixedInventoryClock)
	validLines := []ReserveLine{{SKU: "SKU-1", Quantity: 2}, {SKU: "SKU-1", Quantity: 3}}
	result, err := service.Reserve(context.Background(), ReserveCommand{
		OrderID: "ORD-AGG", IdempotencyKey: "agg-1", Lines: validLines,
	})
	if err != nil {
		t.Fatalf("Reserve error: %v", err)
	}
	// Duplicate SKUs are merged into one sorted line before hitting the store.
	if len(result.Allocations) != 1 || result.Allocations[0].Quantity != 5 {
		t.Fatalf("allocations=%+v, want merged quantity 5", result.Allocations)
	}

	tooMany := make([]ReserveLine, maxReservationLines+1)
	for index := range tooMany {
		tooMany[index] = ReserveLine{SKU: "SKU", Quantity: 1}
	}
	maxInt := int64(math.MaxInt64)
	commands := []ReserveCommand{
		{OrderID: "", IdempotencyKey: "k", Lines: validLines},
		{OrderID: "ORD-V", IdempotencyKey: "", Lines: validLines},
		{OrderID: "ORD-V", IdempotencyKey: "k"},
		{OrderID: "ORD-V", IdempotencyKey: "k", Lines: tooMany},
		{OrderID: "ORD-V", IdempotencyKey: "k", Lines: []ReserveLine{{SKU: " ", Quantity: 1}}},
		{OrderID: "ORD-V", IdempotencyKey: "k", Lines: []ReserveLine{{SKU: "SKU-1", Quantity: 0}}},
		{OrderID: "ORD-V", IdempotencyKey: "k", Lines: []ReserveLine{
			{SKU: "SKU-1", Quantity: maxInt}, {SKU: "SKU-1", Quantity: 1},
		}},
		// Expiry must be strictly after occurrence.
		{OrderID: "ORD-V", IdempotencyKey: "k", Lines: validLines,
			OccurredAt: fixedInventoryClock(), ExpiresAt: fixedInventoryClock()},
	}
	for _, command := range commands {
		if _, err := service.Reserve(context.Background(), command); !errors.Is(err, ErrInvalidCommand) {
			t.Errorf("Reserve(%+v) error=%v, want ErrInvalidCommand", command, err)
		}
	}

	// An explicit future expiry is preserved in UTC (13:00 UTC == 21:00 CST,
	// strictly after the fixed 12:00 UTC clock).
	chinaExpiry := time.Date(2026, 7, 24, 21, 0, 0, 0, time.FixedZone("CST", 8*60*60))
	if _, err := service.Reserve(context.Background(), ReserveCommand{
		OrderID: "ORD-TZ", IdempotencyKey: "tz-1",
		Lines: []ReserveLine{{SKU: "SKU-1", Quantity: 1}}, ExpiresAt: chinaExpiry,
	}); err != nil {
		t.Fatalf("Reserve(tz) error: %v", err)
	}
	if got := store.reservations["tz-1"].Allocations[0].ExpiresAt.Location(); got != time.UTC {
		t.Fatalf("expiry location=%v, want UTC", got)
	}
	if store.reserveErr != nil {
		t.Fatal("unexpected injected error")
	}
	// Store failures propagate unchanged.
	store.reserveErr = errors.New("pool exhausted")
	if _, err := service.Reserve(context.Background(), ReserveCommand{
		OrderID: "ORD-E", IdempotencyKey: "e-1",
		Lines: []ReserveLine{{SKU: "SKU-1", Quantity: 1}},
	}); err == nil {
		t.Fatal("Reserve must propagate store errors")
	}
}

func TestTransitionOrderValidatesInput(t *testing.T) {
	service := NewService(newInventoryStoreStub(), fixedInventoryClock)
	if _, err := service.TransitionOrder(context.Background(), "   ", ReservationCommit); !errors.Is(err, ErrInvalidCommand) {
		t.Fatalf("blank order error=%v, want ErrInvalidCommand", err)
	}
	if _, err := service.TransitionOrder(context.Background(), "ORD-V", ReservationEvent("explode")); !errors.Is(err, ErrInvalidCommand) {
		t.Fatalf("unknown event error=%v, want ErrInvalidCommand", err)
	}
	failing := NewService(&inventoryFailingStore{}, fixedInventoryClock)
	if _, err := failing.TransitionOrder(context.Background(), "ORD-V", ReservationCommit); !errors.Is(err, errTransitionUnavailable) {
		t.Fatalf("TransitionOrder(store error) error=%v, want store error", err)
	}
}

func TestGetLevelsBySKUPropagatesStoreErrors(t *testing.T) {
	service := NewService(&inventoryFailingStore{}, fixedInventoryClock)
	if _, err := service.GetLevelsBySKU(context.Background(), "SKU-1"); !errors.Is(err, errLevelsUnavailable) {
		t.Fatalf("GetLevelsBySKU(store error) error=%v, want store error", err)
	}
}

func TestNewServiceDefaultsClock(t *testing.T) {
	service := NewService(newInventoryStoreStub(), nil)
	if service.clock == nil {
		t.Fatal("NewService must default the clock to time.Now")
	}
}

// inventoryFailingStore fails every read/write with a distinct sentinel so the
// service error-wrapping branches are observable.
type inventoryFailingStore struct{}

var (
	errLevelsUnavailable       = errors.New("inventory levels store unavailable")
	errReservationsUnavailable = errors.New("inventory reservations store unavailable")
	errTransitionUnavailable   = errors.New("inventory transition store unavailable")
)

func (store *inventoryFailingStore) ListLevels(context.Context, InventoryCursor, int) ([]InventoryLevel, error) {
	return nil, errLevelsUnavailable
}

func (store *inventoryFailingStore) GetLevelsBySKU(context.Context, string) ([]InventoryLevel, error) {
	return nil, errLevelsUnavailable
}

func (store *inventoryFailingStore) ListReservationsByOrder(context.Context, string) ([]ReservationAllocation, error) {
	return nil, errReservationsUnavailable
}

func (store *inventoryFailingStore) Reserve(context.Context, ReserveCommand) (ReservationResult, error) {
	return ReservationResult{}, errReservationsUnavailable
}

func (store *inventoryFailingStore) TransitionOrder(context.Context, string, ReservationEvent, time.Time) ([]ReservationAllocation, bool, error) {
	return nil, false, errTransitionUnavailable
}

var _ Store = (*inventoryFailingStore)(nil)
