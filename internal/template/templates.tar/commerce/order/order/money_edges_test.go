package order

import (
	"errors"
	"math"
	"testing"
)

func TestRegionalTaxJurisdictions(t *testing.T) {
	tests := []struct {
		name       string
		country    string
		region     string
		taxable    int64
		wantBPS    int64
		wantTax    int64
		wantErr    bool
	}{
		{name: "china", country: "CN", taxable: 10000, wantBPS: 1300, wantTax: 1300},
		{name: "china normalizes case and padding", country: " cn ", region: "", taxable: 10000, wantBPS: 1300, wantTax: 1300},
		{name: "us oregon has no sales tax", country: "US", region: "OR", taxable: 10000, wantBPS: 0, wantTax: 0},
		{name: "us delaware", country: "US", region: "DE", taxable: 9999, wantBPS: 0, wantTax: 0},
		{name: "us montana", country: "US", region: "MT", taxable: 100, wantBPS: 0, wantTax: 0},
		{name: "us new hampshire", country: "US", region: "NH", taxable: 100, wantBPS: 0, wantTax: 0},
		{name: "us default state", country: "US", region: "CA", taxable: 10000, wantBPS: 725, wantTax: 725},
		{name: "us without region", country: "US", taxable: 10000, wantBPS: 725, wantTax: 725},
		{name: "united kingdom", country: "GB", taxable: 10000, wantBPS: 2000, wantTax: 2000},
		{name: "unlisted country", country: "JP", taxable: 10000, wantBPS: 1000, wantTax: 1000},
		{name: "missing country", country: "", taxable: 100, wantErr: true},
		{name: "negative taxable", country: "CN", taxable: -1, wantErr: true},
		{name: "overflow guard", country: "CN", taxable: math.MaxInt64, wantErr: true},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			basisPoints, tax, err := RegionalTax(test.country, test.region, test.taxable)
			if test.wantErr {
				if !errors.Is(err, ErrInvalidMoney) {
					t.Fatalf("RegionalTax error=%v, want ErrInvalidMoney", err)
				}
				return
			}
			if err != nil {
				t.Fatalf("RegionalTax error: %v", err)
			}
			if basisPoints != test.wantBPS || tax != test.wantTax {
				t.Fatalf("RegionalTax=%d/%d, want %d/%d", basisPoints, tax, test.wantBPS, test.wantTax)
			}
		})
	}
	// Tax rounds down to whole minor units.
	if _, tax, err := RegionalTax("CN", "", 12345); err != nil || tax != 1604 {
		t.Fatalf("RegionalTax rounding: tax=%d err=%v, want floor(12345*0.13)=1604", tax, err)
	}
}

func TestCheckedMultiplyAndAdd(t *testing.T) {
	if got, ok := checkedMultiply(3, 4); !ok || got != 12 {
		t.Fatalf("checkedMultiply(3,4)=%d/%v", got, ok)
	}
	if _, ok := checkedMultiply(-1, 4); ok {
		t.Fatal("negative left must fail")
	}
	if _, ok := checkedMultiply(4, -1); ok {
		t.Fatal("negative right must fail")
	}
	if _, ok := checkedMultiply(math.MaxInt64, 2); ok {
		t.Fatal("overflow must fail")
	}
	if got, ok := checkedMultiply(0, math.MaxInt64); !ok || got != 0 {
		t.Fatalf("checkedMultiply(0,max)=%d/%v, want 0", got, ok)
	}
	if got, ok := checkedAdd(5, 6); !ok || got != 11 {
		t.Fatalf("checkedAdd(5,6)=%d/%v", got, ok)
	}
	if _, ok := checkedAdd(-1, 6); ok {
		t.Fatal("negative add must fail")
	}
	if _, ok := checkedAdd(math.MaxInt64, 1); ok {
		t.Fatal("add overflow must fail")
	}
}

func TestAllocatePercentageDiscountEdges(t *testing.T) {
	// Rounding cents go to the largest remainders.
	allocations, err := AllocatePercentageDiscount([]int64{3333, 3333, 3334}, 1000)
	if err != nil {
		t.Fatal(err)
	}
	// 10% of 10000 is 1000; 333+333+333=999 so one extra cent goes to the
	// largest remainder (the third line, remainder 3340).
	if allocations[0] != 333 || allocations[1] != 333 || allocations[2] != 334 {
		t.Fatalf("allocations=%v, want 333/333/334", allocations)
	}
	// Zero amounts allocate nothing.
	if allocations, err := AllocatePercentageDiscount([]int64{0, 0}, 1000); err != nil || allocations[0] != 0 {
		t.Fatalf("zero allocations=%v err=%v", allocations, err)
	}
	// Invalid inputs are rejected.
	for _, test := range []struct {
		name    string
		amounts []int64
		bps     int64
	}{
		{"no amounts", nil, 100},
		{"negative basis points", []int64{100}, -1},
		{"basis points over 100%", []int64{100}, 10001},
		{"negative amount", []int64{-1}, 100},
		{"amount overflow", []int64{math.MaxInt64, math.MaxInt64}, 10000},
	} {
		t.Run(test.name, func(t *testing.T) {
			if _, err := AllocatePercentageDiscount(test.amounts, test.bps); !errors.Is(err, ErrInvalidMoney) {
				t.Fatalf("AllocatePercentageDiscount error=%v, want ErrInvalidMoney", err)
			}
		})
	}
	// A per-amount product can overflow before the aggregate does.
	if _, err := AllocatePercentageDiscount([]int64{math.MaxInt64}, 10000); !errors.Is(err, ErrInvalidMoney) {
		t.Fatalf("product overflow error=%v, want ErrInvalidMoney", err)
	}
}

func TestCalculateTotalsRejectsInvalidInputs(t *testing.T) {
	maxLine := Line{Quantity: math.MaxInt64, UnitPriceMinor: 2}
	tests := []struct {
		name     string
		lines    []Line
		shipping int64
		tax      int64
	}{
		{"no lines", nil, 0, 0},
		{"negative shipping", []Line{{Quantity: 1, UnitPriceMinor: 1}}, -1, 0},
		{"negative tax", []Line{{Quantity: 1, UnitPriceMinor: 1}}, 0, -1},
		{"zero quantity", []Line{{Quantity: 0, UnitPriceMinor: 1}}, 0, 0},
		{"negative price", []Line{{Quantity: 1, UnitPriceMinor: -1}}, 0, 0},
		{"discount exceeds line", []Line{{Quantity: 1, UnitPriceMinor: 5, DiscountMinor: 6}}, 0, 0},
		{"line overflow", []Line{maxLine}, 0, 0},
		{"subtotal overflow", []Line{
			{Quantity: math.MaxInt64 / 2, UnitPriceMinor: 2},
			{Quantity: 2, UnitPriceMinor: math.MaxInt64},
		}, 0, 0},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if _, err := CalculateTotals(test.lines, test.shipping, test.tax); !errors.Is(err, ErrInvalidMoney) {
				t.Fatalf("CalculateTotals error=%v, want ErrInvalidMoney", err)
			}
		})
	}
	// Total overflow at the final addition.
	if _, err := CalculateTotals([]Line{{Quantity: math.MaxInt64, UnitPriceMinor: 1}}, 1, math.MaxInt64); !errors.Is(err, ErrInvalidMoney) {
		t.Fatalf("total overflow error=%v, want ErrInvalidMoney", err)
	}
	// The happy equation holds.
	totals, err := CalculateTotals([]Line{
		{Quantity: 2, UnitPriceMinor: 1000, DiscountMinor: 200},
	}, 500, 130)
	if err != nil {
		t.Fatal(err)
	}
	want := Totals{Subtotal: 2000, Discount: 200, Shipping: 500, Tax: 130, Total: 2430}
	if totals != want {
		t.Fatalf("totals=%+v, want %+v", totals, want)
	}
}
