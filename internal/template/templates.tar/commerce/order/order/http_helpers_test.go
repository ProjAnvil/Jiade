package order

import (
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestRequireOrderJSON(t *testing.T) {
	tests := []struct {
		name   string
		header string
		want   bool
	}{
		{"exact", "application/json", true},
		{"charset", "application/json; charset=utf-8", true},
		{"missing", "", false},
		{"wrong media type", "text/json", false},
		{"malformed", "application/", false},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			request := httptest.NewRequest(http.MethodPost, "/", nil)
			if test.header != "" {
				request.Header.Set("Content-Type", test.header)
			}
			recorder := httptest.NewRecorder()
			if got := requireOrderJSON(recorder, request); got != test.want {
				t.Fatalf("requireOrderJSON=%v, want %v", got, test.want)
			}
			if !test.want && recorder.Code != http.StatusUnsupportedMediaType {
				t.Fatalf("status=%d, want 415", recorder.Code)
			}
		})
	}
}

func TestDecodeOrderJSONStrictness(t *testing.T) {
	newRequest := func(body string) *http.Request {
		return httptest.NewRequest(http.MethodPost, "/", strings.NewReader(body))
	}
	var destination struct {
		SKU string `json:"sku"`
	}
	if err := decodeOrderJSON(httptest.NewRecorder(), newRequest(`{"sku":"S"}`), &destination); err != nil {
		t.Fatalf("decodeOrderJSON error: %v", err)
	}
	if destination.SKU != "S" {
		t.Fatalf("SKU=%q", destination.SKU)
	}
	if err := decodeOrderJSON(httptest.NewRecorder(), newRequest(`{"sku":"S","x":1}`), &destination); err == nil {
		t.Fatal("unknown field must be rejected")
	}
	if err := decodeOrderJSON(httptest.NewRecorder(), newRequest(`{"sku":"S"} {"extra":1}`), &destination); err == nil {
		t.Fatal("second JSON value must be rejected")
	}
	if err := decodeOrderJSON(httptest.NewRecorder(), newRequest(``), &destination); err == nil {
		t.Fatal("empty body must be rejected")
	}
}

func TestParseOrderPageSize(t *testing.T) {
	tests := []struct {
		raw     string
		want    int
		wantErr bool
	}{
		{"", 0, false},
		{"25", 25, false},
		{"0", 0, true},
		{"-1", 0, true},
		{"nan", 0, true},
	}
	for _, test := range tests {
		request := httptest.NewRequest(http.MethodGet, "/api/v1/orders?page_size="+test.raw, nil)
		size, err := parseOrderPageSize(request)
		if (err != nil) != test.wantErr {
			t.Errorf("parseOrderPageSize(%q) error=%v", test.raw, err)
			continue
		}
		if size != test.want {
			t.Errorf("parseOrderPageSize(%q)=%d, want %d", test.raw, size, test.want)
		}
	}
}

func TestWriteOrderServiceErrorClassification(t *testing.T) {
	request := httptest.NewRequest(http.MethodPost, "/api/v1/carts", nil)
	tests := []struct {
		name   string
		err    error
		want   int
	}{
		{name: "nil"},
		{name: "invalid command", err: ErrInvalidCommand, want: http.StatusUnprocessableEntity},
		{name: "not found", err: ErrOrderNotFound, want: http.StatusNotFound},
		{name: "cart not found", err: ErrCartNotFound, want: http.StatusNotFound},
		{name: "conflict", err: ErrVersionConflict, want: http.StatusConflict},
		{name: "idempotency conflict", err: ErrIdempotencyConflict, want: http.StatusConflict},
		{name: "checkout uncertain", err: ErrCheckoutUncertain, want: http.StatusServiceUnavailable},
		{name: "invalid money", err: ErrInvalidMoney, want: http.StatusUnprocessableEntity},
		{name: "upstream unavailable", err: ErrUpstreamUnavailable, want: http.StatusServiceUnavailable},
		{name: "internal", err: errors.New("boom"), want: http.StatusInternalServerError},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			recorder := httptest.NewRecorder()
			handled := writeOrderServiceError(recorder, request, test.err)
			if test.err == nil {
				if handled {
					t.Fatal("nil error must not be handled")
				}
				return
			}
			if !handled {
				t.Fatal("error must be handled")
			}
			if recorder.Code != test.want {
				t.Fatalf("status=%d, want %d", recorder.Code, test.want)
			}
		})
	}
}

func TestWriteCartSetsETag(t *testing.T) {
	recorder := httptest.NewRecorder()
	writeCart(recorder, http.StatusOK, Cart{ID: "C1", Version: 7})
	if got := recorder.Header().Get("ETag"); got != `"7"` {
		t.Fatalf("ETag=%q, want quoted version", got)
	}
	var body struct {
		Version int64 `json:"version"`
	}
	if err := json.Unmarshal(recorder.Body.Bytes(), &body); err != nil {
		t.Fatal(err)
	}
	if body.Version != 7 {
		t.Fatalf("version=%d", body.Version)
	}
}

func TestWriteOrderProblemIncludesInstance(t *testing.T) {
	recorder := httptest.NewRecorder()
	request := httptest.NewRequest(http.MethodGet, "/api/v1/orders/ORD-404", nil)
	writeOrderProblem(recorder, request, http.StatusNotFound, "order_not_found")
	if recorder.Code != http.StatusNotFound {
		t.Fatalf("status=%d", recorder.Code)
	}
	var problem struct {
		Code     string `json:"code"`
		Instance string `json:"instance"`
	}
	if err := json.Unmarshal(recorder.Body.Bytes(), &problem); err != nil {
		t.Fatal(err)
	}
	if problem.Code != "order_not_found" || problem.Instance != request.URL.Path {
		t.Fatalf("problem=%+v", problem)
	}
}
