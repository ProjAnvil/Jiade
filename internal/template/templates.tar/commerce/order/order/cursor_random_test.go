package order

import (
	"encoding/base64"
	"errors"
	"strings"
	"testing"
	"time"
)

func TestOrderCursorRoundTrip(t *testing.T) {
	placedAt := time.Date(2026, 7, 24, 12, 0, 0, 0, time.UTC)
	cursor := OrderCursor{PlacedAt: placedAt, OrderID: "ord-123"}
	decoded, err := decodeOrderCursor(encodeOrderCursor(cursor))
	if err != nil {
		t.Fatalf("decodeOrderCursor error: %v", err)
	}
	if !decoded.PlacedAt.Equal(placedAt) || decoded.OrderID != "ord-123" {
		t.Fatalf("decoded=%+v, want round trip", decoded)
	}

	// An empty cursor means the first page.
	if decoded, err := decodeOrderCursor(""); err != nil || decoded.OrderID != "" {
		t.Fatalf("empty cursor decoded=%+v err=%v", decoded, err)
	}
}

// encodeRawOrderCursor builds a cursor from arbitrary raw bytes so decode
// failure modes are observable.
func encodeRawOrderCursor(raw []byte) string {
	return base64.RawURLEncoding.EncodeToString(raw)
}

func TestDecodeOrderCursorRejectsMalformed(t *testing.T) {
	paddedOrderID := encodeRawOrderCursor([]byte(
		`{"v":1,"placed_at":"2026-07-24T12:00:00Z","order_id":" o"}`))
	tests := []struct {
		name   string
		cursor string
	}{
		{"not base64", "!!!"},
		{"not json", encodeRawOrderCursor([]byte("plain"))},
		{"wrong version", encodeRawOrderCursor([]byte(`{"v":2,"placed_at":"2026-07-24T12:00:00Z","order_id":"o"}`))},
		{"zero placed_at", encodeRawOrderCursor([]byte(`{"v":1,"placed_at":"0001-01-01T00:00:00Z","order_id":"o"}`))},
		{"empty order id", encodeRawOrderCursor([]byte(`{"v":1,"placed_at":"2026-07-24T12:00:00Z","order_id":""}`))},
		{"padded order id", paddedOrderID},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if _, err := decodeOrderCursor(test.cursor); !errors.Is(err, errInvalidOrderCursor) {
				t.Fatalf("decodeOrderCursor(%q) error=%v, want errInvalidOrderCursor", test.cursor, err)
			}
		})
	}
}

func TestNormalizeOrderPageSize(t *testing.T) {
	tests := []struct {
		requested int
		want      int
	}{
		{0, DefaultPageSize},
		{-1, DefaultPageSize},
		{1, 1},
		{DefaultPageSize, DefaultPageSize},
		{MaxPageSize, MaxPageSize},
		{MaxPageSize + 1, MaxPageSize},
	}
	for _, test := range tests {
		if got := normalizeOrderPageSize(test.requested); got != test.want {
			t.Errorf("normalizeOrderPageSize(%d)=%d, want %d", test.requested, got, test.want)
		}
	}
}

func TestRandomHexProducesUppercaseHexOfRequestedLength(t *testing.T) {
	first := randomHex(8)
	if len(first) != 16 {
		t.Fatalf("randomHex(8) length=%d, want 16 hex chars", len(first))
	}
	if strings.ToUpper(first) != first {
		t.Fatalf("randomHex=%q, want uppercase", first)
	}
	for _, character := range first {
		if !strings.ContainsRune("0123456789ABCDEF", character) {
			t.Fatalf("randomHex=%q, want hex charset", first)
		}
	}
	if second := randomHex(8); second == first {
		t.Fatalf("two randomHex calls produced identical output %q", first)
	}
	if empty := randomHex(0); empty != "" {
		t.Fatalf("randomHex(0)=%q, want empty", empty)
	}
}
