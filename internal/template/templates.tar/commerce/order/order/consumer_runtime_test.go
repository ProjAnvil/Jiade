package order

import (
	"context"
	"errors"
	"strings"
	"testing"
	"time"

	"commerce/lib/messaging"
	amqp "github.com/rabbitmq/amqp091-go"
)

func TestOrderNewConsumerAndWithRetryQueue(t *testing.T) {
	consumer := NewConsumer(nil, messaging.RetryPolicy{MaxAttempts: 4})
	if consumer.policy.MaxAttempts != 4 {
		t.Fatalf("NewConsumer policy=%+v", consumer.policy)
	}
	if got := consumer.WithRetryQueue("order.retry").retryQueue; got != "order.retry" {
		t.Fatalf("WithRetryQueue=%q", got)
	}
	var nilConsumer *Consumer
	if nilConsumer.WithRetryQueue("x") != nilConsumer {
		t.Fatal("WithRetryQueue on nil consumer must return the nil receiver")
	}
}

func TestOrderConsumerGuardsUnavailableStore(t *testing.T) {
	event := messaging.NewEvent("payment.captured.v1", "ORD-G", "corr", "", []byte(`{}`),
		func() time.Time { return time.Now().UTC() })
	if err := NewConsumer(nil, messaging.RetryPolicy{}).Handle(context.Background(), event); err == nil ||
		!strings.Contains(err.Error(), "store is unavailable") {
		t.Fatalf("Handle error=%v, want unavailable store", err)
	}
	var nilConsumer *Consumer
	if err := nilConsumer.Handle(context.Background(), event); err == nil {
		t.Fatal("nil consumer Handle must fail")
	}
	consumer := NewConsumer(&PostgresStore{}, messaging.RetryPolicy{})
	if err := consumer.ProcessDelivery(context.Background(), amqp.Delivery{}); err == nil ||
		!strings.Contains(err.Error(), "store is unavailable") {
		t.Fatalf("ProcessDelivery error=%v, want unavailable store", err)
	}
	if err := nilConsumer.ProcessDelivery(context.Background(), amqp.Delivery{}); err == nil {
		t.Fatal("nil consumer ProcessDelivery must fail")
	}
}

func TestOrderRunConsumerRejectsMissingCollaborators(t *testing.T) {
	consumer := NewConsumer(nil, messaging.RetryPolicy{})
	routing := DeliveryRouting{}
	ctx := context.Background()
	if err := RunConsumer(ctx, nil, &retryPublisherStub{}, "queue", consumer, routing); err == nil {
		t.Fatal("nil channel must be rejected")
	}
	if err := RunConsumer(ctx, &amqp.Channel{}, &retryPublisherStub{}, "queue", nil, routing); err == nil {
		t.Fatal("nil consumer must be rejected")
	}
	if err := RunConsumer(ctx, &amqp.Channel{}, nil, "queue", consumer, routing); err == nil {
		t.Fatal("nil router must be rejected")
	}
}

func TestOrderRetryAcknowledgerAckAndLifecycleEdges(t *testing.T) {
	// Ack passthrough plus the nil-original guard.
	original := &acknowledgerStub{}
	acknowledger := &retryAcknowledger{original: original}
	if err := acknowledger.Ack(4, false); err != nil {
		t.Fatal(err)
	}
	if original.acks != 1 {
		t.Fatalf("acks=%d, want passthrough ack", original.acks)
	}
	if err := (&retryAcknowledger{}).Ack(4, false); err == nil {
		t.Fatal("nil original acknowledger Ack must fail")
	}

	// Requeue Nack / multiple Nack / requeue Reject pass through.
	acknowledger = &retryAcknowledger{original: original}
	if err := acknowledger.Nack(4, false, true); err != nil {
		t.Fatal(err)
	}
	if err := acknowledger.Nack(4, true, false); err != nil {
		t.Fatal(err)
	}
	if err := acknowledger.Reject(4, true); err != nil {
		t.Fatal(err)
	}
	if original.nacks != 2 || original.rejects != 1 {
		t.Fatalf("nacks=%d rejects=%d, want passthrough settlements", original.nacks, original.rejects)
	}

	// Missing routing / publisher fails without settling.
	if err := (&retryAcknowledger{original: &acknowledgerStub{}, publisher: &retryPublisherStub{}}).
		Nack(4, false, false); err == nil {
		t.Fatal("empty routing must fail")
	}
	if err := (&retryAcknowledger{original: &acknowledgerStub{}}).Reject(4, false); err == nil {
		t.Fatal("nil publisher must fail")
	}

	// A confirmed route whose ack fails surfaces the ack error.
	if err := (&retryAcknowledger{
		original: &orderFailingAckStub{}, publisher: &retryPublisherStub{},
		delivery: amqp.Delivery{DeliveryTag: 4, MessageId: "evt"},
		routing:  DeliveryRouting{RetryExchange: "r", RetryRoutingKey: "r"},
		ctx:      context.Background(),
	}).Nack(4, false, false); err == nil || !strings.Contains(err.Error(), "ack routed") {
		t.Fatal("ack failure must surface")
	}

	// Nil ctx defaults instead of panicking.
	if err := (&retryAcknowledger{
		original: &acknowledgerStub{}, publisher: &retryPublisherStub{},
		delivery: amqp.Delivery{DeliveryTag: 4},
		routing:  DeliveryRouting{DeadExchange: "d", DeadRoutingKey: "d"},
	}).Reject(4, false); err != nil {
		t.Fatalf("nil ctx route error: %v", err)
	}
}

func TestOrderWorkerLifecycleDoneAndWait(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	lifecycle := NewWorkerLifecycle(ctx, func(ctx context.Context) error {
		<-ctx.Done()
		return nil
	})
	select {
	case <-lifecycle.Done():
		t.Fatal("Done must be open while the worker runs")
	default:
	}
	cancel()
	waitCtx, waitCancel := context.WithTimeout(context.Background(), time.Second)
	defer waitCancel()
	if err := lifecycle.Wait(waitCtx); err != nil {
		t.Fatalf("Wait error=%v", err)
	}
	select {
	case <-lifecycle.Done():
	default:
		t.Fatal("Done must be closed after termination")
	}

	var nilLifecycle *WorkerLifecycle
	if err := nilLifecycle.Wait(context.Background()); err == nil {
		t.Fatal("nil lifecycle Wait must fail")
	}
}

func TestOrderCombinePublisherAvailability(t *testing.T) {
	if CombinePublisherAvailability().Available() {
		t.Fatal("empty publisher set must be unavailable")
	}
	if !CombinePublisherAvailability(availabilityStub(true)).Available() {
		t.Fatal("single available publisher must be available")
	}
	if CombinePublisherAvailability(availabilityStub(true), nil).Available() {
		t.Fatal("nil member must be unavailable")
	}
	if CombinePublisherAvailability(availabilityStub(true), availabilityStub(false)).Available() {
		t.Fatal("unavailable member must block the set")
	}
}

func TestOrderRuntimeReadinessWithDependenciesBranches(t *testing.T) {
	healthyWorker := func(t *testing.T) *WorkerLifecycle {
		t.Helper()
		ctx, cancel := context.WithCancel(context.Background())
		t.Cleanup(cancel)
		return NewWorkerLifecycle(ctx, func(ctx context.Context) error {
			<-ctx.Done()
			return nil
		})
	}
	stopped := NewWorkerLifecycle(context.Background(), func(context.Context) error {
		return errors.New("order relay crashed")
	})
	waitCtx, waitCancel := context.WithTimeout(context.Background(), time.Second)
	defer waitCancel()
	_ = stopped.Wait(waitCtx)

	scenarios := []struct {
		name     string
		build    func(t *testing.T) func(context.Context) error
		wantErr  string
	}{
		{
			name: "healthy",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil }, availabilityStub(true),
					func() bool { return false }, nil, healthyWorker(t))
			},
		},
		{
			name: "database nil",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(nil, availabilityStub(true), nil, nil, stopped)
			},
			wantErr: "database readiness is unavailable",
		},
		{
			name: "database error",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return errors.New("pg down") },
					availabilityStub(true), nil, nil, stopped)
			},
			wantErr: "pg down",
		},
		{
			name: "broker closed",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil }, availabilityStub(true),
					func() bool { return true }, nil, stopped)
			},
			wantErr: "broker connection is closed",
		},
		{
			name: "publisher unavailable",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil }, availabilityStub(false), nil, nil, stopped)
			},
			wantErr: "publisher is unavailable",
		},
		{
			name: "nil dependency probe",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil }, availabilityStub(true), nil,
					[]func(context.Context) error{nil}, stopped)
			},
			wantErr: "dependency 0 readiness is unavailable",
		},
		{
			name: "failing dependency probe",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil }, availabilityStub(true), nil,
					[]func(context.Context) error{func(context.Context) error { return errors.New("inventory down") }}, stopped)
			},
			wantErr: "dependency 0 is unavailable",
		},
		{
			name: "no workers",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil }, availabilityStub(true), nil, nil)
			},
			wantErr: "workers are unavailable",
		},
		{
			name: "worker stopped",
			build: func(t *testing.T) func(context.Context) error {
				return NewRuntimeReadinessWithDependencies(
					func(context.Context) error { return nil }, availabilityStub(true), nil, nil, stopped)
			},
			wantErr: "worker stopped",
		},
	}
	for _, scenario := range scenarios {
		t.Run(scenario.name, func(t *testing.T) {
			err := scenario.build(t)(context.Background())
			if scenario.wantErr == "" {
				if err != nil {
					t.Fatalf("readiness error=%v, want healthy", err)
				}
				return
			}
			if err == nil || !strings.Contains(err.Error(), scenario.wantErr) {
				t.Fatalf("readiness error=%v, want %q", err, scenario.wantErr)
			}
		})
	}
}

// orderFailingAckStub confirms routes but fails the final Ack.
type orderFailingAckStub struct{ acknowledgerStub }

func (acknowledger *orderFailingAckStub) Ack(uint64, bool) error {
	return errors.New("channel closed")
}
