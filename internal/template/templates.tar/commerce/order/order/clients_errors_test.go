package order

import (
	"context"
	"errors"
	"io"
	"net/http"
	"strings"
	"testing"

	platformclient "commerce/lib/client"
)

// newDependencyClient wires a dependency HTTP client at a transport that
// replies with the given status/body for every call.
func newDependencyClient(status int, body string) (*platformclient.Client, string) {
	transport := roundTripFunc(func(*http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: status,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(strings.NewReader(body)),
		}, nil
	})
	return platformclient.New(platformclient.Config{
		HTTPClient: &http.Client{Transport: transport},
	}), "http://dependency.test"
}

func TestCustomerValidateRejectsInvalidResponses(t *testing.T) {
	propagation := Propagation{RequestID: "r"}
	tests := []struct {
		name     string
		status   int
		body     string
		wantErr  error
	}{
		{
			name:    "validation reports invalid",
			status:  http.StatusOK,
			body:    `{"valid":false}`,
			wantErr: ErrInvalidCommand,
		},
		{
			name:    "validation missing address",
			status:  http.StatusOK,
			body:    `{"valid":true}`,
			wantErr: ErrInvalidCommand,
		},
		{
			name:    "upstream conflict",
			status:  http.StatusConflict,
			body:    `{"code":"idempotency_conflict"}`,
			wantErr: ErrIdempotencyConflict,
		},
		{
			name:    "upstream bad request maps to invalid command",
			status:  http.StatusBadRequest,
			body:    `{"code":"invalid"}`,
			wantErr: ErrInvalidCommand,
		},
		{
			name:    "upstream unavailable",
			status:  http.StatusBadGateway,
			body:    `{}`,
			wantErr: ErrUpstreamUnavailable,
		},
		{
			name:    "malformed json",
			status:  http.StatusOK,
			body:    `{nope`,
			wantErr: ErrUpstreamUnavailable,
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			resilient, base := newDependencyClient(test.status, test.body)
			_, err := NewCustomerHTTPClient(base, resilient).
				Validate(context.Background(), "CUS-1", "ADDR-1", propagation)
			if !errors.Is(err, test.wantErr) {
				t.Fatalf("Validate error=%v, want %v", err, test.wantErr)
			}
		})
	}

	// A customer payload that mismatches the requested identity is rejected.
	resilient, base := newDependencyClient(http.StatusOK,
		`{"valid":true,"customer":{},"address":{"address_id":"A"}}`)
	_ = resilient
	// The second GET returns a different customer id than requested.
	mismatchClient := platformclient.New(platformclient.Config{
		HTTPClient: &http.Client{Transport: roundTripFunc(func(request *http.Request) (*http.Response, error) {
			body := `{"valid":true,"address":{"address_id":"ADDR-1"}}`
			if strings.HasSuffix(request.URL.Path, "/customers/CUS-1") {
				body = `{"customer_id":"CUS-OTHER","email":"x@y.z","name":"X"}`
			}
			return &http.Response{
				StatusCode: http.StatusOK,
				Header:     http.Header{"Content-Type": []string{"application/json"}},
				Body:       io.NopCloser(strings.NewReader(body)),
				Request:    request,
			}, nil
		})},
	})
	if _, err := NewCustomerHTTPClient(base, mismatchClient).
		Validate(context.Background(), "CUS-1", "ADDR-1", propagation); !errors.Is(err, ErrInvalidCommand) {
		t.Fatalf("mismatched customer error=%v, want ErrInvalidCommand", err)
	}

	// Unconfigured clients fail closed instead of panicking.
	var nilCustomer *CustomerHTTPClient
	if _, err := nilCustomer.Validate(context.Background(), "C", "A", propagation); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("nil customer client error=%v", err)
	}
	if _, err := NewCustomerHTTPClient("", resilient).Validate(context.Background(), "C", "A", propagation); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("blank base URL error=%v", err)
	}
}

func TestCatalogSnapshotRejectsMismatches(t *testing.T) {
	propagation := Propagation{}
	resilient, base := newDependencyClient(http.StatusOK,
		`{"sku":"SKU-OTHER","title":"X","status":"active","available_for_sale":true,"unit_price_minor":10,"currency":"CNY"}`)
	if _, err := NewCatalogHTTPClient(base, resilient).
		Snapshot(context.Background(), []string{"SKU-1"}, propagation); !errors.Is(err, ErrInvalidCommand) {
		t.Fatalf("mismatched SKU error=%v, want ErrInvalidCommand", err)
	}
	// Unit price falls back to price_minor when zero.
	resilient2, base2 := newDependencyClient(http.StatusOK,
		`{"sku":"SKU-1","title":"X","status":"active","available_for_sale":true,"price_minor":77,"currency":"CNY"}`)
	snapshots, err := NewCatalogHTTPClient(base2, resilient2).
		Snapshot(context.Background(), []string{"SKU-1"}, propagation)
	if err != nil {
		t.Fatal(err)
	}
	if snapshots[0].UnitPriceMinor != 77 {
		t.Fatalf("unit price=%d, want price_minor fallback 77", snapshots[0].UnitPriceMinor)
	}
	var nilCatalog *CatalogHTTPClient
	if _, err := nilCatalog.Snapshot(context.Background(), nil, propagation); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("nil catalog client error=%v", err)
	}
	if _, err := NewCatalogHTTPClient("", resilient2).Snapshot(context.Background(), []string{"SKU-1"}, propagation); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("blank base URL error=%v", err)
	}
}

func TestInventoryClientErrorBranches(t *testing.T) {
	propagation := Propagation{CorrelationID: "c", CausationID: "cause"}
	command := ReservationCommand{OrderID: "ORD-1", IdempotencyKey: "k"}

	var nilInventory *InventoryHTTPClient
	if _, err := nilInventory.ReserveResult(context.Background(), command, propagation); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("nil inventory ReserveResult error=%v", err)
	}
	if err := nilInventory.Release(context.Background(), "ORD-1", propagation); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("nil inventory Release error=%v", err)
	}
	resilient, base := newDependencyClient(http.StatusInsufficientStorage, `{}`)
	inventory := NewInventoryHTTPClient(base, resilient)
	if _, err := inventory.ReserveResult(context.Background(), command, propagation); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("ReserveResult unavailable error=%v", err)
	}
	if err := inventory.Release(context.Background(), "ORD-1", propagation); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("Release unavailable error=%v", err)
	}
	// Blank base URL is rejected client-side.
	if _, err := NewInventoryHTTPClient("", resilient).ReserveResult(context.Background(), command, propagation); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("blank base ReserveResult error=%v", err)
	}
}

func TestDependencyReadyProbes(t *testing.T) {
	for _, test := range []struct {
		name    string
		status  int
		wantErr bool
	}{
		{"ready", http.StatusOK, false},
		{"service unavailable", http.StatusServiceUnavailable, true},
	} {
		t.Run(test.name, func(t *testing.T) {
			resilient, base := newDependencyClient(test.status, `{}`)
			client := NewInventoryHTTPClient(base, resilient)
			err := client.Ready(context.Background())
			if (err != nil) != test.wantErr {
				t.Fatalf("Ready error=%v wantErr=%v", err, test.wantErr)
			}
			// All three dependency clients share the readiness probe.
			if err := NewCatalogHTTPClient(base, resilient).Ready(context.Background()); (err != nil) != test.wantErr {
				t.Fatalf("catalog Ready error=%v", err)
			}
			if err := NewCustomerHTTPClient(base, resilient).Ready(context.Background()); (err != nil) != test.wantErr {
				t.Fatalf("customer Ready error=%v", err)
			}
		})
	}
	resilient, _ := newDependencyClient(http.StatusOK, `{}`)
	if err := NewInventoryHTTPClient("", resilient).Ready(context.Background()); !errors.Is(err, ErrUpstreamUnavailable) {
		t.Fatalf("blank base Ready error=%v", err)
	}
}

func TestApplyPropagationSetsAllHeaders(t *testing.T) {
	header := http.Header{}
	applyPropagation(header, Propagation{
		RequestID: "r1", Traceparent: "tp1", IdempotencyKey: "ik1",
		CorrelationID: "c1", CausationID: "cause1",
	})
	for name, want := range map[string]string{
		"X-Request-ID":     "r1",
		"traceparent":      "tp1",
		"Idempotency-Key":  "ik1",
		"X-Correlation-ID": "c1",
		"X-Causation-ID":   "cause1",
	} {
		if got := header.Get(name); got != want {
			t.Errorf("%s=%q, want %q", name, got, want)
		}
	}
	// Empty propagation leaves headers unset.
	header = http.Header{}
	applyPropagation(header, Propagation{})
	if len(header) != 0 {
		t.Fatalf("headers=%v, want none", header)
	}
}
