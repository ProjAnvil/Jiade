package order

import (
	"errors"
	"strings"
	"testing"
	"time"

	"commerce/lib/messaging"
)

func TestMustJSONAndDefaultText(t *testing.T) {
	if got := string(mustJSON(map[string]int{"a": 1})); got != `{"a":1}` {
		t.Fatalf("mustJSON=%s", got)
	}
	if got := defaultText("", "fallback"); got != "fallback" {
		t.Fatalf("defaultText empty=%q", got)
	}
	if got := defaultText("value", "fallback"); got != "value" {
		t.Fatalf("defaultText value=%q", got)
	}
}

func TestCommandFingerprintIsStableAndSensitive(t *testing.T) {
	first := commandFingerprint(CheckoutCommand{CartID: "C1", AddressID: "A1", IdempotencyKey: "k"})
	second := commandFingerprint(CheckoutCommand{CartID: "C1", AddressID: "A1", IdempotencyKey: "k"})
	if first != second {
		t.Fatal("fingerprint must be stable for identical commands")
	}
	if first == commandFingerprint(CheckoutCommand{CartID: "C1", AddressID: "A2", IdempotencyKey: "k"}) {
		t.Fatal("fingerprint must change with the payload")
	}
}

func TestValidatePayloadOrderMatchesSubject(t *testing.T) {
	event := messaging.Event{Type: "payment.captured.v1", Subject: "ORD-P"}
	if err := validatePayloadOrder(event, "ORD-P"); err != nil {
		t.Fatalf("matching subject error: %v", err)
	}
	if err := validatePayloadOrder(event, ""); err == nil {
		t.Fatal("empty payload order id must be rejected")
	}
	if err := validatePayloadOrder(event, "ORD-Q"); err == nil {
		t.Fatal("mismatched payload order id must be rejected")
	}
}

func TestValidateCheckoutCommandAndCart(t *testing.T) {
	now := time.Date(2026, 7, 24, 12, 0, 0, 0, time.UTC)
	for _, command := range []CheckoutCommand{
		{CartID: "", AddressID: "A", IdempotencyKey: "k"},
		{CartID: "C", AddressID: "", IdempotencyKey: "k"},
		{CartID: "C", AddressID: "A", IdempotencyKey: ""},
		{CartID: "C", AddressID: "A", IdempotencyKey: strings.Repeat("k", 201)},
	} {
		if err := validateCheckoutCommand(command); !errors.Is(err, ErrInvalidCommand) {
			t.Errorf("validateCheckoutCommand(%+v) error=%v, want ErrInvalidCommand", command, err)
		}
	}
	if err := validateCheckoutCommand(CheckoutCommand{CartID: "C", AddressID: "A", IdempotencyKey: "k"}); err != nil {
		t.Fatalf("valid command error: %v", err)
	}

	activeCart := func(mutate func(*Cart)) Cart {
		cart := Cart{
			ID: "C1", Status: CartActive, Currency: "CNY", Version: 1,
			ExpiresAt: now.Add(time.Hour),
			Lines:     []CartLine{{SKU: "SKU-1", Quantity: 1}},
		}
		if mutate != nil {
			mutate(&cart)
		}
		return cart
	}
	bad := []struct {
		name   string
		mutate func(*Cart)
	}{
		{"converted status", func(cart *Cart) { cart.Status = CartConverted }},
		{"no lines", func(cart *Cart) { cart.Lines = nil }},
		{"no currency", func(cart *Cart) { cart.Currency = "" }},
		{"zero version", func(cart *Cart) { cart.Version = 0 }},
		{"expired cart", func(cart *Cart) { cart.ExpiresAt = now.Add(-time.Minute) }},
		{"blank sku", func(cart *Cart) { cart.Lines[0].SKU = "  " }},
		{"zero quantity", func(cart *Cart) { cart.Lines[0].Quantity = 0 }},
		{"duplicate sku", func(cart *Cart) {
			cart.Lines = []CartLine{{SKU: "SKU-1", Quantity: 1}, {SKU: "SKU-1", Quantity: 2}}
		}},
	}
	for _, test := range bad {
		t.Run(test.name, func(t *testing.T) {
			if err := validateCheckoutCart(activeCart(test.mutate), now); !errors.Is(err, ErrInvalidCommand) {
				t.Fatalf("validateCheckoutCart error=%v, want ErrInvalidCommand", err)
			}
		})
	}
	if err := validateCheckoutCart(activeCart(nil), now); err != nil {
		t.Fatalf("valid cart error: %v", err)
	}
	// A zero ExpiresAt is treated as non-expiring.
	nonExpiring := activeCart(func(cart *Cart) { cart.ExpiresAt = time.Time{} })
	if err := validateCheckoutCart(nonExpiring, now); err != nil {
		t.Fatalf("non-expiring cart error: %v", err)
	}
}

func TestReconcileOrderAmounts(t *testing.T) {
	lines := []OrderLine{
		{Quantity: 2, UnitPriceMinor: 1000, DiscountMinor: 200, TotalMinor: 1800},
	}
	totals := Totals{Subtotal: 2000, Discount: 200, Shipping: 500, Tax: 130, Total: 2430}
	if err := reconcileOrderAmounts(lines, totals); err != nil {
		t.Fatalf("reconcileOrderAmounts error: %v", err)
	}
	if err := reconcileOrderAmounts(lines, Totals{Subtotal: 2001, Discount: 200, Shipping: 500, Tax: 130, Total: 2431}); !errors.Is(err, ErrInvalidMoney) {
		t.Fatalf("subtotal mismatch error=%v, want ErrInvalidMoney", err)
	}
	// Line total must equal quantity*price - discount.
	badLine := []OrderLine{{Quantity: 2, UnitPriceMinor: 1000, DiscountMinor: 0, TotalMinor: 1000}}
	if err := reconcileOrderAmounts(badLine, totals); !errors.Is(err, ErrInvalidMoney) {
		t.Fatalf("line mismatch error=%v, want ErrInvalidMoney", err)
	}
}

func TestReconcileStoredOrder(t *testing.T) {
	stored := Order{
		SubtotalMinor: 2000, DiscountMinor: 200, ShippingMinor: 500, TaxMinor: 130, TotalMinor: 2430,
		Lines: []OrderLine{{Quantity: 2, UnitPriceMinor: 1000, DiscountMinor: 200, TotalMinor: 1800}},
	}
	if err := reconcileStoredOrder(stored); err != nil {
		t.Fatalf("reconcileStoredOrder error: %v", err)
	}
	// A tampered total no longer reconciles.
	tampered := stored
	tampered.TotalMinor = 9999
	if err := reconcileStoredOrder(tampered); !errors.Is(err, ErrInvalidMoney) {
		t.Fatalf("tampered total error=%v, want ErrInvalidMoney", err)
	}
	// Line discount must not exceed the line gross.
	tamperedLines := stored
	tamperedLines.Lines = []OrderLine{{Quantity: 1, UnitPriceMinor: 5, DiscountMinor: 6, TotalMinor: 0}}
	if err := reconcileStoredOrder(tamperedLines); !errors.Is(err, ErrInvalidMoney) {
		t.Fatalf("invalid stored line error=%v, want ErrInvalidMoney", err)
	}
}
